import React from 'react';
import { Sun, Moon, Globe } from 'lucide-react';
import { Language } from '../i18n/translations';

interface Props {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  isDark: boolean;
  onToggleTheme: () => void;
}

export const ThemeLanguageBar: React.FC<Props> = ({
  currentLang,
  onLanguageChange,
  isDark,
  onToggleTheme,
}) => {
  return (
    <div className="flex items-center gap-1.5 bg-[#171820]/90 backdrop-blur-md p-1 rounded-full border border-[#2b2a26] text-xs">
      {/* Theme Toggle Button */}
      <button
        onClick={onToggleTheme}
        type="button"
        className="p-1.5 rounded-full hover:bg-white/10 text-[#d1cbc0] hover:text-[#e2a545] transition flex items-center justify-center cursor-pointer"
        title={isDark ? 'گۆڕین بۆ ڕووی ڕووناک (Light Mode)' : 'گۆڕین بۆ ڕووی تاریک (Dark Mode)'}
      >
        {isDark ? (
          <Sun className="w-3.5 h-3.5 text-amber-400" />
        ) : (
          <Moon className="w-3.5 h-3.5 text-indigo-400" />
        )}
      </button>

      {/* Language Selector Dropdown / Pills */}
      <div className="flex items-center gap-1 pl-1 pr-1 border-l border-[#2b2a26]">
        <button
          onClick={() => onLanguageChange('ku')}
          className={`px-2 py-0.5 rounded-full font-bold text-[11px] transition cursor-pointer ${
            currentLang === 'ku'
              ? 'bg-[#e2a545] text-black font-black'
              : 'text-[#9e978c] hover:text-[#f2ede4]'
          }`}
        >
          کوردی
        </button>
        <button
          onClick={() => onLanguageChange('ar')}
          className={`px-2 py-0.5 rounded-full font-bold text-[11px] transition cursor-pointer ${
            currentLang === 'ar'
              ? 'bg-[#e2a545] text-black font-black'
              : 'text-[#9e978c] hover:text-[#f2ede4]'
          }`}
        >
          عربي
        </button>
        <button
          onClick={() => onLanguageChange('en')}
          className={`px-2 py-0.5 rounded-full font-bold text-[11px] transition cursor-pointer ${
            currentLang === 'en'
              ? 'bg-[#e2a545] text-black font-black'
              : 'text-[#9e978c] hover:text-[#f2ede4]'
          }`}
        >
          EN
        </button>
      </div>
    </div>
  );
};
