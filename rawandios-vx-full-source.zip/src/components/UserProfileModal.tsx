import React from 'react';
import { X, User, ShieldCheck, Mail, LogOut, ShoppingBag, Clock, CheckCircle } from 'lucide-react';
import { AuthUser } from './AuthGateModal';
import { Language, translations } from '../i18n/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: AuthUser | null;
  onSignOut: () => void;
  lang: Language;
}

export const UserProfileModal: React.FC<Props> = ({ isOpen, onClose, user, onSignOut, lang }) => {
  const t = translations[lang];
  const isRtl = lang === 'ku' || lang === 'ar';

  if (!isOpen || !user) return null;

  // Retrieve saved orders
  let pastOrders: any[] = [];
  try {
    pastOrders = JSON.parse(localStorage.getItem('xv_orders') || '[]');
  } catch {
    pastOrders = [];
  }

  const providerLabel =
    user.provider === 'google'
      ? 'Google Play Account'
      : user.provider === 'apple'
      ? 'Apple ID Account'
      : 'Verified Gmail OTP';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-[#121319] border border-[#e2a545]/40 w-full max-w-md rounded-3xl p-5 sm:p-6 shadow-2xl relative text-[#f2ede4] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-[#2b2a26]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#e2a545]/20 border border-[#e2a545]/40 flex items-center justify-center text-[#e2a545]">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-[#f2ede4]">{t.account}</h3>
              <p className="text-[11px] text-[#9e978c]">{providerLabel}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-[#9e978c] hover:text-[#f2ede4] p-1.5 rounded-xl hover:bg-[#1f1e1a] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Card */}
        <div className="bg-[#181922] border border-[#2c2d3c] rounded-2xl p-4 mb-4 flex items-center gap-3.5">
          {user.avatar ? (
            <img src={user.avatar} alt="Avatar" className="w-12 h-12 rounded-full object-cover border-2 border-[#e2a545]" />
          ) : (
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#e2a545] to-[#f5b85a] text-black font-black flex items-center justify-center text-lg">
              {user.name.slice(0, 1).toUpperCase()}
            </div>
          )}

          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm text-[#f2ede4] truncate">{user.name}</div>
            <div className="text-xs text-[#a29d91] font-mono truncate">{user.email}</div>
            <div className="mt-1 flex items-center gap-1.5 text-[10px] text-emerald-400 font-bold">
              <CheckCircle className="w-3 h-3" />
              <span>Verified Sovereign Session</span>
            </div>
          </div>
        </div>

        {/* Past Orders in Session */}
        <div className="mb-4">
          <div className="text-xs font-bold text-[#d1cbc0] mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <ShoppingBag className="w-3.5 h-3.5 text-[#e2a545]" />
              <span>{lang === 'en' ? 'My Orders' : lang === 'ar' ? 'طلباتي السابقة' : 'داواکارییەکانی من'}</span>
            </span>
            <span className="text-[11px] text-[#716c61] font-mono">{pastOrders.length} {lang === 'en' ? 'orders' : 'داواکاری'}</span>
          </div>

          {pastOrders.length === 0 ? (
            <div className="p-4 bg-[#161720] rounded-xl border border-[#252634] text-center text-xs text-[#716c61]">
              {lang === 'en' ? 'No orders placed yet in this session.' : lang === 'ar' ? 'لم تقم بأي طلب حتى الآن.' : 'تا ئێستا هیچ داواکارییەکت تۆمار نەکردووە.'}
            </div>
          ) : (
            <div className="space-y-2 max-h-36 overflow-y-auto">
              {pastOrders.map((ord, idx) => (
                <div key={idx} className="p-2.5 bg-[#171822] border border-[#292a39] rounded-xl text-xs flex items-center justify-between">
                  <div>
                    <div className="font-mono font-bold text-[#e2a545] text-[11px]">{ord.invoiceId}</div>
                    <div className="text-[10px] text-[#757065]">{new Date(ord.date).toLocaleDateString()}</div>
                  </div>
                  <div className="font-bold text-[#f2ede4] text-[11px]">
                    {ord.totalIQD ? `${ord.totalIQD.toLocaleString()} IQD` : ''}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="pt-2 border-t border-[#252634] flex items-center justify-between gap-3">
          <button
            onClick={() => {
              onSignOut();
              onClose();
            }}
            className="flex-1 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-400 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>{t.signOut}</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-[#222129] hover:bg-[#2b2a34] text-xs font-bold transition text-[#d1cbc0]"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
