import React, { useState } from 'react';
import { X, ShoppingBag, Plus, Minus, Trash2, CheckCircle2, CreditCard, ShieldCheck, ArrowRight, Tag } from 'lucide-react';
import { Language, translations } from '../i18n/translations';

export interface ProductItem {
  id: string;
  titleKu: string;
  titleAr: string;
  titleEn: string;
  descKu: string;
  descAr: string;
  descEn: string;
  priceUSD: number;
  priceIQD: number;
  badgeKu: string;
  badgeAr: string;
  badgeEn: string;
  image: string;
  category: 'web' | 'image' | 'cyber' | 'bot';
}

export const STORE_PRODUCTS: ProductItem[] = [
  {
    id: 'prod-fullstack',
    titleKu: 'دروستکردنی وێبسایت و ئەپڵیکەیشنی تەواو (Full-Stack)',
    titleAr: 'تطوير موقع وتطبيق متكامل (Full-Stack)',
    titleEn: 'Full-Stack Custom Web & App Development',
    descKu: 'دیزاینی تایبەت، فرۆنت ئیند مۆدێرن، باکیند پارێزراو بە داتابەیس و چوونەژوورەوەی ئەلیکترۆنی.',
    descAr: 'تصميم احترافي، واجهة مستخدم سريعة، خادم آمن مع قاعدة بيانات ونظام مصادقة كامل.',
    descEn: 'Modern responsive UI, resilient Node/Express backend, database persistence, and user authentication.',
    priceUSD: 49,
    priceIQD: 65000,
    badgeKu: 'پڕفرۆشترین',
    badgeAr: 'الأكثر طلباً',
    badgeEn: 'Best Seller',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
    category: 'web',
  },
  {
    id: 'prod-photostudio',
    titleKu: 'ستۆدیۆی وێنە: لابردنی لۆگۆ و بەرزکردنەوەی کوالیتی 4K',
    titleAr: 'ستوديو الصور: إزالة النصوص ورفع الجودة 4K',
    titleEn: 'AI Photo Studio Pro & Logo Removal Suite',
    descKu: 'سڕینەوەی لۆگۆ و نوسین لە سەدان وێنە بەبێ تێکچوونی باکگراوند، ئیدیتکردنی پرۆفیشناڵ و 4K Upscale.',
    descAr: 'إزالة العلامات المائية والنصوص بدون تشويه الخلفية، تعديل ألوان سينمائي ورفع الدقة إلى 4K.',
    descEn: 'Automated watermark/logo removal, professional retouching, and 4K super-resolution upscaling.',
    priceUSD: 19,
    priceIQD: 25000,
    badgeKu: 'نوێ',
    badgeAr: 'جديد',
    badgeEn: 'New Release',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80',
    category: 'image',
  },
  {
    id: 'prod-cyberaudit',
    titleKu: 'پشکنینی ئەمنی قووڵی ٥ خاڵەکە بۆ کۆمپانیا و وێبسایت',
    titleAr: 'فحص الأمن السيبراني العميق ذو 5 نقاط للمؤسسات',
    titleEn: 'Enterprise 5-Point Cybersecurity Vulnerability Audit',
    descKu: 'پشکنینی پاراستنی ئەدمین، ڕەیت لمتەر، دزەکردنی .env، کەلێنی SSL و SQLi لەگەڵ ڕاپۆرتی فەرمی.',
    descAr: 'فحص ثغرات المسارات الحساسة، حماية .env، شهادات TLS 1.3، وحقن قواعد البيانات مع تقرير شامل.',
    descEn: 'Full spectrum audit of routes, rate limiters, leaked environments, SSL grade, and SQL injection prevention.',
    priceUSD: 35,
    priceIQD: 45000,
    badgeKu: 'سایبەر',
    badgeAr: 'أمني',
    badgeEn: 'Security',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80',
    category: 'cyber',
  },
  {
    id: 'prod-custombot',
    titleKu: 'دروستکردنی چاتبۆتی تایبەتی AI بۆ وەڵامدانەوەی کڕیار',
    titleAr: 'تطوير بوت ذكاء اصطناعي مخصص لخدمة العملاء',
    titleEn: 'Custom AI Customer Support Bot for Stores',
    descKu: 'وەڵامدانەوەی بەردەوامی کڕیارەکان لە وێبسایت یان واتسئاپ بە کوردی، عەرەبی و ئینگلیزی بە کەمترین کات.',
    descAr: 'رد فوري على استفسارات الزبائن على الموقع أو واتساب بالعربية والكردية والإنجليزية على مدار الساعة.',
    descEn: '24/7 intelligent automated customer service bot tailored for e-commerce, shops, and businesses.',
    priceUSD: 29,
    priceIQD: 38000,
    badgeKu: 'زیرەکی دەستکرد',
    badgeAr: 'ذكاء اصطناعي',
    badgeEn: 'AI Bot',
    image: 'https://images.unsplash.com/photo-1531746790731-6c087fecd65a?auto=format&fit=crop&w=600&q=80',
    category: 'bot',
  },
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const StoreOrderModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const t = translations[lang];
  const isRtl = lang === 'ku' || lang === 'ar';

  const [cart, setCart] = useState<Record<string, number>>({});
  const [activeTab, setActiveTab] = useState<'catalog' | 'checkout' | 'success'>('catalog');
  const [lastInvoiceId, setLastInvoiceId] = useState<string>('');

  // Checkout Form
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custCity, setCustCity] = useState('');
  const [custNotes, setCustNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'fastpay' | 'zaincash' | 'fib' | 'cod'>('cod');

  if (!isOpen) return null;

  const totalItemsCount = Object.values(cart).reduce((a, b) => a + b, 0);

  const calculateTotalIQD = () => {
    return Object.entries(cart).reduce((sum, [id, qty]) => {
      const prod = STORE_PRODUCTS.find((p) => p.id === id);
      return sum + (prod ? prod.priceIQD * qty : 0);
    }, 0);
  };

  const calculateTotalUSD = () => {
    return Object.entries(cart).reduce((sum, [id, qty]) => {
      const prod = STORE_PRODUCTS.find((p) => p.id === id);
      return sum + (prod ? prod.priceUSD * qty : 0);
    }, 0);
  };

  const handleAddToCart = (id: string) => {
    setCart((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => {
      const next = { ...prev };
      if (next[id] > 1) {
        next[id] -= 1;
      } else {
        delete next[id];
      }
      return next;
    });
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !custPhone.trim()) return;

    const invoice = `ORD-${Date.now().toString().slice(-6)}`;
    setLastInvoiceId(invoice);

    // Save order locally
    try {
      const existing = JSON.parse(localStorage.getItem('xv_orders') || '[]');
      existing.unshift({
        invoiceId: invoice,
        customerName: custName,
        phone: custPhone,
        city: custCity,
        notes: custNotes,
        paymentMethod,
        items: cart,
        totalIQD: calculateTotalIQD(),
        totalUSD: calculateTotalUSD(),
        date: new Date().toISOString(),
      });
      localStorage.setItem('xv_orders', JSON.stringify(existing));
    } catch {
      // ignore
    }

    setCart({});
    setActiveTab('success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-[#111216] border border-[#e2a545]/40 w-full max-w-3xl max-h-[92vh] rounded-3xl flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2b2a26] flex items-center justify-between bg-[#17171e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#e2a545]/20 border border-[#e2a545]/40 flex items-center justify-center text-[#e2a545]">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#f2ede4]">{t.storeTitle}</h3>
              <p className="text-xs text-[#9e978c]">{t.storeSubtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {totalItemsCount > 0 && activeTab === 'catalog' && (
              <button
                onClick={() => setActiveTab('checkout')}
                className="px-3 py-1.5 rounded-full bg-[#e2a545] hover:bg-[#f0c37c] text-black font-black text-xs transition flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <span>{t.cart} ({totalItemsCount})</span>
                <span>• {calculateTotalIQD().toLocaleString()} IQD</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Tabs */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {activeTab === 'catalog' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {STORE_PRODUCTS.map((prod) => {
                const inCartQty = cart[prod.id] || 0;
                const title = lang === 'en' ? prod.titleEn : lang === 'ar' ? prod.titleAr : prod.titleKu;
                const desc = lang === 'en' ? prod.descEn : lang === 'ar' ? prod.descAr : prod.descKu;
                const badge = lang === 'en' ? prod.badgeEn : lang === 'ar' ? prod.badgeAr : prod.badgeKu;

                return (
                  <div
                    key={prod.id}
                    className="bg-[#16171f] border border-[#2b2a26] hover:border-[#e2a545]/50 rounded-2xl p-4 flex flex-col justify-between transition group shadow-md"
                  >
                    <div>
                      <div className="relative w-full h-36 rounded-xl overflow-hidden mb-3 border border-[#2c2c36]">
                        <img
                          src={prod.image}
                          alt={title}
                          className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                        />
                        <span className="absolute top-2 right-2 bg-black/75 text-[#e2a545] border border-[#e2a545]/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                          {badge}
                        </span>
                      </div>

                      <h4 className="font-bold text-xs sm:text-sm text-[#f2ede4] mb-1 leading-snug">{title}</h4>
                      <p className="text-[11px] text-[#9e978c] leading-relaxed mb-3">{desc}</p>
                    </div>

                    <div className="pt-2 border-t border-[#252630] flex items-center justify-between">
                      <div>
                        <div className="font-black text-xs sm:text-sm text-[#e2a545]">
                          {prod.priceIQD.toLocaleString()} IQD
                        </div>
                        <div className="text-[10px] text-[#716c61]">${prod.priceUSD} USD</div>
                      </div>

                      {inCartQty > 0 ? (
                        <div className="flex items-center gap-2 bg-[#20212d] border border-[#373849] rounded-xl p-1">
                          <button
                            onClick={() => handleRemoveFromCart(prod.id)}
                            className="w-6 h-6 rounded-lg bg-[#2a2c3a] hover:bg-rose-500 hover:text-white flex items-center justify-center text-xs transition"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-black text-xs px-1 text-white">{inCartQty}</span>
                          <button
                            onClick={() => handleAddToCart(prod.id)}
                            className="w-6 h-6 rounded-lg bg-[#e2a545] hover:bg-[#f0c37c] text-black flex items-center justify-center text-xs transition"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleAddToCart(prod.id)}
                          className="px-3 py-1.5 rounded-xl bg-[#222129] hover:bg-[#e2a545] hover:text-black text-[#e2a545] font-bold text-xs transition flex items-center gap-1 cursor-pointer border border-[#e2a545]/40"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>{t.addToCart}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'checkout' && (
            <div className="space-y-4">
              <button
                onClick={() => setActiveTab('catalog')}
                className="text-xs text-[#9e978c] hover:text-[#f2ede4] flex items-center gap-1 cursor-pointer"
              >
                <span>← {t.back}</span>
              </button>

              {/* Order Summary */}
              <div className="bg-[#16171f] border border-[#2b2a26] rounded-2xl p-4">
                <h4 className="font-bold text-xs text-[#e2a545] mb-2.5 flex items-center gap-1.5">
                  <ShoppingBag className="w-4 h-4" />
                  <span>{t.cart} ({totalItemsCount} {lang === 'en' ? 'items' : 'دانە'})</span>
                </h4>

                <div className="space-y-2 divide-y divide-[#252630]">
                  {Object.entries(cart).map(([id, qty]) => {
                    const prod = STORE_PRODUCTS.find((p) => p.id === id);
                    if (!prod) return null;
                    const title = lang === 'en' ? prod.titleEn : lang === 'ar' ? prod.titleAr : prod.titleKu;
                    return (
                      <div key={id} className="pt-2 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-[#f2ede4]">{title}</div>
                          <div className="text-[10px] text-[#787368]">
                            {qty} × {prod.priceIQD.toLocaleString()} IQD
                          </div>
                        </div>
                        <div className="font-black text-[#e2a545]">
                          {(prod.priceIQD * qty).toLocaleString()} IQD
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-3 pt-3 border-t border-[#2f303c] flex items-center justify-between text-sm font-black">
                  <span className="text-[#f2ede4]">{t.total}:</span>
                  <span className="text-[#e2a545] text-base">
                    {calculateTotalIQD().toLocaleString()} IQD (${calculateTotalUSD()} USD)
                  </span>
                </div>
              </div>

              {/* Customer Details Form */}
              <form onSubmit={handleCheckoutSubmit} className="bg-[#16171f] border border-[#2b2a26] rounded-2xl p-4 sm:p-5 space-y-3">
                <h4 className="font-bold text-xs text-[#f2ede4] mb-2">{t.customerName} &amp; {t.customerPhone}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#d1cbc0] mb-1">{t.customerName}</label>
                    <input
                      type="text"
                      required
                      value={custName}
                      onChange={(e) => setCustName(e.target.value)}
                      placeholder={lang === 'en' ? 'Your Name' : lang === 'ar' ? 'الاسم الكريم' : 'ناوی بەڕێزت'}
                      className="w-full bg-[#1b1c25] border border-[#2e2f3d] focus:border-[#e2a545] rounded-xl text-xs px-3 py-2.5 text-[#f2ede4] outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#d1cbc0] mb-1">{t.customerPhone}</label>
                    <input
                      type="text"
                      required
                      value={custPhone}
                      onChange={(e) => setCustPhone(e.target.value)}
                      placeholder="0750 xxx xxxx"
                      className="w-full bg-[#1b1c25] border border-[#2e2f3d] focus:border-[#e2a545] rounded-xl text-xs px-3 py-2.5 text-[#f2ede4] outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#d1cbc0] mb-1">{t.customerCity}</label>
                  <input
                    type="text"
                    value={custCity}
                    onChange={(e) => setCustCity(e.target.value)}
                    placeholder={lang === 'en' ? 'Erbil, Sulaymaniyah, Baghdad, Duhok...' : lang === 'ar' ? 'أربيل، بغداد، السليمانية، دهوك...' : 'هەولێر، سلێمانی، بەغدا، دهۆک...'}
                    className="w-full bg-[#1b1c25] border border-[#2e2f3d] focus:border-[#e2a545] rounded-xl text-xs px-3 py-2.5 text-[#f2ede4] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#d1cbc0] mb-1">{t.paymentMethod}</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-2.5 rounded-xl border text-center font-bold transition cursor-pointer ${
                        paymentMethod === 'cod' ? 'bg-[#e2a545] text-black border-[#e2a545]' : 'bg-[#1b1c25] border-[#2e2f3d] text-[#a19c90]'
                      }`}
                    >
                      Cash
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('fastpay')}
                      className={`p-2.5 rounded-xl border text-center font-bold transition cursor-pointer ${
                        paymentMethod === 'fastpay' ? 'bg-[#e2a545] text-black border-[#e2a545]' : 'bg-[#1b1c25] border-[#2e2f3d] text-[#a19c90]'
                      }`}
                    >
                      FastPay
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('zaincash')}
                      className={`p-2.5 rounded-xl border text-center font-bold transition cursor-pointer ${
                        paymentMethod === 'zaincash' ? 'bg-[#e2a545] text-black border-[#e2a545]' : 'bg-[#1b1c25] border-[#2e2f3d] text-[#a19c90]'
                      }`}
                    >
                      ZainCash
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('fib')}
                      className={`p-2.5 rounded-xl border text-center font-bold transition cursor-pointer ${
                        paymentMethod === 'fib' ? 'bg-[#e2a545] text-black border-[#e2a545]' : 'bg-[#1b1c25] border-[#2e2f3d] text-[#a19c90]'
                      }`}
                    >
                      FIB
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-[#d1cbc0] mb-1">{t.customerNotes}</label>
                  <input
                    type="text"
                    value={custNotes}
                    onChange={(e) => setCustNotes(e.target.value)}
                    placeholder={lang === 'en' ? 'Any specific deadline or instructions' : lang === 'ar' ? 'أي ملاحظات أو مواعيد خاصة' : 'تێبینی یان کاتی خوازراو بۆ تەواوکردن'}
                    className="w-full bg-[#1b1c25] border border-[#2e2f3d] focus:border-[#e2a545] rounded-xl text-xs px-3 py-2 text-[#f2ede4] outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={totalItemsCount === 0}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f5b85a] hover:opacity-95 text-black font-black text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{t.orderNow}</span>
                </button>
              </form>
            </div>
          )}

          {activeTab === 'success' && (
            <div className="bg-[#161a22] border border-emerald-500/40 rounded-3xl p-6 text-center space-y-3 animate-fade-in">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="font-black text-lg text-[#f2ede4]">{t.orderSuccess}</h3>
              <p className="text-xs text-[#9e978c] max-w-md mx-auto leading-relaxed">{t.orderSuccessDesc}</p>
              <div className="inline-block bg-[#1b1d28] border border-emerald-500/30 rounded-xl px-4 py-2 text-xs font-mono text-emerald-300">
                <span>{t.invoiceId}: </span>
                <strong className="text-white">{lastInvoiceId}</strong>
              </div>
              <div className="pt-3">
                <button
                  onClick={() => setActiveTab('catalog')}
                  className="px-5 py-2.5 rounded-xl bg-[#e2a545] text-black font-black text-xs hover:bg-[#f0c37c] transition cursor-pointer shadow-md"
                >
                  {lang === 'en' ? 'Back to Store Catalog' : lang === 'ar' ? 'العودة للمتجر' : 'گەڕانەوە بۆ فرۆشگا'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 border-t border-[#2b2a26] bg-[#16171d] flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-[#7f7a6f] text-[11px]">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% Guaranteed Delivery & Secure Payments</span>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-[#222129] hover:bg-[#2b2a34] text-xs font-bold transition text-[#d1cbc0]"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
