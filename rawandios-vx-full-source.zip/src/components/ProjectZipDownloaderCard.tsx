import React, { useState, useEffect } from 'react';
import { Download, FolderArchive, FileCode, CheckCircle2, Terminal, Layers, Cpu, Shield, Sparkles, Copy, Check } from 'lucide-react';

interface ProjectFileInfo {
  path: string;
  sizeKb: number;
  category: string;
}

interface ProjectSummaryData {
  projectName: string;
  version: string;
  totalFiles: number;
  totalSizeKb: number;
  downloadUrl: string;
  files: ProjectFileInfo[];
  stack: {
    frontend: string[];
    backend: string[];
    securityTools: string[];
    architecture: string;
  };
}

export const ProjectZipDownloaderCard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'download' | 'architecture' | 'files' | 'run'>('download');
  const [summary, setSummary] = useState<ProjectSummaryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDownloading, setIsDownloading] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/project-summary')
      .then((res) => res.json())
      .then((data) => {
        setSummary(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load project summary:', err);
        setLoading(false);
      });
  }, []);

  const [downloadError, setDownloadError] = useState<string | null>(null);

  const handleDownload = async () => {
    try {
      setIsDownloading(true);
      setDownloadError(null);

      // Perform in-memory fetch blob download - this stays within the authenticated iframe session
      const response = await fetch('/api/download-vx-exact-zip');
      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'rawandios-vx-full-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
        setIsDownloading(false);
      }, 2500);
    } catch (err: any) {
      console.warn('Fetch blob download fallback to direct anchor:', err);
      // Fallback direct anchor
      try {
        const link = document.createElement('a');
        link.href = '/api/download-vx-exact-zip';
        link.download = 'rawandios-vx-full-source.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } catch (e: any) {
        setDownloadError('کێشەیەک ڕوویدا لە داگرتندا: ' + (err?.message || 'Unknown error'));
      }
      setIsDownloading(false);
    }
  };

  const handleDownloadSingleHtml = async () => {
    try {
      const resp = await fetch('/rawandios-vx.html');
      const text = await resp.text();
      const blob = new Blob([text], { type: 'text/html;charset=utf-8' });
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = 'rawandios-vx.html';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 2000);
    } catch (err: any) {
      window.location.href = '/rawandios-vx.html';
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(id);
    setTimeout(() => setCopiedCommand(null), 2000);
  };

  return (
    <div className="w-full my-3 bg-[#13141a] border border-[#e2a545]/40 rounded-2xl overflow-hidden shadow-2xl transition-all text-right font-sans" dir="rtl">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-[#211b11] via-[#1a1714] to-[#14151c] border-b border-[#e2a545]/30 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#e2a545] to-[#996515] flex items-center justify-center text-black shadow-lg shadow-[#e2a545]/20 shrink-0">
            <FolderArchive className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-[#f5f0e6] font-bold text-base sm:text-lg tracking-wide">
                فایلی ZIPی سەرجەم کۆد و پێکهاتەکانی ئەم وێبسایتە
              </h2>
              <span className="bg-[#e2a545]/20 text-[#e2a545] border border-[#e2a545]/40 text-[10px] px-2 py-0.5 rounded-full font-bold">
                Full Source (.zip)
              </span>
            </div>
            <p className="text-xs text-[#a3a4b0] mt-0.5">
              هەموو کۆدەکانی فرۆنتئێند، باکئێند، سێرڤەر، ستایلەکان و چۆنیەتی دروستکردنی ئەم ماڵپەڕە بە فایلی ZIP
            </p>
          </div>
        </div>

        {/* Quick Instant Download Button */}
        <button
          onClick={handleDownload}
          disabled={isDownloading}
          className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f0c37c] hover:from-[#f0c37c] hover:to-[#ffd594] text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#e2a545]/25 cursor-pointer transition transform active:scale-95 disabled:opacity-75"
        >
          <Download className="w-4 h-4" />
          <span>{isDownloading ? 'خەریکی دروستکردن و داگرتنە...' : 'داگرتنی تەواوی فایلی ZIP'}</span>
        </button>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-1 bg-[#101117] px-4 pt-2 border-b border-[#242531] overflow-x-auto scrollbar-none text-xs">
        <button
          onClick={() => setActiveTab('download')}
          className={`px-3 py-2 border-b-2 font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'download'
              ? 'border-[#e2a545] text-[#e2a545] bg-[#e2a545]/10 rounded-t-lg'
              : 'border-transparent text-[#8e909e] hover:text-[#e4e5ee]'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>داگرتن و پوختە</span>
        </button>

        <button
          onClick={() => setActiveTab('architecture')}
          className={`px-3 py-2 border-b-2 font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'architecture'
              ? 'border-[#e2a545] text-[#e2a545] bg-[#e2a545]/10 rounded-t-lg'
              : 'border-transparent text-[#8e909e] hover:text-[#e4e5ee]'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>چۆن دروستکراوە؟ (تەلارسازی)</span>
        </button>

        <button
          onClick={() => setActiveTab('files')}
          className={`px-3 py-2 border-b-2 font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'files'
              ? 'border-[#e2a545] text-[#e2a545] bg-[#e2a545]/10 rounded-t-lg'
              : 'border-transparent text-[#8e909e] hover:text-[#e4e5ee]'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>لیستی سەرجەم فایلەکان ({summary?.totalFiles || '...'})</span>
        </button>

        <button
          onClick={() => setActiveTab('run')}
          className={`px-3 py-2 border-b-2 font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap ${
            activeTab === 'run'
              ? 'border-[#e2a545] text-[#e2a545] bg-[#e2a545]/10 rounded-t-lg'
              : 'border-transparent text-[#8e909e] hover:text-[#e4e5ee]'
          }`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>ڕێبەری کارپێکردن لە ماڵەوە</span>
        </button>
      </div>

      {/* Tab 1: Download & Summary Card */}
      {activeTab === 'download' && (
        <div className="p-4 sm:p-6 space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#171822] border border-[#262837] p-3 rounded-xl flex flex-col">
              <span className="text-[11px] text-[#8e909e]">کۆی فایلەکانی پرۆژەکە</span>
              <span className="text-lg font-black text-[#f5f0e6] mt-1">
                {loading ? '...' : `${summary?.totalFiles || 32} فایل`}
              </span>
            </div>
            <div className="bg-[#171822] border border-[#262837] p-3 rounded-xl flex flex-col">
              <span className="text-[11px] text-[#8e909e]">فۆرماتی کۆکردنەوە</span>
              <span className="text-lg font-black text-[#e2a545] mt-1 font-mono">.ZIP (Level 9)</span>
            </div>
            <div className="bg-[#171822] border border-[#262837] p-3 rounded-xl flex flex-col">
              <span className="text-[11px] text-[#8e909e]">سیستەمی بنەڕەت</span>
              <span className="text-lg font-black text-emerald-400 mt-1">React 19 + Node.js</span>
            </div>
            <div className="bg-[#171822] border border-[#262837] p-3 rounded-xl flex flex-col">
              <span className="text-[11px] text-[#8e909e]">بزوێنەری پشکنین</span>
              <span className="text-lg font-black text-cyan-400 mt-1">Python + Express</span>
            </div>
          </div>

          {/* Action Box */}
          <div className="bg-[#181923] border border-[#e2a545]/20 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-right flex-1">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-bold text-white">فایلەکە هەموو کۆدەکانی بە خاوێنی لەخۆگرتووە</span>
              </div>
              <p className="text-xs text-[#a0a2b0] pr-6">
                فۆڵدەرەکانی <code className="text-[#e2a545] font-mono">src/</code>، <code className="text-[#e2a545] font-mono">server.ts</code>، <code className="text-[#e2a545] font-mono">vx_ai_scanner.py</code>، <code className="text-[#e2a545] font-mono">README.md</code>، و سەرجەم مۆداڵ و ستایلەکان ئامادەن.
              </p>
              {downloadError && (
                <p className="text-xs text-rose-400 pr-6 mt-1">{downloadError}</p>
              )}
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full md:w-auto shrink-0">
              <button
                onClick={handleDownloadSingleHtml}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-[#232432] hover:bg-[#2b2c3d] text-[#e2a545] border border-[#e2a545]/40 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow"
                title="داگرتنی تەنها یەک فایلی ڕاستەوخۆ بەبێ پێویستی بە هیچ ڕاژەکارێک"
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>داگرتنی تەنها فایلی HTML</span>
              </button>

              <button
                onClick={handleDownload}
                disabled={isDownloading}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-[#e2a545] via-[#efb96b] to-[#e2a545] hover:opacity-95 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl shadow-[#e2a545]/20 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>{isDownloading ? 'خەریکی داگرتنە...' : 'داگرتنی فایلی ZIP ئێستا'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Architecture (How it was built) */}
      {activeTab === 'architecture' && (
        <div className="p-4 sm:p-6 space-y-4">
          <div className="bg-[#171822] border border-[#272938] rounded-xl p-4 text-xs space-y-3">
            <h3 className="text-sm font-bold text-[#e2a545] flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span>پێکهاتەی تەلارسازی تەواوی ئەم وێبسایتە (Full Architecture):</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="bg-[#12131a] p-3 rounded-lg border border-[#212330]">
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 mb-1">
                  <Layers className="w-3.5 h-3.5" /> بەشی پێشەوە (Frontend)
                </span>
                <ul className="text-[#b2b4c4] space-y-1 list-disc list-inside text-[11.5px]">
                  <li><strong>React 19 & TypeScript:</strong> مۆدێرنترین ڤێرژنی کارکردنی خێرا بە تایپ‌سکریپت.</li>
                  <li><strong>Tailwind CSS 4:</strong> سیستمێکی یەکگرتووی تاریک و ڕووناک بە ئەنیمەیشنی نەرم.</li>
                  <li><strong>Leaflet & OpenStreetMap:</strong> نەخشەی زیندووی جوگرافی بۆ بازنەی سوور و پێگەکان.</li>
                  <li><strong>Lucide Icons:</strong> ئایکۆنی مۆدێرنی ئەندازیاری.</li>
                  <li><strong>Exifr:</strong> دەرهێنەری ناوخۆیی مێتاداتای EXIF و کۆردیناتی کامێرا.</li>
                </ul>
              </div>

              <div className="bg-[#12131a] p-3 rounded-lg border border-[#212330]">
                <span className="text-xs font-bold text-amber-400 flex items-center gap-1 mb-1">
                  <Cpu className="w-3.5 h-3.5" /> بەشی دواوە (Backend & Engines)
                </span>
                <ul className="text-[#b2b4c4] space-y-1 list-disc list-inside text-[11.5px]">
                  <li><strong>Node.js & Express:</strong> سێرڤەری سەرەکی بە پۆرت ۳۰۰۰.</li>
                  <li><strong>SSE (Server-Sent Events):</strong> ستریمکردنی ڕاستەوخۆ و پەیوەستبوون بە مۆدێلەکان.</li>
                  <li><strong>Deep Website Extractor:</strong> ڕەنکردنی هەر ماڵپەڕێک و دەرهێنانی HTML، CSS، JS و وێنەکانی.</li>
                  <li><strong>Archiver Engine:</strong> پەستانی فایلەکان و دروستکردنی فایلی ZIP لەسەر فڕین (On-the-Fly).</li>
                </ul>
              </div>

              <div className="bg-[#12131a] p-3 rounded-lg border border-[#212330] md:col-span-2">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1 mb-1">
                  <Shield className="w-3.5 h-3.5" /> مۆدیوولەکانی ئاسایش و سکانەر (Security & OSINT)
                </span>
                <p className="text-[#b2b4c4] text-[11.5px] leading-relaxed">
                  سیستەمەکە خاوەنی فایلی تایبەتی <code>vx_ai_scanner.py</code> یە بە پایتۆن کە پشکنینی پۆرت، مێتاداتا، کەلێنی .env، هێدەرەکانی SSL/TLS و ڕەیت لمتەر بە شێوازی سەروەرانە ئەنجام دەدات.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: All Project Files Explorer */}
      {activeTab === 'files' && (
        <div className="p-4 sm:p-6 space-y-3">
          <div className="flex items-center justify-between text-xs text-[#8e909e] px-1">
            <span>لیستی هەموو فایلە کۆدکراوەکانی ناو ئەم فایلی ZIPیە:</span>
            <span>کۆی گشتی: {summary?.files.length || '30+'} فایل</span>
          </div>

          <div className="bg-[#0f1016] border border-[#232533] rounded-xl max-h-72 overflow-y-auto divide-y divide-[#1e202c]">
            {(summary?.files || [
              { path: 'server.ts', sizeKb: 68.2, category: 'Backend & Types' },
              { path: 'src/App.tsx', sizeKb: 92.5, category: 'Frontend Source' },
              { path: 'src/components/LiveWebsiteRunnerCard.tsx', sizeKb: 14.8, category: 'React Components' },
              { path: 'src/components/ProjectZipDownloaderCard.tsx', sizeKb: 12.1, category: 'React Components' },
              { path: 'vx_ai_scanner.py', sizeKb: 6.5, category: 'Security Scanner' },
              { path: 'README.md', sizeKb: 4.2, category: 'Documentation' },
              { path: 'package.json', sizeKb: 1.1, category: 'Config' },
              { path: 'index.html', sizeKb: 2.3, category: 'Config' },
            ]).map((file, idx) => (
              <div key={idx} className="p-2.5 px-3 flex items-center justify-between text-xs hover:bg-[#151620] transition">
                <div className="flex items-center gap-2 text-right">
                  <FileCode className="w-3.5 h-3.5 text-[#e2a545]" />
                  <span className="font-mono text-[#e4e5ee] text-[12px]" dir="ltr">{file.path}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[10.5px] text-[#7d7f8d] bg-[#1a1c26] px-2 py-0.5 rounded border border-[#2b2d3c]">
                    {file.category}
                  </span>
                  <span className="font-mono text-[11px] text-[#a1a3b5]">{file.sizeKb} KB</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Run Locally Guide */}
      {activeTab === 'run' && (
        <div className="p-4 sm:p-6 space-y-4">
          <div className="bg-[#12131a] border border-[#262837] rounded-xl p-4 text-xs space-y-3">
            <h4 className="font-bold text-white text-sm">چۆن دوای داگرتنی فایلی ZIP لەسەر کۆمپیوتەری خۆت بیخەیتە کار؟</h4>

            <div className="space-y-3 pt-1">
              <div>
                <span className="text-emerald-400 font-bold block mb-1">١. فایلەکە لەناو کۆمپیوتەرەکەت Extract بکە (فایلەکانی زیپ دەربهێنە):</span>
                <div className="bg-[#0b0c10] p-2.5 rounded-lg border border-[#1e202c] font-mono text-xs text-[#cbd5e1] flex items-center justify-between" dir="ltr">
                  <span>unzip vx-ai-website-source.zip</span>
                  <button onClick={() => handleCopy('unzip vx-ai-website-source.zip', 'c1')} className="text-gray-400 hover:text-white">
                    {copiedCommand === 'c1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <span className="text-amber-400 font-bold block mb-1">٢. دابەزاندنی پاکێجەکانی Node.js (Dependencies):</span>
                <div className="bg-[#0b0c10] p-2.5 rounded-lg border border-[#1e202c] font-mono text-xs text-[#cbd5e1] flex items-center justify-between" dir="ltr">
                  <span>npm install</span>
                  <button onClick={() => handleCopy('npm install', 'c2')} className="text-gray-400 hover:text-white">
                    {copiedCommand === 'c2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <span className="text-cyan-400 font-bold block mb-1">٣. کارپێکردن بە خێرایی (Run Dev Server):</span>
                <div className="bg-[#0b0c10] p-2.5 rounded-lg border border-[#1e202c] font-mono text-xs text-[#cbd5e1] flex items-center justify-between" dir="ltr">
                  <span>npm run dev</span>
                  <button onClick={() => handleCopy('npm run dev', 'c3')} className="text-gray-400 hover:text-white">
                    {copiedCommand === 'c3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
