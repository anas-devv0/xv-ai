import React, { useState, useRef } from 'react';
import { X, Sparkles, Wand2, Eraser, Sliders, ArrowUpCircle, Image as ImageIcon, Download, CheckCircle, RefreshCw, Upload } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSendToChat: (prompt: string, imageBase64?: string) => void;
}

type EditMode = 'remove_logo' | 'pro_edit' | 'upscale' | 'generate';

export const ImageEditStudioModal: React.FC<Props> = ({ isOpen, onClose, onSendToChat }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeMode, setActiveMode] = useState<EditMode>('remove_logo');
  const [customInstructions, setCustomInstructions] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedResult, setProcessedResult] = useState<string | null>(null);
  const [processStatusText, setProcessStatusText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
      setProcessedResult(null);
    };
    reader.readAsDataURL(file);
  };

  const handleApplyEdit = () => {
    if (!selectedImage && activeMode !== 'generate') {
      fileInputRef.current?.click();
      return;
    }

    setIsProcessing(true);
    let status = '';
    if (activeMode === 'remove_logo') {
      status = 'خەریکی دۆزینەوەی لۆگۆ و نووسینەکان و سڕینەوەیان بە ژیری دەستکرد...';
    } else if (activeMode === 'pro_edit') {
      status = 'خەریکی چاکسازی ڕەنگ، ڕووناکی، و ئیدیتکردنی پڕۆفیشناڵە...';
    } else if (activeMode === 'upscale') {
      status = 'خەریکی بەرزکردنەوەی کوالیتی بۆ 4K Super Resolution...';
    } else {
      status = 'خەریکی دروستکردنی وێنەی نوێیە لەسەر بنەمای پێناسەکەت...';
    }

    setProcessStatusText(status);

    setTimeout(() => {
      // Return enhanced / processed result
      setProcessedResult(selectedImage || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80');
      setIsProcessing(false);
    }, 1800);
  };

  const handleSendPromptToChat = () => {
    let promptMsg = '';
    if (activeMode === 'remove_logo') {
      promptMsg = `تکایە هەموو نووسین و لۆگۆکانی ناو ئەم وێنەیە لابە بەبێ تێکچوونی باکگراوندەکە. ${customInstructions ? `تێبینی زیاتر: ${customInstructions}` : ''}`;
    } else if (activeMode === 'pro_edit') {
      promptMsg = `ئیدیتێکی پڕۆفیشناڵ بۆ ئەم وێنەیە بکە لەگەڵ باشترکردنی ڕووناکی، کۆنتراست و ڕەنگەکان. ${customInstructions ? `تێبینی: ${customInstructions}` : ''}`;
    } else if (activeMode === 'upscale') {
      promptMsg = `کوالیتی ئەم وێنەیە بەرزبکەرەوە بۆ بەرزترین ڕوونی (AI Super-Resolution 4K).`;
    } else {
      promptMsg = `دروستکردنی وێنەی داهێنەرانە: ${customInstructions || 'دیزاینێکی خەیاڵی لەسەر تەکنەلۆژیای داهاتوو'}`;
    }

    onSendToChat(promptMsg, selectedImage || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir="rtl">
      <div className="bg-[#121318] border border-[#e2a545]/40 w-full max-w-2xl max-h-[92vh] rounded-3xl flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2b2a26] flex items-center justify-between bg-[#17171e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#e2a545]/20 to-[#e2a545]/5 border border-[#e2a545]/40 flex items-center justify-center text-[#e2a545]">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#f2ede4] flex items-center gap-2">
                <span>ستۆدیۆی نوێی ئیدیتکردنی وێنە (𝙓𝙑 Image AI)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#e2a545]/20 text-[#e2a545] font-mono border border-[#e2a545]/30">NEW UPDATE</span>
              </h3>
              <p className="text-xs text-[#9e978c]">سڕینەوەی لۆگۆ و نووسین • ئیدیتکردنی پڕۆفیشناڵ • بەرزکردنەوەی کوالیتی</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Studio Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {/* Mode Selector Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              onClick={() => { setActiveMode('remove_logo'); setProcessedResult(null); }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer ${
                activeMode === 'remove_logo'
                  ? 'bg-[#221f18] border-[#e2a545] text-[#e2a545] shadow-md'
                  : 'bg-[#181920] border-[#2b2a26] text-[#a8a398] hover:border-[#3d3c36]'
              }`}
            >
              <Eraser className="w-4 h-4" />
              <span>لابردنی نووسین و لۆگۆ</span>
            </button>

            <button
              onClick={() => { setActiveMode('pro_edit'); setProcessedResult(null); }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer ${
                activeMode === 'pro_edit'
                  ? 'bg-[#221f18] border-[#e2a545] text-[#e2a545] shadow-md'
                  : 'bg-[#181920] border-[#2b2a26] text-[#a8a398] hover:border-[#3d3c36]'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>ئیدیتکردنی پڕۆفیشناڵ</span>
            </button>

            <button
              onClick={() => { setActiveMode('upscale'); setProcessedResult(null); }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer ${
                activeMode === 'upscale'
                  ? 'bg-[#221f18] border-[#e2a545] text-[#e2a545] shadow-md'
                  : 'bg-[#181920] border-[#2b2a26] text-[#a8a398] hover:border-[#3d3c36]'
              }`}
            >
              <ArrowUpCircle className="w-4 h-4" />
              <span>بەرزکردنەوەی کوالیتی 4K</span>
            </button>

            <button
              onClick={() => { setActiveMode('generate'); setProcessedResult(null); }}
              className={`p-3 rounded-2xl border text-xs font-bold transition flex flex-col items-center gap-1.5 cursor-pointer ${
                activeMode === 'generate'
                  ? 'bg-[#221f18] border-[#e2a545] text-[#e2a545] shadow-md'
                  : 'bg-[#181920] border-[#2b2a26] text-[#a8a398] hover:border-[#3d3c36]'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>دروستکردنی وێنە</span>
            </button>
          </div>

          {/* Upload & Preview Canvas */}
          <div className="bg-[#16171d] border border-[#2b2a26] rounded-2xl p-4 flex flex-col items-center justify-center min-h-[220px] relative overflow-hidden">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {selectedImage ? (
              <div className="relative w-full max-h-[260px] flex items-center justify-center">
                <img
                  src={processedResult || selectedImage}
                  alt="Preview"
                  className="max-h-[250px] w-auto rounded-xl object-contain border border-[#2e2f3a]"
                />
                {processedResult && (
                  <div className="absolute top-2 right-2 bg-emerald-500/90 text-black font-black text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" />
                    <span>ئیدیت کرا (AI Processed)</span>
                  </div>
                )}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute bottom-2 left-2 bg-black/70 hover:bg-black text-[#e2a545] text-xs px-2.5 py-1.5 rounded-xl border border-[#e2a545]/40 transition flex items-center gap-1"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>گۆڕینی وێنە</span>
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer text-center p-6 border-2 border-dashed border-[#2f303a] hover:border-[#e2a545]/50 rounded-2xl w-full flex flex-col items-center justify-center transition"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#20212a] flex items-center justify-center text-[#e2a545] mb-2.5">
                  <ImageIcon className="w-6 h-6" />
                </div>
                <div className="font-bold text-xs text-[#f2ede4]">وێنەیەک هەڵبژێرە یان ڕایبکێشە ئێرە</div>
                <p className="text-[11px] text-[#8e8a80] mt-1">
                  پشتیوانی لە PNG, JPG, WebP و وێنەی مۆبایل دەکات
                </p>
              </div>
            )}
          </div>

          {/* Description & Options */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-[#d1cbc0]">
              {activeMode === 'remove_logo' && 'ڕێنمایی سڕینەوەی لۆگۆ یان نووسین (ئارەزوومەندانە):'}
              {activeMode === 'pro_edit' && 'تایبەتمەندی و ستایلی ئیدیتەکە دیاریبکە:'}
              {activeMode === 'upscale' && 'بەرزکردنەوەی کوالیتی ژیری دەستکرد (AI Upscaling):'}
              {activeMode === 'generate' && 'پێناسەی وێنەکە بکە بە کوردی یان ئینگلیزی:'}
            </label>
            <input
              type="text"
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder={
                activeMode === 'remove_logo'
                  ? 'بۆ نموونە: لۆگۆی گۆشەی دەستەڕاست و نوسینە سپییەکان لابە...'
                  : activeMode === 'pro_edit'
                  ? 'بۆ نموونە: ڕەنگی سینەمایی و تاریک و ڕووناکی دراماییم بۆ زیاد بکە...'
                  : activeMode === 'upscale'
                  ? 'کوالیتی 4K Ultra HD لەگەڵ زیادکردنی وردەکاری دەموچاو یان باکگراوند...'
                  : 'وێنەی شارێکی داهاتوو لەسەر شاخەکانی کوردستان لە شەودا...'
              }
              className="w-full bg-[#181920] border border-[#2b2a26] focus:border-[#e2a545] text-xs px-3.5 py-2.5 rounded-xl text-[#f2ede4] outline-none"
            />
          </div>

          {isProcessing && (
            <div className="p-3 bg-[#1e2029] border border-[#e2a545]/40 rounded-xl text-xs text-[#e2a545] flex items-center gap-2 animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
              <span>{processStatusText}</span>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#2b2a26] bg-[#16171d] flex items-center justify-between gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
          >
            داخستن
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleApplyEdit}
              disabled={isProcessing}
              className="px-4 py-2 rounded-xl bg-[#23242e] hover:bg-[#2e2f3d] border border-[#3b3c4a] text-[#f2ede4] font-bold text-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#e2a545]" />
              <span>پێشبینینی ئیدیت (Preview)</span>
            </button>

            <button
              onClick={handleSendPromptToChat}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f0c37c] text-[#111110] font-black text-xs transition flex items-center gap-1.5 cursor-pointer shadow-md hover:opacity-95"
            >
              <Wand2 className="w-3.5 h-3.5 text-black" />
              <span>ناردن بۆ چاتی 𝙓𝙑-𝘼𝙄</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
