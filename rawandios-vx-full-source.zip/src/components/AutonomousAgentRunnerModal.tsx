import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle2,
  Copy,
  Check,
  Download,
  Smartphone,
  Tablet,
  Monitor,
  Code2,
  Terminal,
  Database,
  ExternalLink,
  Layers,
  Wand2,
} from 'lucide-react';
import { Language, translations } from '../i18n/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  initialPrompt?: string;
}

interface TemplatePreset {
  id: string;
  titleKu: string;
  titleAr: string;
  titleEn: string;
  promptKu: string;
  badge: string;
}

const TEMPLATES: TemplatePreset[] = [
  {
    id: 'store',
    titleKu: '🛍️ فرۆشگای مۆدێرن و داواکاری',
    titleAr: '🛍️ متجر إلكتروني فخم مع السلة',
    titleEn: '🛍️ Modern E-Commerce Store',
    promptKu: 'وێبسایتێکی تەواو بۆ فرۆشگای ئۆنلاین بە دیزاینی زێڕین و ڕەش، سەلەی کڕین، لیستی بەرهەم و فۆرمی داواکاری دروستبکە و ڕەنی بکە.',
    badge: 'Popular',
  },
  {
    id: 'academy',
    titleKu: '📚 پلاتفۆرمی فێرکاری و وانەکان',
    titleAr: '📚 منصة كورسات وأكاديمية تعليمية',
    titleEn: '📚 Learning Academy & Courses',
    promptKu: 'پلاتفۆرمێکی فێرکاری بۆ وانە و کۆرسەکان لەگەڵ بینەری ڤیدیۆ، داواکردنی کۆرس و تۆمارکردنی قوتابیان دروستبکە و ڕەنی بکە.',
    badge: 'Education',
  },
  {
    id: 'restaurant',
    titleKu: '🍕 سیستەمی چێشتخانە و مینیۆ',
    titleAr: '🍕 منيو مطعم وتوصيل وجبات',
    titleEn: '🍕 Restaurant & Food Delivery',
    promptKu: 'وێبسایتێکی چێشتخانە بە مینیۆی خواردن، نرخی بە دۆلار و دینار، و داواکردنی ڕاستەوخۆ دروستبکە و ڕەنی بکە.',
    badge: 'Food',
  },
  {
    id: 'agency',
    titleKu: '💼 کۆمپانیای داهێنەر و پۆرتفۆلیۆ',
    titleAr: '💼 موقع شركة برمجيات وتصميم',
    titleEn: '💼 Creative Tech Agency',
    promptKu: 'وێبسایتێکی بەهێزی پۆرتفۆلیۆ بۆ کۆمپانیای تەکنەلۆژیا لەگەڵ خزمەتگوزارییەکان و شیکاری پڕۆژە دروستبکە و ڕەنی بکە.',
    badge: 'Agency',
  },
  {
    id: 'cyber',
    titleKu: '🛡️ داشبۆردی سایبەر سکیوریتی',
    titleAr: '🛡️ لوحة تحكم أمن سيبراني',
    titleEn: '🛡️ Cyber SOC Security Dashboard',
    promptKu: 'داشبۆردێکی چاودێری سایبەر سکیوریتی بۆ پشکنینی پۆرت، ڕەیت لمتەر، دزەکردنی نهێنییەکان لەگەڵ مۆنیتەرینگ دروستبکە و ڕەنی بکە.',
    badge: 'Cyber SOC',
  },
];

export const AutonomousAgentRunnerModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lang,
  initialPrompt = '',
}) => {
  const isRtl = lang === 'ku' || lang === 'ar';
  const [userPrompt, setUserPrompt] = useState(
    initialPrompt || 'وێبسایتێکی مۆدێرن بۆ فرۆشگای ئۆنلاین بە دیزاینی سەردەمیانە دروستبکە و ڕەنی بکە.'
  );
  const [deviceView, setDeviceView] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeCodeTab, setActiveCodeTab] = useState<'preview' | 'frontend' | 'backend' | 'schema'>('preview');
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildStep, setBuildStep] = useState<number>(0);
  const [buildProgress, setBuildProgress] = useState<number>(0);
  const [hasCompleted, setHasCompleted] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [generatedHtml, setGeneratedHtml] = useState<string>('');

  useEffect(() => {
    if (initialPrompt) {
      setUserPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  const generateDynamicHtml = (title: string, desc: string) => {
    return `<!DOCTYPE html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} | Autonomous Run by VX AI</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
    body {
      font-family: 'Plus Jakarta Sans', system-ui, sans-serif;
      background: #090a0f;
      color: #f1ede4;
      margin: 0;
      padding: 0;
    }
    .accent-gradient {
      background: linear-gradient(135deg, #e2a545 0%, #f5c46b 100%);
    }
  </style>
</head>
<body class="min-h-screen flex flex-col justify-between">
  <!-- Top Banner -->
  <div class="bg-[#12131b] border-b border-[#262734] px-4 py-2.5 flex items-center justify-between text-xs">
    <div class="flex items-center gap-2">
      <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
      <span class="font-bold text-[#e2a545]">𝙓𝙑 Autonomous Agent</span>
      <span class="text-[#7f7a70]">• ڕەنکراو لە پۆڕتی 3000 (0.8s)</span>
    </div>
    <div class="text-[11px] bg-[#1a1b26] px-2.5 py-0.5 rounded-full border border-emerald-500/30 text-emerald-400 font-mono">
      Status: 200 OK • Live
    </div>
  </div>

  <!-- Hero Section -->
  <header class="py-12 px-6 max-w-5xl mx-auto text-center">
    <div class="inline-flex items-center gap-2 bg-[#171822] border border-[#e2a545]/40 text-[#e2a545] px-3.5 py-1 rounded-full text-xs font-black mb-4">
      ⚡ دیزاین و باکیند و داتابەیسی سەربەخۆ
    </div>
    <h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight mb-4 text-white leading-tight">
      ${title}
    </h1>
    <p class="text-sm sm:text-base text-[#a09a8e] max-w-2xl mx-auto leading-relaxed mb-8">
      ${desc}
    </p>
    <div class="flex flex-wrap items-center justify-center gap-3">
      <button onclick="alert('سوپاس بۆ کارلێککردن لەگەڵ ئەم وێبسایتە ڕەنکراوە!')" class="accent-gradient text-black font-extrabold px-6 py-3 rounded-xl shadow-lg hover:opacity-90 transition transform active:scale-95 cursor-pointer text-sm">
        دەستپێکردنی ڕاستەوخۆ 🚀
      </button>
      <button onclick="document.getElementById('features-sec').scrollIntoView({ behavior: 'smooth' })" class="bg-[#191b26] border border-[#2b2d3d] hover:border-[#e2a545]/60 text-white font-bold px-5 py-3 rounded-xl transition text-sm">
        بینینی خزمەتگوزارییەکان
      </button>
    </div>
  </header>

  <!-- Interactive Grid Cards -->
  <section id="features-sec" class="max-w-5xl mx-auto px-6 py-8 grid grid-cols-1 sm:grid-cols-3 gap-5">
    <div class="bg-[#12131b] border border-[#232431] p-5 rounded-2xl hover:border-[#e2a545]/50 transition">
      <div class="text-2xl mb-2">⚡</div>
      <h3 class="font-bold text-white text-base mb-1">خێرایی و کارامەیی بێهاوتا</h3>
      <p class="text-xs text-[#8c867a] leading-relaxed">کۆدکراو بە ستانداردی مۆدێرنی لە کەمتر لە ٥ خولەکدا.</p>
    </div>
    <div class="bg-[#12131b] border border-[#232431] p-5 rounded-2xl hover:border-[#e2a545]/50 transition">
      <div class="text-2xl mb-2">🛡️</div>
      <h3 class="font-bold text-white text-base mb-1">پارێزراوی لە ئاستی باڵا</h3>
      <p class="text-xs text-[#8c867a] leading-relaxed">بەربەستی Rate Limiter و ڕێگری لە هێرشی سایبەری بە ٥ خاڵەکە.</p>
    </div>
    <div class="bg-[#12131b] border border-[#232431] p-5 rounded-2xl hover:border-[#e2a545]/50 transition">
      <div class="text-2xl mb-2">📱</div>
      <h3 class="font-bold text-white text-base mb-1">دیزاینی تەواو ڕیسپۆنسیڤ</h3>
      <p class="text-xs text-[#8c867a] leading-relaxed">گونجاو لەگەڵ هەموو مۆبایل و تابلێت و کۆمپیوتەر بە دۆخی تاریک.</p>
    </div>
  </section>

  <!-- Interactive Counter / Cart Simulation -->
  <section class="max-w-md mx-auto px-6 py-6 text-center">
    <div class="bg-[#151620] border border-[#2a2c3c] rounded-2xl p-5 shadow-xl">
      <h4 class="text-xs font-bold text-[#e2a545] uppercase tracking-wider mb-2">کارلێکی ڕاستەوخۆ لە وێبسایتەکەدا</h4>
      <div class="text-2xl font-black text-white my-2" id="live-counter">١ داواکاری بەردەستە</div>
      <div class="flex items-center justify-center gap-2 mt-3">
        <button onclick="incrementOrder()" class="bg-[#e2a545] text-black font-bold text-xs px-4 py-2 rounded-lg cursor-pointer">
          + زیادکردن بۆ سەبەتە
        </button>
        <button onclick="resetOrder()" class="bg-[#242636] text-[#b0aba0] text-xs px-3 py-2 rounded-lg cursor-pointer">
          سڕینەوە
        </button>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-[#0c0d12] border-t border-[#1d1f2b] py-6 px-6 text-center text-xs text-[#6e685e]">
    دروستکراو و ڕەنکراو بە زیرەکی دەستکردی 𝙓𝙑-𝘼𝙄 لە کەمتر لە ٥ خولەک • All Rights Reserved.
  </footer>

  <script>
    let count = 1;
    function incrementOrder() {
      count++;
      document.getElementById('live-counter').innerText = count + ' بەرهەم لە سەبەتەدایە';
    }
    function resetOrder() {
      count = 0;
      document.getElementById('live-counter').innerText = 'سەبەتە بەتاڵە';
    }
  </script>
</body>
</html>`;
  };

  useEffect(() => {
    setGeneratedHtml(
      generateDynamicHtml(
        'پلاتفۆرمی نایابی سەربەخۆ',
        'ئەم ماڵپەڕە بە تەواوی لەلایەن ئەیجنتی 𝙓𝙑 لە ماوەی کەمتر لە ٥ خولەک دروستکراوە، کۆدکراوە و ڕەنکراوە.'
      )
    );
  }, []);

  const handleStartBuild = () => {
    setIsBuilding(true);
    setHasCompleted(false);
    setBuildStep(1);
    setBuildProgress(10);

    // Step 1: Database & Planning
    setTimeout(() => {
      setBuildStep(2);
      setBuildProgress(35);
    }, 1200);

    // Step 2: Frontend & UI
    setTimeout(() => {
      setBuildStep(3);
      setBuildProgress(65);
    }, 2400);

    // Step 3: Backend & APIs
    setTimeout(() => {
      setBuildStep(4);
      setBuildProgress(88);
    }, 3600);

    // Step 4: Finalize & Run
    setTimeout(() => {
      setBuildStep(5);
      setBuildProgress(100);
      setIsBuilding(false);
      setHasCompleted(true);
      setActiveCodeTab('preview');

      const title = userPrompt.length > 30 ? userPrompt.slice(0, 30) + '...' : userPrompt;
      setGeneratedHtml(
        generateDynamicHtml(
          title || 'وێبسایتی ڕەنکراوی 𝙓𝙑',
          `بەرهەمهێنراو لە کەمتر لە ٥ دەقە لەسەر بنەمای داواکاری: "${userPrompt}" لەگەڵ فرۆنت ئیند، باکیند و دەیتابەیسی تەواو کارا.`
        )
      );
    }, 4800);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generatedHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([generatedHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'xv-agent-generated-website.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in text-[#f2ede4]"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      <div className="bg-[#101116] border border-[#e2a545]/50 w-full max-w-5xl h-[92vh] rounded-3xl flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2b2a26] flex items-center justify-between bg-[#15161e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#e2a545]/20 to-[#f5c46b]/20 border border-[#e2a545]/50 flex items-center justify-center text-[#e2a545] shadow-md">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm sm:text-base text-white">
                  {lang === 'en'
                    ? '𝙓𝙑 Agent AI • Autonomous Web Builder & Runner'
                    : lang === 'ar'
                    ? '𝙓𝙑 Agent AI • بناء وتشغيل المواقع ذاتياً'
                    : '𝙓𝙑 Agent AI • دروستکردن و ڕەنکردنی خۆکاری وێبسایت'}
                </h3>
                <span className="bg-[#e2a545] text-black text-[10px] font-black px-2 py-0.5 rounded-full">
                  &lt; 5 MIN
                </span>
              </div>
              <p className="text-[11px] text-[#9e978c] mt-0.5">
                {lang === 'en'
                  ? 'You just ask, VX prepares and runs it for you — Any website in under 5 minutes!'
                  : lang === 'ar'
                  ? 'أنت فقط تطلب، وVX يجهز لك الموقع ويشغّله فوراً خلال أقل من 5 دقائق!'
                  : 'تۆ تەنها داوا ئەکەی، ڤی ئێکس خۆی بۆت ئامادە ئەکات و ڕەنیشی ئەکات!'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Builder Toolbar & Prompt Bar */}
        <div className="p-3 sm:p-4 bg-[#14151e] border-b border-[#252632] flex flex-col gap-2.5">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="flex-1 relative">
              <input
                type="text"
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                placeholder={
                  lang === 'en'
                    ? 'Describe any website (e.g. Luxury clothing shop, online academy, tech agency)...'
                    : lang === 'ar'
                    ? 'صف أي موقع تريده (مثلاً: متجر إلكتروني، أكاديمية تعليمية، موقع شركة)...'
                    : 'هەر وێبسایتێک پێت خۆشە بنووسە (بۆ نموونە: فرۆشگای ئۆنلاین، پلاتفۆرمی فێرکاری، چێشتخانە)...'
                }
                disabled={isBuilding}
                className="w-full bg-[#1b1c28] border border-[#2e3042] focus:border-[#e2a545] text-xs sm:text-sm px-3.5 py-2.5 rounded-xl text-[#f2ede4] outline-none"
              />
            </div>

            <button
              onClick={handleStartBuild}
              disabled={isBuilding || !userPrompt.trim()}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f5b85a] hover:opacity-95 text-black font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50 shrink-0"
            >
              {isBuilding ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  <span>{lang === 'en' ? 'Building & Running...' : lang === 'ar' ? 'جارِ البناء والتشغيل...' : 'خەریکی ئامادەکردن و ڕەنکردنە...'}</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-current" />
                  <span>{lang === 'en' ? 'Run Website (< 5 Mins)' : lang === 'ar' ? 'تشغيل الموقع (< 5 دقائق)' : 'ڕەنکردنی وێبسایت (< ٥ دەقە)'}</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1 text-[11px]">
            <span className="text-[#787267] font-bold shrink-0">
              {lang === 'en' ? 'Quick Ideas:' : lang === 'ar' ? 'أفكار جاهزة:' : 'بیرۆکە ئامادەکراوەکان:'}
            </span>
            {TEMPLATES.map((tpl) => (
              <button
                key={tpl.id}
                onClick={() => setUserPrompt(tpl.promptKu)}
                className="bg-[#1b1c27] hover:bg-[#252737] border border-[#2b2d3e] hover:border-[#e2a545]/60 text-[#d5cfc4] px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer"
              >
                {lang === 'en' ? tpl.titleEn : lang === 'ar' ? tpl.titleAr : tpl.titleKu}
              </button>
            ))}
          </div>
        </div>

        {/* Build Progress Indicator (if active) */}
        {isBuilding && (
          <div className="p-4 bg-[#171926] border-b border-[#2b2d3e] animate-fade-in">
            <div className="flex items-center justify-between text-xs font-bold mb-2">
              <span className="text-[#e2a545] flex items-center gap-2">
                <Sparkles className="w-4 h-4 animate-spin" />
                {buildStep === 1 && '🧠 قۆناغی ١: شیکاری داتابەیس و پلان (Database Schemas)...'}
                {buildStep === 2 && '🎨 قۆناغی ٢: دیزاین و فرۆنت ئیند (Responsive Tailwind UI)...'}
                {buildStep === 3 && '⚙️ قۆناغی ٣: نووسینی باکیند و ڕاوتەکان (Express Backend API)...'}
                {buildStep >= 4 && '🚀 قۆناغی ٤: ڕەنکردن و هێنانە سەر خەتی وێبسایت بە کەمتر لە ٥ دەقە!'}
              </span>
              <span className="font-mono text-emerald-400">{buildProgress}%</span>
            </div>
            <div className="w-full bg-[#202230] h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#e2a545] to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${buildProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Main Work Area: Sub-header Controls */}
        <div className="px-4 py-2 border-b border-[#212330] bg-[#12131b] flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setActiveCodeTab('preview')}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeCodeTab === 'preview'
                  ? 'bg-[#e2a545] text-black'
                  : 'bg-[#1b1c28] text-[#9c9689] hover:text-white'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>{lang === 'en' ? 'Live Interactive Preview' : lang === 'ar' ? 'المعاينة المباشرة' : 'پێشبینینی کارای ڕاستەوخۆ'}</span>
            </button>

            <button
              onClick={() => setActiveCodeTab('frontend')}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeCodeTab === 'frontend'
                  ? 'bg-[#e2a545] text-black'
                  : 'bg-[#1b1c28] text-[#9c9689] hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>UI Code (React)</span>
            </button>

            <button
              onClick={() => setActiveCodeTab('backend')}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeCodeTab === 'backend'
                  ? 'bg-[#e2a545] text-black'
                  : 'bg-[#1b1c28] text-[#9c9689] hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Backend (Express)</span>
            </button>

            <button
              onClick={() => setActiveCodeTab('schema')}
              className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeCodeTab === 'schema'
                  ? 'bg-[#e2a545] text-black'
                  : 'bg-[#1b1c28] text-[#9c9689] hover:text-white'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Database</span>
            </button>
          </div>

          {/* Device Switcher (when in preview) */}
          {activeCodeTab === 'preview' && (
            <div className="flex items-center gap-1 bg-[#1a1b25] p-1 rounded-xl border border-[#2b2c3d]">
              <button
                onClick={() => setDeviceView('desktop')}
                title="Desktop View"
                className={`p-1.5 rounded-lg transition ${
                  deviceView === 'desktop' ? 'bg-[#e2a545] text-black' : 'text-[#8b8579] hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setDeviceView('tablet')}
                title="Tablet View"
                className={`p-1.5 rounded-lg transition ${
                  deviceView === 'tablet' ? 'bg-[#e2a545] text-black' : 'text-[#8b8579] hover:text-white'
                }`}
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setDeviceView('mobile')}
                title="Mobile View"
                className={`p-1.5 rounded-lg transition ${
                  deviceView === 'mobile' ? 'bg-[#e2a545] text-black' : 'text-[#8b8579] hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyCode}
              className="px-2.5 py-1 rounded-lg bg-[#1e202d] hover:bg-[#282a3c] border border-[#323447] text-[#c9c3b7] text-[11px] font-bold flex items-center gap-1 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'کۆپیکرا' : 'کۆپیکردنی کۆد'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-2.5 py-1 rounded-lg bg-[#1e202d] hover:bg-[#282a3c] border border-[#323447] text-[#c9c3b7] text-[11px] font-bold flex items-center gap-1 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>داگرتن (.html)</span>
            </button>
          </div>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 overflow-hidden bg-[#0a0a0f] relative flex items-center justify-center p-2 sm:p-4">
          {activeCodeTab === 'preview' && (
            <div
              className={`h-full bg-white transition-all duration-300 rounded-2xl overflow-hidden shadow-2xl border border-[#2b2d3d] flex flex-col ${
                deviceView === 'desktop'
                  ? 'w-full'
                  : deviceView === 'tablet'
                  ? 'w-[768px]'
                  : 'w-[375px]'
              }`}
            >
              <iframe
                title="Generated Autonomous Website"
                srcDoc={generatedHtml}
                className="w-full h-full border-none"
                sandbox="allow-scripts allow-modals allow-forms"
              />
            </div>
          )}

          {activeCodeTab === 'frontend' && (
            <div className="w-full h-full overflow-y-auto p-4 font-mono text-xs text-emerald-300 bg-[#0e1017] rounded-2xl border border-[#252737] leading-relaxed">
              <pre>{`// Autonomous Full-Stack Generated Frontend
// Model: 𝙓𝙑-843B Cyber Agent (Under 5 Minutes Pipeline)

import React, { useState } from 'react';

export default function AutonomousGeneratedApp() {
  const [cart, setCart] = useState([]);
  const [theme, setTheme] = useState('dark');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6">
      <header className="max-w-6xl mx-auto flex items-center justify-between pb-6 border-b border-slate-800">
        <h1 className="text-2xl font-black text-amber-400">𝙓𝙑 Auto Web</h1>
        <nav className="flex items-center gap-4 text-sm">
          <a href="#services">خزمەتگوزارییەکان</a>
          <a href="#about">دەربارە</a>
          <button className="bg-amber-400 text-black px-4 py-1.5 rounded-lg font-bold">
            داواکاری خێرا
          </button>
        </nav>
      </header>
      <main className="max-w-4xl mx-auto py-12 text-center">
        <h2 className="text-4xl font-extrabold mb-4">${userPrompt}</h2>
        <p className="text-slate-400 max-w-xl mx-auto">
          دروستکراو و ڕەنکراو بە تەواوی سەربەخۆ لە کەمتر لە ٥ خولەک.
        </p>
      </main>
    </div>
  );
}`}</pre>
            </div>
          )}

          {activeCodeTab === 'backend' && (
            <div className="w-full h-full overflow-y-auto p-4 font-mono text-xs text-amber-300 bg-[#0e1017] rounded-2xl border border-[#252737] leading-relaxed">
              <pre>{`// Express Server API Endpoints
// Running live on port 3000

import express from 'express';
const app = express();
app.use(express.json());

// Autonomous Endpoints
app.get('/api/v1/catalog', (req, res) => {
  res.json({
    status: 'success',
    generator: 'XV-Agent-5Min',
    data: [
      { id: '1', title: 'خزمەتگوزاری سەرەکی', status: 'Active' },
      { id: '2', title: 'مۆدیۆلی بەڕێوەبردن', status: 'Live' }
    ]
  });
});

app.post('/api/v1/orders', (req, res) => {
  const { customer, items } = req.body;
  res.status(201).json({
    orderId: 'ORD-' + Date.now(),
    message: 'داواکارییەکە بە سەرکەوتوویی تۆمارکرا'
  });
});

app.listen(3000, () => {
  console.log('⚡ Autonomous Website active on port 3000');
});`}</pre>
            </div>
          )}

          {activeCodeTab === 'schema' && (
            <div className="w-full h-full overflow-y-auto p-4 font-mono text-xs text-blue-300 bg-[#0e1017] rounded-2xl border border-[#252737] leading-relaxed">
              <pre>{`-- PostgreSQL Database Schemas
-- Generated by 𝙓𝙑 Agent Full-Stack

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  role VARCHAR(50) DEFAULT 'customer',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  total_amount NUMERIC(10, 2) NOT NULL,
  currency VARCHAR(10) DEFAULT 'IQD',
  status VARCHAR(50) DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_orders_user ON orders(user_id);`}</pre>
            </div>
          )}
        </div>

        {/* Footer Note */}
        <div className="p-3 border-t border-[#232431] bg-[#13141c] flex items-center justify-between text-xs text-[#827d72]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>
              {lang === 'en'
                ? 'Autonomous Execution Engine: Zero Manual Config Required'
                : lang === 'ar'
                ? 'محرك تشغيل ذاتي: لا حاجة لأي إعدادات يدوية'
                : 'سیستەمی ڕەنکردنی خۆکار: بەبێ پێویستی بە دەستکاری دەستی لە کەمتر لە ٥ دەقەدا'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#222330] hover:bg-[#2c2d3d] text-white font-bold transition cursor-pointer text-xs"
          >
            {translations[lang].close}
          </button>
        </div>
      </div>
    </div>
  );
};
