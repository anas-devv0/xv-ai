import React, { useState, useEffect, useRef } from 'react';
import { ArrowUp, Check, X as XIcon, FolderArchive, Sparkles, Terminal as TerminalIcon, Globe, MapPin, Shield } from 'lucide-react';

interface Props {
  onOpenChat: (initialPrompt?: string) => void;
  onOpenLocationRecon: () => void;
  onDownloadZip: () => void;
  isSignedIn?: boolean;
}

const scenes = [
  [
    { t: 'prompt', text: '$ ember chat "fix this cors error in fastapi"' },
    { t: 'out', text: 'reading traceback...' },
    { t: 'out', text: 'add CORSMiddleware before your routes:' },
    { t: 'out', text: 'app.add_middleware(CORSMiddleware, allow_origins=["*"])' },
    { t: 'ok', text: '✓ patched app/main.py' },
  ],
  [
    { t: 'prompt', text: '$ ember chat "wergêr bike bo kurdî: welcome back"' },
    { t: 'out', text: 'detecting language... sorani' },
    { t: 'ok', text: '→ "بەخێربێیتەوە"' },
  ],
  [
    { t: 'prompt', text: '$ ember agent run --task "audit auth flow"' },
    { t: 'out', text: 'scanning routes/auth.py, models/user.py...' },
    { t: 'out', text: 'found 1 IDOR risk in GET /users/:id' },
    { t: 'ok', text: '✓ patch ready for review' },
  ],
];

const heroPrompts = [
  "Describe what you're stuck on...",
  "wergêr bike bo kurdî...",
  "fix this cors error in fastapi...",
  "draft a voice-call script...",
];

const faqs = [
  {
    q: 'How do I get access?',
    a: 'Tap Get started, sign in with Google, and complete the one-time onboarding. Paid plans unlock higher monthly usage.',
  },
  {
    q: 'Does it work in Kurdish?',
    a: 'Yes. Every plan speaks Kurdish Sorani. VX Pro and VX Pro Max also handle any other language you type, with the UI switching RTL or LTR to match.',
  },
  {
    q: 'How do monthly limits work?',
    a: 'Every plan has a token cap (what you type plus what VX replies, including thinking tokens on VX-843B). VX Mini is 869K tokens on VX-320B. VX Normal is 2.24M on VX-320B. VX Pro is 5.07M on VX-320B or 2.56M on VX-843B. VX Pro Max is 10.7M on VX-320B or 5.25M on VX-843B. They share one pool — mix models, but VX-843B uses the budget faster. Limits reset each month. Reply counts on the cards assume ~2,000 tokens per turn. If you already paid for a month, that period keeps the token amount from checkout. The larger pools apply to new purchases and to upgrades onto a different plan.',
  },
  {
    q: 'What are Geo /location limits?',
    a: 'Attach a photo and send /location. Mini has 0 tries. Normal has 1 try per month. Pro has 5 tries per week. Pro Max is unlimited. Tries only count when Geo succeeds.',
  },
  {
    q: 'What is website /web?',
    a: 'Send /web https://example.com in chat. VX snapshots that page plus linked CSS, JS, and images, then gives you a preview and a zip. Mini has 0 tries. Normal has 1 try per month. Pro has 5 tries per week. Pro Max is unlimited. Tries count when the snapshot succeeds. Preview and zip stay up about 30 minutes — download the zip to keep it.',
  },
  {
    q: 'Which model do I get?',
    a: 'VX Mini and VX Normal are chat on VX-320B (256K context), with no thinking trace and no VX-843B. VX Pro and VX Pro Max add the agent workspace, VX-843B Super Intelligent (1M context) with thinking style, and replies in any language including Kurdish Sorani.',
  },
  {
    q: 'Is it uncensored, and how big is the context?',
    a: 'Every plan is uncensored — 0 content filters. VX-320B (all plans) is 320B with a 256K context window. VX-843B Super Intelligent on Pro and Pro Max is 843B with a 1M context window. Monthly token caps are separate from how much the model can hold in one thread.',
  },
  {
    q: 'How do I pay, and who pays the fee?',
    a: 'Sign in with Google first, pick a plan, then pay in IQD on the checkout page (FIB, FastPay, ZainCash, QiCard, or card). Payment is always tied to your signed-in account. You pay package price + Wayl fee (2.5% + 600 IQD local) in one checkout total — for example VX Normal is 13,500 + 938 = 14,438 IQD.',
  },
];

export const VxLandingPage: React.FC<Props> = ({
  onOpenChat,
  onOpenLocationRecon,
  onDownloadZip,
  isSignedIn = true,
}) => {
  // Rotating hero placeholder
  const [heroPlaceholderIndex, setHeroPlaceholderIndex] = useState(0);
  const [heroInputValue, setHeroInputValue] = useState('');
  const [heroGateOpen, setHeroGateOpen] = useState(false);
  const [heroGateSecs, setHeroGateSecs] = useState(4);

  // Terminal typewriter animation state
  const [termLines, setTermLines] = useState<Array<{ t: string; text: string }>>([]);
  const [currentTypingText, setCurrentTypingText] = useState('');
  const [currentLineType, setCurrentLineType] = useState('prompt');

  // Accordion state
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Buy Gate modal
  const [buyGatePlan, setBuyGatePlan] = useState<string | null>(null);
  const [buyGateSecs, setBuyGateSecs] = useState(4);

  // Right-click toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Handle right-click deterrent
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      e.preventDefault();
      e.stopPropagation();

      setToastMessage("You can't do right click on my website, butty!");
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      toastTimerRef.current = setTimeout(() => {
        setToastMessage(null);
      }, 2800);
    };

    window.addEventListener('contextmenu', handleContextMenu, true);
    return () => window.removeEventListener('contextmenu', handleContextMenu, true);
  }, []);

  // Placeholder rotation
  useEffect(() => {
    const interval = setInterval(() => {
      setHeroPlaceholderIndex((prev) => (prev + 1) % heroPrompts.length);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  // Terminal scene simulation loop
  useEffect(() => {
    let isCancelled = false;
    let sceneIndex = 0;

    const runTerminalLoop = async () => {
      while (!isCancelled) {
        const scene = scenes[sceneIndex];
        setTermLines([]);
        setCurrentTypingText('');

        for (const line of scene) {
          if (isCancelled) return;
          setCurrentLineType(line.t);
          setCurrentTypingText('');

          // Type line character by character
          const speed = line.t === 'prompt' ? 26 : 10;
          for (let i = 0; i <= line.text.length; i++) {
            if (isCancelled) return;
            setCurrentTypingText(line.text.slice(0, i));
            await new Promise((r) => setTimeout(r, speed));
          }

          // Commit typed line to terminal
          setTermLines((prev) => [...prev, { t: line.t, text: line.text }]);
          setCurrentTypingText('');
          await new Promise((r) => setTimeout(r, 280));
        }

        // Pause before clearing for next scene
        await new Promise((r) => setTimeout(r, 1600));
        sceneIndex = (sceneIndex + 1) % scenes.length;
      }
    };

    runTerminalLoop();
    return () => {
      isCancelled = true;
    };
  }, []);

  // Handle hero form submit
  const handleHeroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const prompt = heroInputValue.trim();
    if (!prompt) {
      onOpenChat();
      return;
    }
    onOpenChat(prompt);
  };

  // Handle plan purchase click
  const handlePlanClick = (planId: string) => {
    setBuyGatePlan(planId);
    setBuyGateSecs(4);
    const timer = setInterval(() => {
      setBuyGateSecs((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onOpenChat(`I would like to activate the ${planId.toUpperCase()} package`);
          setBuyGatePlan(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="relative min-h-screen bg-[#111110] text-[#f2ede4] font-['Inter',system-ui,sans-serif]">
      {/* Background glow and dot texture */}
      <div className="bg-fx">
        <div className="bg-glow"></div>
        <div className="bg-dots"></div>
      </div>

      {/* Sticky Navigation */}
      <nav className="sticky top-0 z-40 bg-[#111110]/80 backdrop-blur-md border-b border-[#201f1c]">
        <div className="wrap flex items-center justify-between h-16">
          <a className="brand flex items-center gap-2.5 font-medium text-[15px]" href="#top">
            <span className="brand-mark w-[26px] h-[26px] rounded-[7px] bg-[#e2a545] flex items-center justify-center text-[#191204] font-['Newsreader'] italic font-medium text-[15px]">
              V
            </span>
            <span>VX</span>
          </a>

          <div className="nav-links hidden md:flex items-center gap-7 text-[13.5px] text-[#b3ac9f]">
            <a href="#features" className="hover:text-[#f2ede4] transition-colors">Features</a>
            <a href="#model" className="hover:text-[#f2ede4] transition-colors">Vela model</a>
            <a href="#pricing" className="hover:text-[#f2ede4] transition-colors">Pricing</a>
            <a href="/vx/docs" target="_blank" rel="noreferrer" className="hover:text-[#f2ede4] transition-colors">API</a>
            <a href="#faq" className="hover:text-[#f2ede4] transition-colors">FAQ</a>
          </div>

          <div className="nav-cta flex items-center gap-2.5 sm:gap-3.5">
            {/* Direct ZIP download button */}
            <button
              onClick={onDownloadZip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-[#1d1c19] border border-[#e2a545]/40 text-[#f0c37c] hover:bg-[#232220] transition shadow-sm cursor-pointer"
              title="داگرتنی هەموو فایلەکانی وێبسایتەکە بە ZIP"
            >
              <FolderArchive className="w-3.5 h-3.5 text-[#e2a545]" />
              <span className="hidden sm:inline">داگرتنی ZIP</span>
              <span className="sm:hidden">ZIP</span>
            </button>

            <button
              onClick={() => onOpenChat()}
              className="btn btn-primary bg-[#e2a545] hover:bg-[#f0c37c] text-[#191204] font-medium text-[13.5px] px-4 py-2 rounded-[9px] transition cursor-pointer shadow"
            >
              Open chat
            </button>
          </div>
        </div>
      </nav>

      {/* Free Testing Event Bar */}
      <div className="event-bar open border-b border-[#201f1c] bg-[#171715]" id="event-bar">
        <div className="wrap flex items-center justify-between gap-4 py-3.5 flex-wrap">
          <div className="text-[13.5px] text-[#b3ac9f] flex items-center flex-wrap gap-2">
            <span className="event-pill bg-[#e2a545]/20 text-[#f0c37c] px-2 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider">
              On
            </span>
            <span>
              Free testing is live on <strong className="text-[#f2ede4]">VX-320B</strong>. Today · Iraq time · 2 hours. Sign in and chat until this is turned off.
            </span>
          </div>
          <button
            onClick={() => onOpenChat()}
            className="btn btn-primary bg-[#e2a545] hover:bg-[#f0c37c] text-[#191204] font-medium text-[13px] px-4 py-1.5 rounded-[9px] transition cursor-pointer"
          >
            Open chat
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <header className="hero py-16 md:py-20" id="top">
        <div className="wrap hero-grid grid grid-cols-1 lg:grid-cols-[1fr_0.92fr] gap-12 items-start">
          <div className="hero-copy">
            <div className="eyebrow inline-flex items-center gap-2 text-xs text-[#b3ac9f] border border-[#2b2a26] px-3 py-1 rounded-full mb-6">
              <span className="dot w-1.5 h-1.5 rounded-full bg-[#e2a545] shadow-[0_0_0_3px_rgba(226,165,69,0.18)]"></span>
              <span>Now speaking Kurdish and English</span>
            </div>

            <h1 className="serif text-4xl sm:text-5xl font-normal italic text-[#f2ede4] mb-4 leading-tight">
              What are we building today
            </h1>

            <p className="text-[15.5px] text-[#b3ac9f] max-w-[460px] mb-7 leading-relaxed">
              Chat, voice, and agent tools tuned for builders — ask in Kurdish or English and get a direct answer, not a lecture.
            </p>

            {/* Interactive Hero Input */}
            <form onSubmit={handleHeroSubmit} className="hero-input flex items-center gap-2 max-w-[460px] bg-[#171715] border border-[#2b2a26] rounded-2xl p-1.5 pl-4 mb-3.5 transition focus-within:border-[#4a3a22] shadow-lg">
              <input
                type="text"
                value={heroInputValue}
                onChange={(e) => setHeroInputValue(e.target.value)}
                placeholder={heroPrompts[heroPlaceholderIndex]}
                maxLength={4000}
                aria-label="Ask VX"
                className="flex-1 min-w-0 bg-transparent border-none outline-none text-[14px] text-[#f2ede4] placeholder-[#726c62] text-left"
              />
              <button
                type="submit"
                aria-label="Send"
                className="go w-8 h-8 rounded-full bg-[#e2a545] hover:bg-[#f0c37c] flex items-center justify-center text-[#191204] shrink-0 transition cursor-pointer"
              >
                <ArrowUp className="w-4 h-4 stroke-[2.5]" />
              </button>
            </form>

            <div className="hero-subcta text-xs text-[#726c62] mb-9">
              No invite list — type a question, send it, then sign in to read the answer.
            </div>

            {/* Stat Row */}
            <div className="stat-row flex gap-8 sm:gap-10 flex-wrap">
              <div className="stat">
                <div className="num font-['Newsreader'] italic text-2xl text-[#e2a545]">0</div>
                <div className="label text-[11.5px] text-[#726c62] mt-0.5">content filters</div>
              </div>
              <div className="stat">
                <div className="num font-['Newsreader'] italic text-2xl text-[#e2a545]">Live</div>
                <div className="label text-[11.5px] text-[#726c62] mt-0.5">streaming replies</div>
              </div>
              <div className="stat">
                <div className="num font-['Newsreader'] italic text-2xl text-[#e2a545]">RTL</div>
                <div className="label text-[11.5px] text-[#726c62] mt-0.5">native Kurdish layout</div>
              </div>
            </div>
          </div>

          {/* Animated Terminal Mockup */}
          <div className="term-wrap relative">
            <div className="term-glow absolute -inset-8 rounded-3xl bg-[radial-gradient(closest-side,rgba(226,165,69,0.12),transparent_70%)] -z-10 pointer-events-none"></div>
            <div className="terminal bg-[#0d0d0c] border border-[#2b2a26] rounded-xl overflow-hidden shadow-2xl">
              <div className="term-bar flex items-center gap-1.5 px-3.5 py-2.5 border-b border-[#201f1c]">
                <span className="term-dot r w-2.5 h-2.5 rounded-full bg-[#e5716a]"></span>
                <span className="term-dot y w-2.5 h-2.5 rounded-full bg-[#e2b34a]"></span>
                <span className="term-dot g w-2.5 h-2.5 rounded-full bg-[#6fbf73]"></span>
                <span className="term-title mono ml-2 text-[11.5px] text-[#726c62]">ember — vela-1</span>
              </div>
              <div className="term-body mono p-5 min-h-[260px] text-[13px] leading-relaxed">
                {termLines.map((line, idx) => (
                  <div
                    key={idx}
                    className={`term-line whitespace-pre-wrap break-words ${
                      line.t === 'prompt' ? 'text-[#e2a545]' : line.t === 'ok' ? 'text-[#7fb87a]' : 'text-[#b3ac9f]'
                    }`}
                  >
                    {line.text}
                  </div>
                ))}
                {currentTypingText && (
                  <div
                    className={`term-line whitespace-pre-wrap break-words inline-block ${
                      currentLineType === 'prompt' ? 'text-[#e2a545]' : currentLineType === 'ok' ? 'text-[#7fb87a]' : 'text-[#b3ac9f]'
                    }`}
                  >
                    {currentTypingText}
                    <span className="cursor inline-block w-1.5 h-3.5 bg-[#e2a545] align-middle ml-0.5 animate-pulse"></span>
                  </div>
                )}
                {!currentTypingText && (
                  <span className="cursor inline-block w-1.5 h-3.5 bg-[#e2a545] align-middle ml-0.5 animate-pulse"></span>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section id="features" className="py-20 border-t border-[#201f1c]">
        <div className="wrap">
          <div className="section-head max-w-[560px] mb-12">
            <div className="kicker text-xs text-[#e2a545] mb-2.5 uppercase tracking-wider font-semibold">What you get</div>
            <h2 className="text-3xl text-[#f2ede4] font-normal font-['Newsreader'] italic">Built for people shipping things.</h2>
            <p className="text-[#b3ac9f] mt-2.5 text-[14.5px]">
              Not a demo. A working chat, voice, and agent stack tuned for how you actually build.
            </p>
          </div>

          <div className="feat-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-[#201f1c] border border-[#201f1c] rounded-2xl overflow-hidden shadow-xl">
            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">01</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Full-stack answers</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Debug endpoints, review architecture, ship features — without the model second-guessing your stack.
              </p>
            </div>

            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">02</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Kurdish-first chat</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Auto-detects Sorani or English per message and lays the UI out RTL or LTR to match.
              </p>
            </div>

            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">03</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Voice mode</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Call in and talk through a problem live — same context carries over into the chat thread.
              </p>
            </div>

            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">04</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Streaming replies</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Token-by-token output in a composer that keeps model picker and history one tap away.
              </p>
            </div>

            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">05</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Session memory</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Threads persist to your account — pick a build back up without re-explaining the context.
              </p>
            </div>

            <div className="feat bg-[#111110] p-7 hover:bg-[#171715] transition-colors">
              <div className="n font-['Newsreader'] italic text-[#e2a545] text-base mb-4">06</div>
              <h3 className="text-base text-[#f2ede4] font-medium mb-2">Usage you control</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Start on VX Mini or VX Normal. VX Pro and VX Pro Max add the agent, VX-843B, thinking, and every language including Kurdish Sorani.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Model Spotlight Section */}
      <section id="model" className="py-20 border-t border-[#201f1c]">
        <div className="wrap spotlight grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
          <div className="spotlight-copy">
            <div className="kicker text-xs text-[#e2a545] mb-2.5 uppercase tracking-wider font-semibold">The model</div>
            <h2 className="serif text-3xl font-normal italic text-[#f2ede4]">One model. No refusals on real dev work.</h2>
            <p className="text-[#b3ac9f] text-[14.5px] my-4 leading-relaxed max-w-[440px]">
              Tuned for code, Kurdish translation, and long technical threads. Keeps context across sessions and powers chat, voice, and the agent workspace.
            </p>

            <div className="spot-stats grid grid-cols-2 gap-px bg-[#201f1c] border border-[#201f1c] rounded-2xl overflow-hidden mt-6">
              <div className="spot-stat bg-[#171715] p-5">
                <div className="val font-['Newsreader'] italic text-[#e2a545] text-xl">320B</div>
                <div className="lab text-[11.5px] text-[#726c62] mt-1">VX · 256K context</div>
              </div>
              <div className="spot-stat bg-[#171715] p-5">
                <div className="val font-['Newsreader'] italic text-[#e2a545] text-xl">843B</div>
                <div className="lab text-[11.5px] text-[#726c62] mt-1">VX-843B · 1M context</div>
              </div>
              <div className="spot-stat bg-[#171715] p-5">
                <div className="val font-['Newsreader'] italic text-[#e2a545] text-xl">0</div>
                <div className="lab text-[11.5px] text-[#726c62] mt-1">content filters</div>
              </div>
              <div className="spot-stat bg-[#171715] p-5">
                <div className="val font-['Newsreader'] italic text-[#e2a545] text-xl">Direct</div>
                <div className="lab text-[11.5px] text-[#726c62] mt-1">uncensored replies</div>
              </div>
            </div>
          </div>

          <div className="code-block mono bg-[#0d0d0c] border border-[#2b2a26] rounded-xl p-5 text-[12.5px] leading-loose overflow-x-auto shadow-2xl">
            <span className="text-[#726c62]">$ </span>
            <span className="text-[#e2a545]">curl </span>
            <span className="text-[#b3ac9f]">https://api.ember.dev/v1/chat \</span>
            <br />
            <span className="text-[#b3ac9f]"> -H "Authorization: Bearer $EMBER_KEY" \</span>
            <br />
            <span className="text-[#b3ac9f]"> -d '{'{"model":"vela-1","stream":true,'}</span>
            <br />
            <span className="text-[#b3ac9f]">{'     "messages":[{"role":"user",'}</span>
            <br />
            <span className="text-[#b3ac9f]">{'     "content":"bişêwirî min bike"}]}'}</span>
            <br />
            <span className="text-[#726c62]">→ </span>
            <span className="text-[#7fb87a]">streaming 12 tok/s · ctx 256k · sorani detected</span>
          </div>
        </div>
      </section>

      {/* How it works (3 Steps) */}
      <section id="how" className="py-20 border-t border-[#201f1c]">
        <div className="wrap">
          <div className="section-head max-w-[560px] mb-12">
            <div className="kicker text-xs text-[#e2a545] mb-2.5 uppercase tracking-wider font-semibold">Getting started</div>
            <h2 className="text-3xl text-[#f2ede4] font-normal font-['Newsreader'] italic">Three steps to your first reply.</h2>
          </div>

          <div className="steps grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="step bg-[#171715]/40 border border-[#201f1c] rounded-2xl p-6">
              <div className="idx w-8 h-8 rounded-full border border-[#4a3a22] text-[#e2a545] flex items-center justify-center text-xs font-semibold mb-4">
                1
              </div>
              <h3 className="text-[15.5px] text-[#f2ede4] font-medium mb-1.5">Sign in with Google</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                No invite list. Confirm your account once and you're in.
              </p>
            </div>

            <div className="step bg-[#171715]/40 border border-[#201f1c] rounded-2xl p-6">
              <div className="idx w-8 h-8 rounded-full border border-[#4a3a22] text-[#e2a545] flex items-center justify-center text-xs font-semibold mb-4">
                2
              </div>
              <h3 className="text-[15.5px] text-[#f2ede4] font-medium mb-1.5">Open chat</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                Pick a model, type in the composer, and stream your first answer.
              </p>
            </div>

            <div className="step bg-[#171715]/40 border border-[#201f1c] rounded-2xl p-6">
              <div className="idx w-8 h-8 rounded-full border border-[#4a3a22] text-[#e2a545] flex items-center justify-center text-xs font-semibold mb-4">
                3
              </div>
              <h3 className="text-[15.5px] text-[#f2ede4] font-medium mb-1.5">Upgrade when ready</h3>
              <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed">
                VX Pro and VX Pro Max unlock the agent, thinking style on VX-843B, and a bigger monthly token cap.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 border-t border-[#201f1c]">
        <div className="wrap">
          <div className="section-head max-w-[560px] mb-12">
            <div className="kicker text-xs text-[#e2a545] mb-2.5 uppercase tracking-wider font-semibold">Pricing</div>
            <h2 className="text-3xl text-[#f2ede4] font-normal font-['Newsreader'] italic">Four monthly plans. Pick a lane.</h2>
            <p className="text-[#b3ac9f] mt-2.5 text-[14.5px]">
              Billed once a month. Token limits reset every 30 days. Geo <code>/location</code> and website <code>/web</code> are separate: Mini 0 · Normal 1/month · Pro 5/week · Pro Max unlimited.
            </p>
          </div>

          <div className="price-grid grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3 items-start">
            {/* Plan 1: Mini */}
            <div className="price-card bg-[#171715] border border-[#2b2a26] rounded-2xl p-5 flex flex-col hover:border-[#4a3a22] transition shadow-lg">
              <div className="tier text-[13px] text-[#b3ac9f] mb-2.5">VX Mini</div>
              <div className="amount font-['Newsreader'] italic text-3xl text-[#f2ede4]">
                $5<span className="text-[13px] text-[#726c62] font-['Inter'] not-italic">/mo</span>
              </div>
              <div className="deal-row flex flex-wrap gap-1.5 mt-2.5">
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  49% off
                </span>
              </div>
              <div className="iqd text-[13px] text-[#e2a545] font-medium mt-1.5">7,500 IQD</div>
              <p className="fee text-[11.5px] text-[#726c62] mt-2 leading-tight">Checkout total 8,288 IQD (incl. Wayl fee 788)</p>

              <ul className="my-5 flex-1 space-y-2 text-[13px] text-[#b3ac9f]">
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>869K tokens / mo</strong> on VX-320B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>~430 typical replies</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-320B</strong> · 256K context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Uncensored — 0 content filters</span></li>
                <li className="flex items-center gap-2.5 text-[#726c62]"><XIcon className="w-4 h-4 text-[#8a5a5a] shrink-0" /> <span>Chat only — no agent, no thinking, no 843B</span></li>
                <li className="flex items-center gap-2.5 text-[#726c62]"><XIcon className="w-4 h-4 text-[#8a5a5a] shrink-0" /> <span><strong>Geo /location</strong> — 0 / week</span></li>
                <li className="flex items-center gap-2.5 text-[#726c62]"><XIcon className="w-4 h-4 text-[#8a5a5a] shrink-0" /> <span><strong>/web</strong> — 0</span></li>
              </ul>

              <button
                onClick={() => handlePlanClick('mini')}
                className="btn btn-outline border border-[#2b2a26] hover:bg-[#232220] text-[#f2ede4] font-medium text-[13.5px] py-2 px-4 rounded-[9px] transition cursor-pointer"
              >
                Sign in to buy VX Mini
              </button>
            </div>

            {/* Plan 2: Normal */}
            <div className="price-card bg-[#171715] border border-[#2b2a26] rounded-2xl p-5 flex flex-col hover:border-[#4a3a22] transition shadow-lg">
              <div className="tier text-[13px] text-[#b3ac9f] mb-2.5">VX Normal</div>
              <div className="amount font-['Newsreader'] italic text-3xl text-[#f2ede4]">
                $9<span className="text-[13px] text-[#726c62] font-['Inter'] not-italic">/mo</span>
              </div>
              <div className="deal-row flex flex-wrap gap-1.5 mt-2.5">
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  49% off
                </span>
              </div>
              <div className="iqd text-[13px] text-[#e2a545] font-medium mt-1.5">13,500 IQD</div>
              <p className="fee text-[11.5px] text-[#726c62] mt-2 leading-tight">Checkout total 14,438 IQD (incl. Wayl fee 938)</p>

              <ul className="my-5 flex-1 space-y-2 text-[13px] text-[#b3ac9f]">
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>2.24M tokens / mo</strong> on VX-320B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>~1,120 typical replies</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-320B</strong> · 256K context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Uncensored — 0 content filters</span></li>
                <li className="flex items-center gap-2.5 text-[#726c62]"><XIcon className="w-4 h-4 text-[#8a5a5a] shrink-0" /> <span>Chat only — no agent, no thinking trace</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Kurdish Sorani + English</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>Geo /location</strong> — 1 / month</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>/web</strong> — 1 / month</span></li>
              </ul>

              <button
                onClick={() => handlePlanClick('normal')}
                className="btn btn-outline border border-[#2b2a26] hover:bg-[#232220] text-[#f2ede4] font-medium text-[13.5px] py-2 px-4 rounded-[9px] transition cursor-pointer"
              >
                Sign in to buy VX Normal
              </button>
            </div>

            {/* Plan 3: Pro (Most popular) */}
            <div className="price-card pop relative bg-[#171715] border border-[#e2a545]/60 rounded-2xl p-5 flex flex-col shadow-2xl">
              <span className="pop-badge absolute -top-3 left-6 bg-[#e2a545] text-[#191204] text-[10.5px] px-2.5 py-0.5 rounded-full font-bold">
                Most popular
              </span>
              <div className="tier text-[13px] text-[#b3ac9f] mb-2.5">VX Pro</div>
              <div className="amount font-['Newsreader'] italic text-3xl text-[#f2ede4]">
                $19<span className="text-[13px] text-[#726c62] font-['Inter'] not-italic">/mo</span>
              </div>
              <div className="deal-row flex flex-wrap gap-1.5 mt-2.5">
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  49% off VX-320B
                </span>
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  22% off VX-843B
                </span>
              </div>
              <div className="iqd text-[13px] text-[#e2a545] font-medium mt-1.5">28,500 IQD</div>
              <p className="fee text-[11.5px] text-[#726c62] mt-2 leading-tight">Checkout total 29,813 IQD (incl. Wayl fee 1,313)</p>

              <ul className="my-5 flex-1 space-y-2 text-[13px] text-[#b3ac9f]">
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>5.07M tokens</strong> on VX-320B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>or 2.56M tokens</strong> on VX-843B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>~2,500 replies · ~1,280 on 843B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-320B</strong> · 256K context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-843B</strong> · 1M context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Uncensored — 0 content filters</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Chat + agent workspace</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Thinking style on VX-843B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Switch models in thread</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>All languages (Kurdish Sorani)</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>Geo /location</strong> — 5 / week</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>/web</strong> — 5 / week</span></li>
              </ul>

              <button
                onClick={() => handlePlanClick('pro')}
                className="btn btn-primary bg-[#e2a545] hover:bg-[#f0c37c] text-[#191204] font-medium text-[13.5px] py-2 px-4 rounded-[9px] transition cursor-pointer shadow"
              >
                Sign in to buy VX Pro
              </button>
            </div>

            {/* Plan 4: Pro Max */}
            <div className="price-card bg-[#171715] border border-[#2b2a26] rounded-2xl p-5 flex flex-col hover:border-[#4a3a22] transition shadow-lg">
              <div className="tier text-[13px] text-[#b3ac9f] mb-2.5">VX Pro Max</div>
              <div className="amount font-['Newsreader'] italic text-3xl text-[#f2ede4]">
                $39<span className="text-[13px] text-[#726c62] font-['Inter'] not-italic">/mo</span>
              </div>
              <div className="deal-row flex flex-wrap gap-1.5 mt-2.5">
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  49% off VX-320B
                </span>
                <span className="deal text-[11px] font-semibold text-[#e2a545] bg-[#e2a545]/15 border border-[#4a3a22] px-2.5 py-1 rounded-full">
                  22% off VX-843B
                </span>
              </div>
              <div className="iqd text-[13px] text-[#e2a545] font-medium mt-1.5">58,500 IQD</div>
              <p className="fee text-[11.5px] text-[#726c62] mt-2 leading-tight">Checkout total 60,563 IQD (incl. Wayl fee 2,063)</p>

              <ul className="my-5 flex-1 space-y-2 text-[13px] text-[#b3ac9f]">
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>10.7M tokens</strong> on VX-320B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>or 5.25M tokens</strong> on VX-843B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>~5,360 replies · ~2,620 on 843B</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-320B</strong> · 256K context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>VX-843B</strong> · 1M context</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Uncensored — 0 content filters</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Chat + agent workspace</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Thinking style at max depth</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>Switch models in thread</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span>All languages (Kurdish Sorani)</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>Geo /location</strong> — unlimited</span></li>
                <li className="flex items-center gap-2.5"><Check className="w-4 h-4 text-[#e2a545] shrink-0" /> <span><strong>/web</strong> — unlimited</span></li>
              </ul>

              <button
                onClick={() => handlePlanClick('promax')}
                className="btn btn-outline border border-[#2b2a26] hover:bg-[#232220] text-[#f2ede4] font-medium text-[13.5px] py-2 px-4 rounded-[9px] transition cursor-pointer"
              >
                Sign in to buy VX Pro Max
              </button>
            </div>
          </div>

          <p className="price-fee-note mt-6 text-xs text-[#726c62] max-w-[720px] leading-relaxed">
            You must sign in with Google before you can pay — checkout is tied to your account. Charged in IQD at 1,500 IQD per $1. Checkout total = package + Wayl fee (2.5% + 600 IQD local). That fee is added on our payment link so you pay it with the plan.
          </p>

          {/* Buy Gate Modal / Inline Callout */}
          {buyGatePlan && (
            <div className="buy-gate open mt-5 p-4 border border-[#4a3a22] rounded-xl bg-[#171715] max-w-[520px] shadow-2xl animate-fade-in">
              <p className="text-[13.5px] text-[#b3ac9f] mb-2.5">
                Sign in with Google to buy <span className="plan-name text-[#e2a545] font-semibold">{buyGatePlan.toUpperCase()}</span>. After login we open checkout for your account.
              </p>
              <button
                onClick={() => {
                  onOpenChat(`I am ready to proceed with ${buyGatePlan.toUpperCase()}`);
                  setBuyGatePlan(null);
                }}
                className="btn btn-primary bg-[#e2a545] text-[#191204] font-medium text-xs px-4 py-2 rounded-lg cursor-pointer"
              >
                Sign in to pay
              </button>
              <div className="buy-gate-wait text-xs text-[#726c62] mt-2.5">
                Opening Google in <span className="text-[#e2a545] font-bold">{buyGateSecs}</span>s…
              </div>
            </div>
          )}
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 border-t border-[#201f1c]">
        <div className="wrap">
          <div className="section-head max-w-[560px] mb-12">
            <div className="kicker text-xs text-[#e2a545] mb-2.5 uppercase tracking-wider font-semibold">FAQ</div>
            <h2 className="text-3xl text-[#f2ede4] font-normal font-['Newsreader'] italic">Common questions</h2>
          </div>

          <div className="faq-list max-w-[680px]">
            {faqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className="faq-item border-b border-[#201f1c]">
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="faq-q w-full py-5 flex justify-between items-center cursor-pointer text-[14.5px] text-[#f2ede4] text-left hover:text-[#e2a545] transition-colors"
                  >
                    <span>{faq.q}</span>
                    <span
                      className={`plus text-lg transition-transform duration-200 ${
                        isOpen ? 'rotate-45 text-[#e2a545]' : 'text-[#726c62]'
                      }`}
                    >
                      +
                    </span>
                  </button>
                  {isOpen && (
                    <div className="faq-a pb-5 animate-fade-in">
                      <p className="text-[13.5px] text-[#b3ac9f] leading-relaxed max-w-[600px]">{faq.a}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="closing text-center py-24 border-t border-[#201f1c]">
        <div className="wrap">
          <h2 className="serif text-3xl sm:text-4xl italic max-w-[560px] mx-auto mb-7 text-[#f2ede4]">
            Your first reply is one sign-in away.
          </h2>
          <button
            onClick={() => onOpenChat()}
            className="btn btn-primary bg-[#e2a545] hover:bg-[#f0c37c] text-[#191204] font-medium text-sm px-6 py-3 rounded-xl transition cursor-pointer shadow-xl inline-flex items-center gap-2"
          >
            <span>Get started with Google</span>
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#201f1c] py-9">
        <div className="wrap flex justify-between items-center flex-wrap gap-4">
          <div className="foot-note text-xs text-[#726c62]">Ember — built for Kurdistan builders.</div>
          <div className="foot-links flex gap-5 text-xs text-[#b3ac9f]">
            <a href="#features" className="hover:text-[#f2ede4]">Features</a>
            <a href="#model" className="hover:text-[#f2ede4]">Model</a>
            <a href="#pricing" className="hover:text-[#f2ede4]">Pricing</a>
            <button onClick={onDownloadZip} className="hover:text-[#e2a545] text-xs font-semibold cursor-pointer">
              Download ZIP
            </button>
          </div>
        </div>
      </footer>

      {/* Right-click Guard Toast */}
      {toastMessage && (
        <div
          id="site-guard-toast"
          role="status"
          aria-live="polite"
          className="fixed left-1/2 bottom-6 -translate-x-1/2 z-50 max-w-[min(92vw,360px)] px-5 py-3.5 rounded-2xl bg-[#12161c] text-[#f3f5f7] font-semibold text-[0.95rem] border border-emerald-400/40 shadow-2xl text-center pointer-events-none transition-all duration-200 animate-slide-up"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
};
