import React, { useState, useMemo } from 'react';
import { Search, X, Wand2, Shield, ShoppingBag, Image as ImageIcon, ArrowRight, Sparkles } from 'lucide-react';
import { Language, translations } from '../i18n/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSelectAction: (actionKey: string, payload?: string) => void;
}

interface SearchEntry {
  id: string;
  category: 'tool' | 'store' | 'security' | 'gallery';
  icon: React.ReactNode;
  titleKu: string;
  titleAr: string;
  titleEn: string;
  descKu: string;
  descAr: string;
  descEn: string;
  actionKey: string;
  payload?: string;
}

export const QuickSearchBar: React.FC<Props> = ({ isOpen, onClose, lang, onSelectAction }) => {
  const t = translations[lang];
  const isRtl = lang === 'ku' || lang === 'ar';
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState<'all' | 'tool' | 'store' | 'security' | 'gallery'>('all');

  const entries: SearchEntry[] = useMemo(
    () => [
      {
        id: 's-img-studio',
        category: 'tool',
        icon: <Wand2 className="w-4 h-4 text-[#e2a545]" />,
        titleKu: 'ستۆدیۆی ئیدیتکردنی وێنە (لابردنی لۆگۆ و نووسین)',
        titleAr: 'ستوديو تعديل الصور (إزالة النصوص والشعارات)',
        titleEn: 'AI Image Studio (Remove Logo & Text)',
        descKu: 'سڕینەوەی لۆگۆ و ئاوەڕۆک، دەستکاریکردنی سینەمایی، و بەرزکردنەوەی کوالیتی 4K.',
        descAr: 'إزالة العلامات المائية والنصوص، تعديل سينمائي، ورفع الجودة.',
        descEn: 'Erase logos and text without distortion, upscale to 4K resolution.',
        actionKey: 'open_image_studio',
      },
      {
        id: 's-agent-ai',
        category: 'tool',
        icon: <Sparkles className="w-4 h-4 text-[#e2a545]" />,
        titleKu: 'شۆڕشێکی نوێ: دروستکردن و ڕەنکردنی هەر وێبسایتێک (< ٥ دەقە)',
        titleAr: 'ثورة جديدة: بناء وتشغيل أي موقع ويب ذاتياً (< 5 دقائق)',
        titleEn: 'Autonomous Agent: Build & Run Any Website in Under 5 Mins',
        descKu: 'تۆ تەنها داوا ئەکەی، ڤی ئێکس خۆی بۆت ئامادە ئەکات و ڕەنیشی ئەکات (دیزاین، باکیند، داتابەیس).',
        descAr: 'أنت فقط تطلب، وVX يجهّزه ويشغّله فوراً مع الواجهات والخادم وقاعدة البيانات.',
        descEn: 'You just ask, VX prepares and runs it for you autonomously in under 5 minutes.',
        actionKey: 'open_agent_runner',
        payload: 'وێبسایتێکی مۆدێرن دروستبکە و ڕەنی بکە.',
      },
      {
        id: 's-cyber-audit',
        category: 'security',
        icon: <Shield className="w-4 h-4 text-emerald-400" />,
        titleKu: 'پشکنینی سایبەر سکیوریتی بە ٥ خاڵەکە (/check)',
        titleAr: 'فحص الأمن السيبراني ذو 5 نقاط (/check)',
        titleEn: '5-Point Cyber Vulnerability Auditor (/check)',
        descKu: 'پشکنینی دەروازەکان، ڕەیت لمتەر، دزەکردنی .env، دۆخی بڕوانامەی SSL و کەلێنی SQLi.',
        descAr: 'فحص مسارات المشرف، محدد السرعة، تسريب .env، شهادات SSL وثغرات SQLi.',
        descEn: 'Scan admin routes, rate limiters, .env leaks, SSL TLS 1.3, and SQL injection.',
        actionKey: 'trigger_prompt',
        payload: '/check https://example.com',
      },
      {
        id: 's-store-web',
        category: 'store',
        icon: <ShoppingBag className="w-4 h-4 text-amber-400" />,
        titleKu: 'داواکردنی وێبسایت و ئەپڵیکەیشن لە فرۆشگا',
        titleAr: 'طلب تطوير موقع أو تطبيق من المتجر',
        titleEn: 'Order Full-Stack Web Development in Store',
        descKu: 'داواکاری ڕاستەوخۆ بە شێوازی پارەدانی FastPay, ZainCash, FIB یان کاش.',
        descAr: 'طلب مباشر مع دعم الدفع عبر فاست باي، زين كاش، أو الدفع عند الاستلام.',
        descEn: 'Direct order with FastPay, ZainCash, FIB, or Cash on delivery.',
        actionKey: 'open_store',
      },
      {
        id: 's-gallery',
        category: 'gallery',
        icon: <ImageIcon className="w-4 h-4 text-purple-400" />,
        titleKu: 'گاڵەری وێنە و ڤیدیۆکانی 𝙓𝙑-𝘼𝙄',
        titleAr: 'معرض الصور والفيديوهات والنماذج',
        titleEn: 'Media Gallery Showcase (Photos & Videos)',
        descKu: 'بینینی نموونەکانی پێش و پاشی لابردنی لۆگۆ، 4K Upscale، و ڤیدیۆکانی فێرکاری.',
        descAr: 'استعراض نماذج قبل وبعد إزالة الشعار، رفع الدقة 4K، والدروس.',
        descEn: 'Browse before/after logo removal, 4K upscale, and video demos.',
        actionKey: 'open_gallery',
      },
    ],
    []
  );

  if (!isOpen) return null;

  const filtered = entries.filter((item) => {
    if (activeCat !== 'all' && item.category !== activeCat) return false;
    if (!query.trim()) return true;

    const q = query.toLowerCase();
    const tKu = item.titleKu.toLowerCase();
    const tAr = item.titleAr.toLowerCase();
    const tEn = item.titleEn.toLowerCase();
    const dKu = item.descKu.toLowerCase();
    const dAr = item.descAr.toLowerCase();
    const dEn = item.descEn.toLowerCase();

    return (
      tKu.includes(q) ||
      tAr.includes(q) ||
      tEn.includes(q) ||
      dKu.includes(q) ||
      dAr.includes(q) ||
      dEn.includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-60 flex items-start justify-center pt-16 sm:pt-24 p-3 bg-black/80 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-[#121319] border border-[#e2a545]/40 w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Box */}
        <div className="p-3.5 sm:p-4 border-b border-[#2b2c3a] flex items-center gap-3 bg-[#171822]">
          <Search className="w-5 h-5 text-[#e2a545] shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="flex-1 bg-transparent border-none outline-none text-xs sm:text-sm text-[#f2ede4] placeholder-[#787368]"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded text-[#8e8a80] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs bg-[#242533] px-2.5 py-1 rounded-lg text-[#a29d91] hover:text-white transition"
          >
            ESC
          </button>
        </div>

        {/* Category Filters */}
        <div className="p-2 border-b border-[#252634] bg-[#14151e] flex items-center gap-1.5 overflow-x-auto text-[11px] no-scrollbar">
          <button
            onClick={() => setActiveCat('all')}
            className={`px-3 py-1 rounded-full transition cursor-pointer font-bold ${
              activeCat === 'all' ? 'bg-[#e2a545] text-black font-black' : 'text-[#8e8a80] hover:text-white'
            }`}
          >
            {t.allMedia}
          </button>
          <button
            onClick={() => setActiveCat('tool')}
            className={`px-3 py-1 rounded-full transition cursor-pointer font-bold ${
              activeCat === 'tool' ? 'bg-[#e2a545] text-black font-black' : 'text-[#8e8a80] hover:text-white'
            }`}
          >
            {t.imageStudio} &amp; AI
          </button>
          <button
            onClick={() => setActiveCat('store')}
            className={`px-3 py-1 rounded-full transition cursor-pointer font-bold ${
              activeCat === 'store' ? 'bg-[#e2a545] text-black font-black' : 'text-[#8e8a80] hover:text-white'
            }`}
          >
            {t.store}
          </button>
          <button
            onClick={() => setActiveCat('security')}
            className={`px-3 py-1 rounded-full transition cursor-pointer font-bold ${
              activeCat === 'security' ? 'bg-[#e2a545] text-black font-black' : 'text-[#8e8a80] hover:text-white'
            }`}
          >
            Cyber Security
          </button>
          <button
            onClick={() => setActiveCat('gallery')}
            className={`px-3 py-1 rounded-full transition cursor-pointer font-bold ${
              activeCat === 'gallery' ? 'bg-[#e2a545] text-black font-black' : 'text-[#8e8a80] hover:text-white'
            }`}
          >
            {t.gallery}
          </button>
        </div>

        {/* Search Results List */}
        <div className="max-h-[380px] overflow-y-auto p-2 sm:p-3 space-y-1.5">
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-xs text-[#787368]">
              {lang === 'en' ? 'No matching results found.' : lang === 'ar' ? 'لم يتم العثور على نتائج مطابقة.' : 'هیچ ئەنجامێک بۆ ئەم گەڕانە نەدۆزرایەوە.'}
            </div>
          ) : (
            filtered.map((item) => {
              const title = lang === 'en' ? item.titleEn : lang === 'ar' ? item.titleAr : item.titleKu;
              const desc = lang === 'en' ? item.descEn : lang === 'ar' ? item.descAr : item.descKu;

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    onSelectAction(item.actionKey, item.payload);
                    onClose();
                  }}
                  className="p-3 rounded-2xl bg-[#161722] hover:bg-[#20212e] border border-[#262736] hover:border-[#e2a545]/50 cursor-pointer transition flex items-center justify-between group"
                >
                  <div className="flex items-start gap-3">
                    <div className="p-2 rounded-xl bg-[#232433] shrink-0 mt-0.5 group-hover:scale-105 transition">
                      {item.icon}
                    </div>
                    <div>
                      <div className="font-bold text-xs sm:text-[13px] text-[#f2ede4] mb-0.5 group-hover:text-[#e2a545] transition">
                        {title}
                      </div>
                      <p className="text-[11px] text-[#8e8a80] line-clamp-1">{desc}</p>
                    </div>
                  </div>

                  <ArrowRight className={`w-4 h-4 text-[#68645a] group-hover:text-[#e2a545] transition shrink-0 ${isRtl ? 'rotate-180' : ''}`} />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
