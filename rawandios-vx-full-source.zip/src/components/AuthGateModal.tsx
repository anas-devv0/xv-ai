import React, { useState, useEffect } from 'react';
import { Lock, Mail, KeyRound, ShieldCheck, CheckCircle2, ArrowRight, Smartphone, RefreshCw, LogIn, AlertCircle } from 'lucide-react';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  provider: 'google' | 'apple' | 'gmail_otp';
  avatar?: string;
  verifiedAt: number;
}

interface Props {
  isOpen: boolean;
  onAuthenticated: (user: AuthUser) => void;
}

export const AuthGateModal: React.FC<Props> = ({ isOpen, onAuthenticated }) => {
  const [authMethod, setAuthMethod] = useState<'options' | 'gmail_otp' | 'otp_verify'>('options');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [otpCodeInput, setOtpCodeInput] = useState(['', '', '', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [simulatedInboxNotification, setSimulatedInboxNotification] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Generate 6-digit OTP and show notification
  const handleRequestOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const email = emailInput.trim();
    if (!email || !email.includes('@')) {
      setErrorMessage('تکایە ناونیشانی جیمەیڵ (Gmail) بە دروستی بنووسە.');
      return;
    }
    if (!passwordInput || passwordInput.length < 4) {
      setErrorMessage('تکایە تێپەڕەوشە (پاسپۆرد) بنووسە (لانیکەم ٤ پیت/ژمارە).');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      // 6-digit random code
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      setGeneratedOtp(code);
      setAuthMethod('otp_verify');
      setIsSubmitting(false);

      // Simulate incoming Gmail OTP notification banner
      setSimulatedInboxNotification(code);
    }, 600);
  };

  const handleVerifyOtp = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const enteredOtp = otpCodeInput.join('');
    if (enteredOtp.length !== 6) {
      setErrorMessage('تکایە کۆدی ٦ ژمارەیی بە تەواوی بنووسە.');
      return;
    }

    if (enteredOtp !== generatedOtp) {
      setErrorMessage('کۆدی داخڵکراو هەڵەیە! تکایە سەیری ئەو کۆدە بکە کە بۆ جیمەیڵەکەت هاتووە.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const user: AuthUser = {
        id: `user-gmail-${Date.now()}`,
        name: emailInput.split('@')[0],
        email: emailInput,
        provider: 'gmail_otp',
        verifiedAt: Date.now(),
      };
      localStorage.setItem('xv_auth_user', JSON.stringify(user));
      setIsSubmitting(false);
      onAuthenticated(user);
    }, 500);
  };

  const handleGoogleSignIn = () => {
    const user: AuthUser = {
      id: `user-google-${Date.now()}`,
      name: 'Google Play User',
      email: 'user.play@gmail.com',
      provider: 'google',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120&q=80',
      verifiedAt: Date.now(),
    };
    try {
      localStorage.setItem('xv_auth_user', JSON.stringify(user));
    } catch {
      // storage
    }
    onAuthenticated(user);
  };

  const handleAppleSignIn = () => {
    const user: AuthUser = {
      id: `user-apple-${Date.now()}`,
      name: 'Apple ID Member',
      email: 'apple.user@icloud.com',
      provider: 'apple',
      verifiedAt: Date.now(),
    };
    try {
      localStorage.setItem('xv_auth_user', JSON.stringify(user));
    } catch {
      // storage
    }
    onAuthenticated(user);
  };

  // Quick auto-fill OTP helper for great user experience
  const autoFillOtp = () => {
    if (!generatedOtp) return;
    const digits = generatedOtp.split('');
    setOtpCodeInput(digits);
    setErrorMessage(null);
  };

  const handleOtpDigitChange = (index: number, val: string) => {
    if (val.length > 1) {
      val = val.slice(-1);
    }
    const newArr = [...otpCodeInput];
    newArr[index] = val;
    setOtpCodeInput(newArr);

    // Auto-focus next input
    if (val && index < 5) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpCodeInput[index] && index > 0) {
      const prevInput = document.getElementById(`otp-input-${index - 1}`);
      prevInput?.focus();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fade-in text-[#f2ede4] select-none" dir="rtl">
      {/* Real simulated OTP Toast incoming popup */}
      {simulatedInboxNotification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 bg-[#1e2029] border-2 border-emerald-500/80 rounded-2xl p-4 shadow-2xl max-w-md w-full animate-bounce-subtle text-right flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
            <Mail className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-emerald-400">📩 ئاگاداری: نامەی جیمەیڵ هات لە 𝙓𝙑-𝘼𝙄</span>
              <span className="text-[10px] text-[#8e8a80]">ئێستا</span>
            </div>
            <p className="text-xs text-[#d1cbc0] mt-1">
              کۆدی دڵنیابوونەوەکەت بریتییە لە: <span className="font-mono font-black text-emerald-300 text-sm tracking-wider px-1.5 py-0.5 bg-black/40 rounded border border-emerald-500/40">{simulatedInboxNotification}</span>
            </p>
            <div className="mt-2.5 flex items-center gap-2">
              <button
                type="button"
                onClick={autoFillOtp}
                className="text-[11px] bg-emerald-600 hover:bg-emerald-500 text-black font-black px-3 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>پڕکردنەوەی خۆکار بەم کۆدە (Auto-fill)</span>
              </button>
              <button
                type="button"
                onClick={() => setSimulatedInboxNotification(null)}
                className="text-[11px] text-[#9e978c] hover:text-[#f2ede4] px-2 py-1"
              >
                داخستن
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Lock Card */}
      <div className="bg-[#121318] border border-[#e2a545]/40 w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-[0_0_50px_rgba(226,165,69,0.15)] relative overflow-hidden">
        {/* Glow ambient */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#e2a545]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Logo / Badge */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-[#2a241b] to-[#171614] border border-[#e2a545]/50 text-[#e2a545] shadow-lg mb-3">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-[#f2ede4] tracking-tight">
            چوونەژوورەوەی پارێزراو بۆ 𝙓𝙑-𝘼𝙄
          </h2>
          <p className="text-xs text-[#9e978c] mt-1.5 leading-relaxed">
            بۆ پاراستنی ئاسایش و داتاکان، تکایە لەڕێگەی یەکێک لەم شێوازانە داخڵ بە:
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-950/40 border border-rose-500/50 rounded-xl text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {authMethod === 'options' && (
          <div className="space-y-3">
            {/* Google Play / Google Button */}
            <button
              onClick={handleGoogleSignIn}
              type="button"
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#1b1c23] hover:bg-[#23242e] border border-[#2e2f3a] text-sm font-bold text-[#f2ede4] transition hover:border-[#e2a545]/70 cursor-pointer shadow-md group"
            >
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>چوونەژوورەوە بە Google Play</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                دەستبەجێ بەبێ کۆد
              </span>
            </button>

            {/* Apple ID Button */}
            <button
              onClick={handleAppleSignIn}
              type="button"
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#1b1c23] hover:bg-[#23242e] border border-[#2e2f3a] text-sm font-bold text-[#f2ede4] transition hover:border-[#e2a545]/70 cursor-pointer shadow-md group"
            >
              <div className="flex items-center gap-3">
                <svg className="w-5 h-5 shrink-0 fill-current" viewBox="0 0 170 170">
                  <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.7-3.08-7.73-7.87-12.09-14.37-6.08-9.08-10.9-19.4-14.46-30.97-3.55-11.57-5.33-22.75-5.33-33.54 0-14.42 3.6-26.68 10.8-36.79 7.21-10.11 16.5-15.27 27.88-15.49 5.38 0 11.05 1.45 17.02 4.35 5.97 2.9 9.87 4.41 11.71 4.54 1.7.13 5.79-1.42 12.27-4.66 6.48-3.23 12.38-4.7 17.7-4.42 13.58.64 24.58 5.73 33 15.26-11.96 7.25-17.84 17.04-17.65 29.38.2 9.69 3.89 17.91 11.07 24.66 7.18 6.75 15.86 10.59 26.04 11.51-2.23 6.94-4.87 13.79-7.92 20.54zM119.22 33.64c0-7.22 2.6-13.97 7.8-20.25 5.2-6.28 11.66-10.29 19.38-12.03.43 2.14.64 4.1.64 5.88 0 7.37-2.73 14.34-8.2 20.91-5.47 6.57-12.02 10.59-19.62 12.06-.43-2.14-.64-4.1-.64-5.88z" />
                </svg>
                <span>چوونەژوورەوە بە Apple ID</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                دەستبەجێ بەبێ کۆد
              </span>
            </button>

            {/* Divider */}
            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-[#262730]"></div>
              <span className="flex-shrink mx-3 text-xs text-[#7e796e] font-medium">یاخود بە ئیمێڵ و کۆد</span>
              <div className="flex-grow border-t border-[#262730]"></div>
            </div>

            {/* Gmail + Password + OTP trigger */}
            <button
              onClick={() => {
                setErrorMessage(null);
                setAuthMethod('gmail_otp');
              }}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-gradient-to-r from-[#221e16] to-[#1a1916] hover:from-[#2e271a] hover:to-[#22201b] border border-[#e2a545]/60 text-sm font-bold text-[#e2a545] transition cursor-pointer shadow-lg"
            >
              <div className="flex items-center gap-2.5">
                <Mail className="w-5 h-5 text-[#e2a545]" />
                <span>داخڵبوون بە Gmail و وەرگرتنی کۆد (OTP)</span>
              </div>
              <ArrowRight className="w-4 h-4 rotate-180" />
            </button>
          </div>
        )}

        {/* Step 2: Enter Gmail & Password */}
        {authMethod === 'gmail_otp' && (
          <form onSubmit={handleRequestOtp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#d1cbc0] mb-1.5">
                ناونیشانی جیمەیڵ (Gmail Address):
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="example@gmail.com"
                  className="w-full bg-[#181920] border border-[#2e2f3a] focus:border-[#e2a545] text-sm px-3.5 py-3 rounded-xl text-[#f2ede4] outline-none text-left font-mono"
                  dir="ltr"
                />
                <Mail className="w-4 h-4 text-[#757065] absolute right-3.5 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#d1cbc0] mb-1.5">
                تێپەڕەوشە (Password):
              </label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#181920] border border-[#2e2f3a] focus:border-[#e2a545] text-sm px-3.5 py-3 rounded-xl text-[#f2ede4] outline-none text-left font-mono"
                  dir="ltr"
                />
                <KeyRound className="w-4 h-4 text-[#757065] absolute right-3.5 top-3.5" />
              </div>
            </div>

            <p className="text-[11px] text-[#8e8a80] leading-relaxed">
              کاتێک دوگمەکە دابگریت، کۆدێکی پارێزراوی ٦ ژمارەیی بۆ ئەم جیمەیڵە ڕەوانە دەکرێت تا دڵنیابین لە ناسنامەت.
            </p>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-[#e2a545] hover:bg-[#f0c37c] text-[#111110] font-black text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>خەریکی ناردنی کۆدە...</span>
                </>
              ) : (
                <>
                  <span>ناردنی کۆدی دڵنیابوونەوە بۆ جیمەیڵ</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                setErrorMessage(null);
                setAuthMethod('options');
              }}
              className="w-full text-center text-xs text-[#9e978c] hover:text-[#f2ede4] py-1 cursor-pointer"
            >
              گەڕانەوە بۆ شێوازەکانی تر
            </button>
          </form>
        )}

        {/* Step 3: Enter the 6-Digit OTP */}
        {authMethod === 'otp_verify' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="bg-[#181922] border border-emerald-500/30 rounded-2xl p-3.5 text-center">
              <div className="text-xs text-emerald-400 font-bold mb-1 flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>کۆدی دڵنیابوونەوە نێردرا!</span>
              </div>
              <p className="text-xs text-[#a39e93]">
                کۆدێکی ٦ ژمارەیی بۆ <span className="font-mono text-[#f2ede4] font-bold">{emailInput}</span> نێردرا.
              </p>
            </div>

            <div>
              <label className="block text-center text-xs font-bold text-[#d1cbc0] mb-2.5">
                کۆدە ٦ ژمارەییەکە لێرە داخڵ بکە:
              </label>

              {/* 6 Digit Inputs */}
              <div className="flex justify-center gap-2" dir="ltr">
                {otpCodeInput.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`otp-input-${idx}`}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(idx, e)}
                    className="w-11 h-13 text-center text-xl font-black font-mono bg-[#181920] border-2 border-[#2e2f3a] focus:border-[#e2a545] rounded-xl text-[#f2ede4] outline-none transition"
                  />
                ))}
              </div>
            </div>

            {/* Quick helper to re-trigger simulation toast if dismissed */}
            <div className="flex items-center justify-between text-xs pt-1">
              <button
                type="button"
                onClick={() => setSimulatedInboxNotification(generatedOtp)}
                className="text-[#e2a545] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>دیسانەوە پیشاندانی کۆدەکە لە ئاگاداری</span>
              </button>
              <button
                type="button"
                onClick={autoFillOtp}
                className="text-emerald-400 font-bold hover:underline cursor-pointer"
              >
                پڕکردنەوەی خۆکار (Paste)
              </button>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f5b85a] hover:opacity-95 text-[#111110] font-black text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-xl disabled:opacity-50 mt-2"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>دڵنیابوونەوە لە کۆد...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-5 h-5 text-black" />
                  <span>تەواوکردن و کردنەوەی بەرنامەکە</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                setErrorMessage(null);
                setAuthMethod('gmail_otp');
              }}
              className="w-full text-center text-xs text-[#9e978c] hover:text-[#f2ede4] py-1 cursor-pointer"
            >
              گۆڕینی ناونیشانی جیمەیڵ
            </button>
          </form>
        )}

        {/* Security badge at bottom */}
        <div className="mt-6 pt-4 border-t border-[#262730] flex items-center justify-center gap-2 text-[11px] text-[#6d685d]">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>پارێزراوە بە سیستمى ئاسایشی ئەلیکترۆنی 𝙓𝙑-𝘼𝙄</span>
        </div>
      </div>
    </div>
  );
};
