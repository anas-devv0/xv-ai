import React, { useState } from 'react';
import {
  ExternalLink,
  RotateCw,
  Monitor,
  Tablet,
  Smartphone,
  Shield,
  Copy,
  Check,
  Globe,
  Maximize2,
  FileCode,
  Palette,
  Cpu,
  Image as ImageIcon,
  Link2,
  ListFilter,
  Download,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

export interface WebsiteRunData {
  url: string;
  title: string;
  status: number;
  responseTimeMs: number;
  tls: string;
  server?: string;
  html?: string;
  rawHtml?: string;
  htmlSizeKb?: number;
  totalFilesCount?: number;
  assets?: {
    stylesheets?: Array<{ url: string; rel: string; name: string }>;
    scripts?: Array<{ url: string; name: string }>;
    images?: Array<{ url: string; alt: string; name: string }>;
    links?: Array<{ url: string; text: string; isExternal: boolean }>;
    metaTags?: Array<{ name: string; content: string }>;
  };
  headers?: Record<string, string>;
  deviceView?: 'desktop' | 'tablet' | 'mobile';
}

interface Props {
  data: WebsiteRunData;
  onTriggerCheck?: (url: string) => void;
}

export const LiveWebsiteRunnerCard: React.FC<Props> = ({ data, onTriggerCheck }) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'html' | 'css' | 'js' | 'images' | 'links' | 'headers'>('preview');
  const [deviceView, setDeviceView] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [iframeKey, setIframeKey] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const cleanUrl = data.url.startsWith('http') ? data.url : `https://${data.url}`;
  const stylesheets = data.assets?.stylesheets || [];
  const scripts = data.assets?.scripts || [];
  const images = data.assets?.images || [];
  const links = data.assets?.links || [];
  const metaTags = data.assets?.metaTags || [];

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(cleanUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleCopyHtml = () => {
    navigator.clipboard.writeText(data.rawHtml || data.html || '');
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([data.rawHtml || data.html || ''], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${cleanUrl.replace(/[^a-zA-Z0-9]/g, '_')}_extracted.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReload = () => {
    setIframeKey((prev) => prev + 1);
  };

  return (
    <div
      className={`mt-3 w-full bg-[#111218] border border-[#e2a545]/50 rounded-2xl overflow-hidden shadow-2xl animate-fade-in text-[#f2ede4] ${
        isFullscreen ? 'fixed inset-2 sm:inset-4 z-60 max-h-[96vh] flex flex-col' : ''
      }`}
      dir="rtl"
    >
      {/* Top Browser Bar */}
      <div className="bg-[#171822] border-b border-[#2b2c3d] px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2">
        {/* Mac OS Style Window Dots & Live Status */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5" dir="ltr">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
          </div>

          <div className="flex items-center gap-1.5 text-xs font-black text-[#e2a545]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>وێبسایتی ڕەنکراو (Live Runner)</span>
          </div>
        </div>

        {/* Center URL Address Bar with Direct Open link */}
        <div className="flex-1 max-w-md mx-auto hidden sm:flex items-center gap-2 bg-[#0c0d13] border border-[#2b2c3d] px-3 py-1 rounded-full text-xs text-[#b8b3a7] font-mono truncate" dir="ltr">
          <Globe className="w-3.5 h-3.5 text-[#e2a545] shrink-0" />
          <a
            href={cleanUrl}
            target="_blank"
            rel="noopener noreferrer"
            title="کلیک بکە بۆ کردنەوەی ڕاستەوخۆ"
            className="truncate text-[11px] text-[#f2ede4] hover:text-[#e2a545] hover:underline"
          >
            {cleanUrl}
          </a>
          <span className="text-[10px] text-emerald-400 font-bold ml-auto shrink-0">
            {data.status || 200} OK • {data.responseTimeMs || 80}ms
          </span>
        </div>

        {/* Quick Controls */}
        <div className="flex items-center gap-1.5">
          <a
            href={cleanUrl}
            target="_blank"
            rel="noopener noreferrer"
            title="کردنەوەی ڕاستەوخۆی وێبسایتەکە لە پەنجەرەی نوێدا"
            className="px-3 py-1 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f5c46b] text-black font-black text-xs transition hover:opacity-90 flex items-center gap-1.5 shadow-md cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>کردنەوەی ڕاستەوخۆ</span>
          </a>

          <button
            onClick={handleReload}
            title="ڕەنکردنەوە / Reload"
            className="p-1.5 rounded-lg bg-[#1e202d] hover:bg-[#282a3c] text-[#a59f93] hover:text-white transition cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            title="گەورەکردنی شاشە"
            className="p-1.5 rounded-lg bg-[#1e202d] hover:bg-[#282a3c] text-[#a59f93] hover:text-white transition cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tabs Bar: Extracted Files & Source Navigator */}
      <div className="bg-[#13141d] border-b border-[#252635] px-2.5 py-1.5 flex items-center gap-1 overflow-x-auto no-scrollbar text-xs">
        <button
          onClick={() => setActiveTab('preview')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'preview' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>🖥️ بینینی وێبسایتەکە</span>
        </button>

        <button
          onClick={() => setActiveTab('html')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'html' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>کۆدی HTML ({data.htmlSizeKb || Math.round((data.html?.length || 0) / 1024)} KB)</span>
        </button>

        <button
          onClick={() => setActiveTab('css')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'css' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>فایلەکانی CSS ({stylesheets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('js')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'js' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>سکریپتەکانی JS ({scripts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('images')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'images' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>وێنەکان ({images.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('links')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'links' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <Link2 className="w-3.5 h-3.5" />
          <span>لینک و پەڕەکان ({links.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('headers')}
          className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
            activeTab === 'headers' ? 'bg-[#e2a545] text-black' : 'text-[#8f897d] hover:text-white hover:bg-white/5'
          }`}
        >
          <ListFilter className="w-3.5 h-3.5" />
          <span>مێتاداتا و هێدەر</span>
        </button>
      </div>

      {/* Main Tab Viewport */}
      <div className={`w-full bg-[#08080c] relative flex flex-col items-center justify-center ${
        isFullscreen ? 'flex-1 overflow-auto' : 'h-[460px]'
      }`}>
        {/* TAB 1: LIVE RUNNING PREVIEW (Native srcDoc with base href = ALWAYS OPENS) */}
        {activeTab === 'preview' && (
          <div className="w-full h-full flex flex-col p-2">
            {/* Device Frame Selectors */}
            <div className="flex items-center justify-between pb-2 px-1 text-xs text-[#8c867a]">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span className="font-bold text-[#f2ede4]">{data.title || cleanUrl}</span>
              </div>

              <div className="flex items-center gap-1 bg-[#1a1b26] p-0.5 rounded-lg border border-[#2b2c3d]" dir="ltr">
                <button
                  onClick={() => setDeviceView('desktop')}
                  title="Desktop (100%)"
                  className={`p-1 rounded transition cursor-pointer ${
                    deviceView === 'desktop' ? 'bg-[#e2a545] text-black font-bold' : 'text-[#8c867a] hover:text-white'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeviceView('tablet')}
                  title="Tablet (768px)"
                  className={`p-1 rounded transition cursor-pointer ${
                    deviceView === 'tablet' ? 'bg-[#e2a545] text-black font-bold' : 'text-[#8c867a] hover:text-white'
                  }`}
                >
                  <Tablet className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeviceView('mobile')}
                  title="Mobile (375px)"
                  className={`p-1 rounded transition cursor-pointer ${
                    deviceView === 'mobile' ? 'bg-[#e2a545] text-black font-bold' : 'text-[#8c867a] hover:text-white'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Iframe Viewport */}
            <div className="flex-1 w-full flex items-center justify-center overflow-auto bg-[#0a0a0f] rounded-xl border border-[#252636]">
              <div
                className={`h-full bg-white transition-all duration-300 rounded-lg overflow-hidden shadow-2xl flex flex-col ${
                  deviceView === 'desktop'
                    ? 'w-full'
                    : deviceView === 'tablet'
                    ? 'w-[768px]'
                    : 'w-[375px]'
                }`}
              >
                <iframe
                  key={iframeKey}
                  srcDoc={data.html || `<html><head><base href="${cleanUrl}"></head><body>Loading...</body></html>`}
                  title={`Live Runner: ${cleanUrl}`}
                  className="w-full h-full border-none"
                  sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: HTML FULL CODE */}
        {activeTab === 'html' && (
          <div className="w-full h-full flex flex-col p-3">
            <div className="flex items-center justify-between pb-2">
              <span className="text-xs text-[#8e897e] font-mono">
                {cleanUrl} • {data.rawHtml?.length || data.html?.length || 0} پیت
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleCopyHtml}
                  className="px-2.5 py-1 rounded-lg bg-[#1e202d] hover:bg-[#282a3c] border border-[#323447] text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'کۆپیکرا' : 'کۆپیکردنی هەموو کۆدەکە'}</span>
                </button>
                <button
                  onClick={handleDownloadHtml}
                  className="px-2.5 py-1 rounded-lg bg-[#e2a545] hover:bg-[#f5c46b] text-black text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>داگرتنی فایل (.html)</span>
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-auto bg-[#0e1017] p-3 rounded-xl border border-[#252737] font-mono text-xs text-emerald-300 leading-relaxed" dir="ltr">
              <pre>{data.rawHtml || data.html || 'No source content available.'}</pre>
            </div>
          </div>
        )}

        {/* TAB 3: CSS STYLESHEETS */}
        {activeTab === 'css' && (
          <div className="w-full h-full overflow-y-auto p-4 space-y-2">
            <div className="text-xs font-bold text-[#e2a545] mb-2">
              هەموو فایلی ستایل و CSS دەرهێنراوەکانی وێبسایتەکە ({stylesheets.length} فایل):
            </div>
            {stylesheets.length === 0 ? (
              <div className="text-xs text-[#7d776c] py-8 text-center">هیچ فایلی دەرەکی CSS لەم پەڕەیەدا نەدۆزرایەوە (ستایلەکان لەناو خودی کۆدەکاندان).</div>
            ) : (
              stylesheets.map((sheet, idx) => (
                <div key={idx} className="bg-[#14151f] border border-[#262837] rounded-xl p-3 flex items-center justify-between gap-3 text-xs" dir="ltr">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-2 h-2 rounded-full bg-blue-400 shrink-0"></span>
                    <span className="font-bold text-white truncate">{sheet.name}</span>
                    <span className="text-[10px] bg-[#1e202e] px-2 py-0.5 rounded text-[#9c9689]">{sheet.rel}</span>
                  </div>
                  <a
                    href={sheet.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-[#e2a545] hover:underline flex items-center gap-1 shrink-0"
                  >
                    <span>Open CSS</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 4: JAVASCRIPT SCRIPTS */}
        {activeTab === 'js' && (
          <div className="w-full h-full overflow-y-auto p-4 space-y-2">
            <div className="text-xs font-bold text-[#e2a545] mb-2">
              هەموو فایلی سکریپت و پەڕگەکانی JavaScript لەم وێبسایتەدا ({scripts.length} فایل):
            </div>
            {scripts.length === 0 ? (
              <div className="text-xs text-[#7d776c] py-8 text-center">هیچ فایلی دەرەکی JS نەدۆزرایەوە.</div>
            ) : (
              scripts.map((sc, idx) => (
                <div key={idx} className="bg-[#14151f] border border-[#262837] rounded-xl p-3 flex items-center justify-between gap-3 text-xs" dir="ltr">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0"></span>
                    <span className="font-bold text-white truncate">{sc.name}</span>
                  </div>
                  <a
                    href={sc.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-[#e2a545] hover:underline flex items-center gap-1 shrink-0"
                  >
                    <span>Open Script</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 5: EXTRACTED IMAGES & MEDIA */}
        {activeTab === 'images' && (
          <div className="w-full h-full overflow-y-auto p-4">
            <div className="text-xs font-bold text-[#e2a545] mb-3">
              هەموو وێنە و مێدیاکانی دەرهێنراو لە وێبسایتەکە ({images.length} وێنە):
            </div>
            {images.length === 0 ? (
              <div className="text-xs text-[#7d776c] py-8 text-center">هیچ وێنەیەک لە ناو تاگەکان نەدۆزرایەوە.</div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {images.map((img, idx) => (
                  <div key={idx} className="bg-[#14151f] border border-[#282a3c] rounded-xl p-2 flex flex-col justify-between group overflow-hidden">
                    <div className="w-full h-24 bg-[#0a0a0f] rounded-lg overflow-hidden flex items-center justify-center mb-2">
                      <img
                        src={img.url}
                        alt={img.alt || 'Asset'}
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>
                    <div className="text-[10px] text-[#b0aba0] truncate mb-1" title={img.name}>
                      {img.name}
                    </div>
                    <a
                      href={img.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] bg-[#1e202e] hover:bg-[#2b2e42] text-[#e2a545] text-center py-1 rounded transition flex items-center justify-center gap-1"
                    >
                      <span>داگرتن / Open</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 6: EXTRACTED LINKS & PAGES */}
        {activeTab === 'links' && (
          <div className="w-full h-full overflow-y-auto p-4 space-y-1.5">
            <div className="text-xs font-bold text-[#e2a545] mb-2">
              هەموو بەستەر و پەڕە دۆزراوەکانی ناو وێبسایتەکە ({links.length} لینک):
            </div>
            {links.length === 0 ? (
              <div className="text-xs text-[#7d776c] py-8 text-center">هیچ بەستەرێک لە پەڕەکەدا نەدۆزرایەوە.</div>
            ) : (
              links.map((ln, idx) => (
                <div key={idx} className="bg-[#14151f] border border-[#252737] rounded-xl p-2.5 flex items-center justify-between gap-3 text-xs" dir="ltr">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${ln.isExternal ? 'bg-purple-400' : 'bg-emerald-400'}`}></span>
                    <span className="font-bold text-white truncate">{ln.text || ln.url}</span>
                    <span className="text-[10px] text-[#7d786d] truncate">({ln.url})</span>
                  </div>
                  <a
                    href={ln.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-[#e2a545] hover:underline shrink-0 flex items-center gap-1"
                  >
                    <span>Visit</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              ))
            )}
          </div>
        )}

        {/* TAB 7: METADATA & SERVER HEADERS */}
        {activeTab === 'headers' && (
          <div className="w-full h-full overflow-y-auto p-4 space-y-3">
            <div className="text-xs font-bold text-[#e2a545]">مێتاداتا و زانیارییەکانی سێرڤەر:</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-[#14151f] border border-[#252737] p-3 rounded-xl">
                <span className="text-[#8c867a] block text-[11px]">Server Engine:</span>
                <span className="font-bold text-white">{data.server || 'Standard Web Server'}</span>
              </div>
              <div className="bg-[#14151f] border border-[#252737] p-3 rounded-xl">
                <span className="text-[#8c867a] block text-[11px]">Security Protocol:</span>
                <span className="font-bold text-emerald-400">{data.tls || 'TLS 1.3 / HTTPS'}</span>
              </div>
              <div className="bg-[#14151f] border border-[#252737] p-3 rounded-xl">
                <span className="text-[#8c867a] block text-[11px]">Status Code:</span>
                <span className="font-bold text-white">{data.status} OK</span>
              </div>
              <div className="bg-[#14151f] border border-[#252737] p-3 rounded-xl">
                <span className="text-[#8c867a] block text-[11px]">Response Latency:</span>
                <span className="font-bold text-amber-400">{data.responseTimeMs}ms</span>
              </div>
            </div>

            {metaTags.length > 0 && (
              <div className="pt-2">
                <div className="text-xs font-bold text-[#e2a545] mb-2">تاگەکانی Meta & SEO:</div>
                <div className="bg-[#14151f] border border-[#252737] rounded-xl p-3 space-y-1.5 text-xs font-mono" dir="ltr">
                  {metaTags.map((mt, idx) => (
                    <div key={idx} className="flex items-start gap-2 border-b border-white/5 pb-1 last:border-none">
                      <span className="text-purple-400 font-bold shrink-0">{mt.name}:</span>
                      <span className="text-[#dcd6ca] break-all">{mt.content}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Bar: Quick Audit & Action Triggers */}
      <div className="bg-[#15161f] border-t border-[#252634] px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 text-[11px] text-[#938d81]">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>{data.totalFilesCount || stylesheets.length + scripts.length + images.length} فایل و ئاسێت دەرهێنراون</span>
          <span>•</span>
          <span className="text-[#e2a545] font-bold">{data.title || cleanUrl}</span>
        </div>

        <div className="flex items-center gap-2">
          {onTriggerCheck && (
            <button
              onClick={() => onTriggerCheck(cleanUrl)}
              className="text-[11px] font-bold px-3 py-1.5 rounded-xl bg-[#14231b] hover:bg-[#1b3325] border border-emerald-500/40 text-emerald-300 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>پشکنینی ٥ خاڵەکە (/check)</span>
            </button>
          )}

          <button
            onClick={handleCopyUrl}
            className="text-[11px] font-bold px-2.5 py-1.5 rounded-xl bg-[#1e202d] hover:bg-[#282a3c] border border-[#323447] text-[#c9c3b7] transition flex items-center gap-1 cursor-pointer"
          >
            {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedUrl ? 'کۆپیکرا' : 'کۆپیکردنی لینک'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
