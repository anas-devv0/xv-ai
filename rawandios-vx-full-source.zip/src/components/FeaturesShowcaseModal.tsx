import React from 'react';
import { X, Sparkles, Shield, Eye, Video, Globe, Bookmark, Download, MapPin, Wand2, Cpu, Eraser, Sliders, ArrowUpCircle, Terminal } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onTriggerPrompt: (prompt: string) => void;
  onOpenImageStudio?: () => void;
}

export const FeaturesShowcaseModal: React.FC<Props> = ({ isOpen, onClose, onTriggerPrompt, onOpenImageStudio }) => {
  if (!isOpen) return null;

  const coreFeatures = [
    {
      num: '١',
      icon: <Wand2 className="w-4 h-4 text-[#e2a545]" />,
      title: 'ستۆدیۆی نوێی ئیدیتکردنی وێنە',
      desc: 'لابردنی نووسین و لۆگۆ، ئیدیتکردنی پڕۆفیشناڵ، و بەرزکردنەوەی کوالیتی و ڕوونی وێنە بە ژیریی دەستکرد.',
    },
    {
      num: '٢',
      icon: <Cpu className="w-4 h-4 text-[#e2a545]" />,
      title: 'شۆڕشێکی نوێ: Agent AI (دروستکردن و ڕەنکردن)',
      desc: 'هەرچەندە ئێمە دەمێکە ئەیجنتمان هەیە بەڵام ئەمە شۆڕشێکی نوێیە لە زیرەکی دەستکرد؛ تۆ تەنها داوا ئەکەی، ڤی ئێکس خۆی بۆت ئامادە ئەکات و ڕەنیشی ئەکات — هەر وێبسایتێک بە کەمتر لە ٥ دەقە!',
    },
    {
      num: '٣',
      icon: <MapPin className="w-4 h-4 text-rose-400" />,
      title: 'دۆزینەوەی لۆکەیشن لەسەر نەخشە (/location)',
      desc: 'شیکاری جوگرافی و مێتاداتای وێنە و نیشاندانی شوێنەکان بە بازنەی سوور لەسەر نەخشەی زیندوو.',
    },
    {
      num: '٤',
      icon: <Shield className="w-4 h-4 text-emerald-400" />,
      title: 'پشکنینی سایبەر سکیوریتی بە ٥ خاڵەکە',
      desc: 'پشکنینی کەلێنەکانی وێبسایت، دزەکردنی فایلی .env، کەلێنی SQLi، و دۆخی SSL و Rate Limiter لە کەمتر لە ١ خولەکدا.',
    },
    {
      num: '٥',
      icon: <Globe className="w-4 h-4 text-amber-400" />,
      title: 'ڕیسێرچی وێب و فێتچکردن',
      desc: 'هێنانی داتای هەر وێبسایتێک و پشکنین و شییکردنەوەی خێرای کێشە و بەگەکان.',
    },
    {
      num: '٦',
      icon: <Terminal className="w-4 h-4 text-purple-400" />,
      title: 'دروستکردنی تووڵ، سکریپت و چیتی یاری',
      desc: 'نووسینی سکریپتی پاراستن، تووڵی ئۆتۆمەیشن، کڕاکینگی ئەخلاقی و چارەسەری کۆدەکان.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir="rtl">
      <div className="bg-[#111216] border border-[#e2a545]/40 w-full max-w-2xl max-h-[92vh] rounded-3xl flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2b2a26] flex items-center justify-between bg-[#17171c]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#e2a545]/20 border border-[#e2a545]/30 flex items-center justify-center text-[#e2a545]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-[#f2ede4] flex items-center gap-2">
                <span>تایبەتمەندی و تواناکانی 𝙓𝙑-𝘼𝙄</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">LATEST RELEASE</span>
              </h3>
              <p className="text-xs text-[#9e978c]">ستۆدیۆی وێنە • ئەیجنتی فول ستاک • ئاسایشی پێشکەوتوو</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Announcement Card */}
          <div className="bg-gradient-to-br from-[#1d1b16] to-[#141418] border border-[#e2a545]/40 rounded-2xl p-4 text-xs sm:text-[13px] leading-relaxed shadow-lg">
            <div className="text-[#e2a545] font-black mb-1.5 flex items-center gap-2 text-sm">
              <Sparkles className="w-4 h-4" />
              <span>هەنگاوێکی تر لە ژیریی دەستکرد: توانای ئیدیتکردنی وێنە و ئەیجنتی نارنیکس</span>
            </div>
            <p className="text-[#d1cbc0] leading-relaxed mb-3">
              ئێستا 𝙓𝙑-𝘼𝙄 گەورەترین نوێکاری بەدەستهێناوە لە توانای بیرکردنەوە و ئۆتۆمەیشن:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-[#181920] border border-[#2b2a26] p-2.5 rounded-xl flex items-center gap-2">
                <Eraser className="w-4 h-4 text-[#e2a545] shrink-0" />
                <span><strong>لابردنی نووسین و لۆگۆ:</strong> سڕینەوە بەبێ تێکچوونی ڕووکار</span>
              </div>
              <div className="bg-[#181920] border border-[#2b2a26] p-2.5 rounded-xl flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-400 shrink-0" />
                <span><strong>ئیدیتکردنی پڕۆفیشناڵ:</strong> ڕێکخستنی ڕووناکی و کۆنتراست</span>
              </div>
              <div className="bg-[#181920] border border-[#2b2a26] p-2.5 rounded-xl flex items-center gap-2">
                <ArrowUpCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span><strong>بەرزکردنەوەی کوالیتی:</strong> AI 4K Super-Resolution</span>
              </div>
              <div className="bg-[#181920] border border-[#2b2a26] p-2.5 rounded-xl flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-400 shrink-0" />
                <span><strong>ئەیجنتی Full Stack:</strong> دروستکردنی وێبسایت لە خولەکێکدا</span>
              </div>
            </div>
          </div>

          {/* 6 Core Capabilities */}
          <div>
            <h4 className="text-xs font-bold text-[#e2a545] mb-2 uppercase tracking-wider">
              تەواوی تایبەتمەندییە بەردەستەکان
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {coreFeatures.map((f, i) => (
                <div key={i} className="bg-[#161619] border border-[#2b2a26] hover:border-[#382c19] p-3 rounded-2xl flex items-start gap-2.5 transition">
                  <div className="p-2 rounded-xl bg-[#22211e] shrink-0 mt-0.5">
                    {f.icon}
                  </div>
                  <div>
                    <div className="font-semibold text-xs text-[#f2ede4] mb-0.5">{f.num}. {f.title}</div>
                    <p className="text-[11px] text-[#9e978c] leading-relaxed">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2b2a26] bg-[#141418] flex items-center justify-between text-xs">
          {onOpenImageStudio && (
            <button
              onClick={() => {
                onClose();
                onOpenImageStudio();
              }}
              className="text-[#e2a545] hover:underline flex items-center gap-1.5 font-bold cursor-pointer"
            >
              <Wand2 className="w-4 h-4" />
              <span>کردنەوەی ستۆدیۆی وێنە</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#e2a545] text-[#111110] font-black hover:bg-[#f0c37c] transition mr-auto cursor-pointer"
          >
            داخستن
          </button>
        </div>
      </div>
    </div>
  );
};
