import React, { useState } from 'react';
import { X, Image as ImageIcon, Video, Play, Eye, Sparkles, Filter, ZoomIn, Download } from 'lucide-react';
import { Language, translations } from '../i18n/translations';

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  titleKu: string;
  titleAr: string;
  titleEn: string;
  category: 'edit' | 'upscale' | 'website' | 'tutorial';
  src: string;
  previewSrc: string;
  descriptionKu: string;
  descriptionAr: string;
  descriptionEn: string;
}

export const GALLERY_ITEMS: MediaItem[] = [
  {
    id: 'gal-1',
    type: 'image',
    titleKu: 'لابردنی نووسین و لۆگۆ بەبێ تێکچوون (Logo Eraser)',
    titleAr: 'إزالة الشعارات والنصوص بدقة تامة',
    titleEn: 'AI Logo & Watermark Eraser Demo',
    category: 'edit',
    src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    previewSrc: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'سڕینەوەی لۆگۆ لەسەر وێنەی سروشت و گۆڕینی بە ژیری دەستکرد بەبێ بەجێهێشتنی هیچ شوێنەوارێک.',
    descriptionAr: 'مسح العلامة المائية والشعار من الصورة الطبيعية وإعادة البناء الذكي للخلفية.',
    descriptionEn: 'Flawless removal of watermarks and logos with background inpainting.',
  },
  {
    id: 'gal-2',
    type: 'image',
    titleKu: 'بەرزکردنەوەی کوالیتی وێنە بۆ 4K Super-Resolution',
    titleAr: 'رفع دقة وجودة الصورة إلى 4K فائقة الدقة',
    titleEn: '4K Super-Resolution Portrait Enhancer',
    category: 'upscale',
    src: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    previewSrc: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'زیادکردنی وردەکاری دەموچاو و چاو بە ٤ هێندە بەرزکردنەوەی کوالیتی.',
    descriptionAr: 'تحسين تفاصيل الوجه والعيون ومضاعفة الدقة أربع مرات بتقنية التعلم العميق.',
    descriptionEn: 'Deep learning 4x upscale revealing crisp facial contours and textures.',
  },
  {
    id: 'gal-3',
    type: 'video',
    titleKu: 'ڤیدیۆی فێرکاری: دروستکردنی وێبسایت لە چەند خولەکێکدا لەگەڵ Agent AI',
    titleAr: 'فيديو تعليمي: بناء موقع متكامل خلال دقائق بواسطة Agent AI',
    titleEn: 'Agent AI Full-Stack Website Builder Video Guide',
    category: 'tutorial',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    previewSrc: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'بینینی چۆنیەتی دروستکردنی وێبسایت بە فرۆنت ئیند و باکیند و دیزاین بە نامەیەکی کورت.',
    descriptionAr: 'شاهد بالفيديو كيفية إنشاء موقع متكامل الواجهات والخادم خلال دقائق بطلب بسيط.',
    descriptionEn: 'Complete walkthrough of generating frontend and backend code autonomously.',
  },
  {
    id: 'gal-4',
    type: 'image',
    titleKu: 'ئیدیتکردنی پرۆفیشناڵی ڕەنگ و ڕووناکی سینەمایی',
    titleAr: 'تعديل احترافي للإضاءة والألوان السينمائية',
    titleEn: 'Cinematic Mood & Color Grading Studio',
    category: 'edit',
    src: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
    previewSrc: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'گۆڕینی کەشوهەوای وێنە بە فلتەری ستۆدیۆ و تیشکی زێڕین.',
    descriptionAr: 'تحويل الأجواء العامة للصورة بمرشحات استوديو سينمائية وأشعة ذهبية.',
    descriptionEn: 'Atmospheric cinematic grade with volumetric lighting and golden hues.',
  },
  {
    id: 'gal-5',
    type: 'video',
    titleKu: 'ڤیدیۆی شیکاریی سایبەری: پشکنینی ٥ خاڵەکە بە زیندوویی (/check)',
    titleAr: 'فيديو الفحص الأمني: التدقيق ذو الـ 5 نقاط مباشرة',
    titleEn: 'Live 5-Point Security Audit Walkthrough',
    category: 'tutorial',
    src: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    previewSrc: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'پشکنینی دەروازەکان، ڕەیت لمتەر، دزەکردنی .env و کەلێنی SSL بە کەمتر لە ١ خولەک.',
    descriptionAr: 'فحص المنافذ ومحدد السرعة وحماية المفاتيح السرية في أقل من دقيقة.',
    descriptionEn: 'Full video demonstrating lightning-fast probing of critical vulnerabilities.',
  },
  {
    id: 'gal-6',
    type: 'image',
    titleKu: 'دروستکردنی شار و ژینگەی داهاتوو بە ژیریی دەستکرد',
    titleAr: 'توليد مدن وبيئات خيالية مستقبلية بالذكاء الاصطناعي',
    titleEn: 'Futuristic Cyberpunk Metropolis Generation',
    category: 'upscale',
    src: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1200&q=80',
    previewSrc: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=600&q=80',
    descriptionKu: 'تەلارسازی سایبەرپانک و ڕووناکی نیۆن دروستکراو بە تەواوی بە مۆدێلی وێنە.',
    descriptionAr: 'عمارة مستقبلية مع إضاءة نيون مستوحاة من خيال الخيال العلمي.',
    descriptionEn: 'High concept neural generation of sprawling futuristic cityscapes.',
  },
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const MediaGalleryModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const t = translations[lang];
  const isRtl = lang === 'ku' || lang === 'ar';

  const [activeCategory, setActiveCategory] = useState<'all' | 'image' | 'video'>('all');
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);

  if (!isOpen) return null;

  const filteredItems = GALLERY_ITEMS.filter((item) => {
    if (activeCategory === 'all') return true;
    return item.type === activeCategory;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fade-in text-[#f2ede4]" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-[#111216] border border-[#e2a545]/40 w-full max-w-4xl max-h-[92vh] rounded-3xl flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#2b2a26] flex items-center justify-between bg-[#17171e]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <ImageIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#f2ede4]">{t.galleryTitle}</h3>
              <p className="text-xs text-[#9e978c]">{t.gallerySubtitle}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-[#9e978c] hover:text-[#f2ede4] hover:bg-white/5 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="px-4 sm:px-6 py-3 border-b border-[#252630] bg-[#14151b] flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-[#e2a545]" />
          <div className="flex items-center gap-1.5 text-xs">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1 rounded-full font-bold transition cursor-pointer ${
                activeCategory === 'all'
                  ? 'bg-[#e2a545] text-black shadow-md'
                  : 'bg-[#1b1c24] text-[#a09a8f] hover:text-[#f2ede4]'
              }`}
            >
              {t.allMedia} ({GALLERY_ITEMS.length})
            </button>
            <button
              onClick={() => setActiveCategory('image')}
              className={`px-3 py-1 rounded-full font-bold transition cursor-pointer flex items-center gap-1 ${
                activeCategory === 'image'
                  ? 'bg-[#e2a545] text-black shadow-md'
                  : 'bg-[#1b1c24] text-[#a09a8f] hover:text-[#f2ede4]'
              }`}
            >
              <ImageIcon className="w-3 h-3" />
              <span>{t.photos} (4)</span>
            </button>
            <button
              onClick={() => setActiveCategory('video')}
              className={`px-3 py-1 rounded-full font-bold transition cursor-pointer flex items-center gap-1 ${
                activeCategory === 'video'
                  ? 'bg-[#e2a545] text-black shadow-md'
                  : 'bg-[#1b1c24] text-[#a09a8f] hover:text-[#f2ede4]'
              }`}
            >
              <Video className="w-3 h-3" />
              <span>{t.videos} (2)</span>
            </button>
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredItems.map((item) => {
              const title = lang === 'en' ? item.titleEn : lang === 'ar' ? item.titleAr : item.titleKu;
              const desc = lang === 'en' ? item.descriptionEn : lang === 'ar' ? item.descriptionAr : item.descriptionKu;

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="bg-[#16171f] border border-[#2b2a26] hover:border-[#e2a545]/60 rounded-2xl overflow-hidden cursor-pointer group transition shadow-md flex flex-col justify-between"
                >
                  <div className="relative h-44 w-full bg-black overflow-hidden">
                    <img
                      src={item.previewSrc}
                      alt={title}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90 group-hover:opacity-100"
                    />

                    {item.type === 'video' ? (
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="w-11 h-11 rounded-full bg-[#e2a545] text-black flex items-center justify-center shadow-lg group-hover:scale-110 transition">
                          <Play className="w-5 h-5 ml-0.5 fill-current" />
                        </div>
                      </div>
                    ) : (
                      <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-sm text-[#e2a545] p-1.5 rounded-lg border border-[#e2a545]/30">
                        <ZoomIn className="w-3.5 h-3.5" />
                      </div>
                    )}

                    <span className="absolute top-2 right-2 bg-black/80 text-[10px] font-bold px-2 py-0.5 rounded-full border border-white/20">
                      {item.type === 'video' ? 'VIDEO' : 'IMAGE'}
                    </span>
                  </div>

                  <div className="p-3.5">
                    <h4 className="font-bold text-xs sm:text-[13px] text-[#f2ede4] mb-1 line-clamp-1">{title}</h4>
                    <p className="text-[11px] text-[#908b80] line-clamp-2 leading-relaxed">{desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Lightbox / Video Player Modal */}
        {selectedItem && (
          <div
            className="fixed inset-0 z-60 bg-black/95 backdrop-blur-xl flex items-center justify-center p-3 sm:p-6 animate-fade-in"
            onClick={() => setSelectedItem(null)}
          >
            <div
              className="bg-[#111216] border border-[#e2a545]/50 rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-3 border-b border-[#2b2a26] flex items-center justify-between bg-[#17171e]">
                <div className="font-bold text-xs sm:text-sm text-[#f2ede4]">
                  {lang === 'en' ? selectedItem.titleEn : lang === 'ar' ? selectedItem.titleAr : selectedItem.titleKu}
                </div>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="p-1 rounded-lg text-[#9e978c] hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-2 sm:p-4 bg-black flex items-center justify-center max-h-[60vh] overflow-hidden">
                {selectedItem.type === 'video' ? (
                  <video
                    src={selectedItem.src}
                    controls
                    autoPlay
                    className="max-h-[55vh] w-auto rounded-xl"
                  />
                ) : (
                  <img
                    src={selectedItem.src}
                    alt="Preview"
                    className="max-h-[55vh] w-auto object-contain rounded-xl"
                  />
                )}
              </div>

              <div className="p-4 bg-[#14151b] border-t border-[#252630] text-xs text-[#a09a8f] leading-relaxed">
                {lang === 'en' ? selectedItem.descriptionEn : lang === 'ar' ? selectedItem.descriptionAr : selectedItem.descriptionKu}
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3.5 border-t border-[#2b2a26] bg-[#16171d] flex items-center justify-between text-xs">
          <span className="text-[#8e8a80] text-[11px]">
            {filteredItems.length} items rendered with high fidelity
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#e2a545] hover:bg-[#f0c37c] text-black font-black transition cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
