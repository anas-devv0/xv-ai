export type Language = 'ku' | 'ar' | 'en';

export interface Translations {
  // Navigation & General
  appName: string;
  tagline: string;
  search: string;
  searchPlaceholder: string;
  theme: string;
  lightMode: string;
  darkMode: string;
  language: string;
  signIn: string;
  signOut: string;
  account: string;
  store: string;
  gallery: string;
  contact: string;
  features: string;
  imageStudio: string;
  agentRunner: string;
  aiChatbot: string;
  whatsApp: string;
  telegram: string;

  // Banner & Hero
  bannerBadge: string;
  bannerText: string;
  heroTitle: string;
  heroDesc: string;

  // Actions & Pills
  pillImageStudio: string;
  pillAgentAi: string;
  pillCyberCheck: string;
  pillProEdit: string;
  pillLocation: string;
  pillShop: string;
  pillContactUs: string;
  pillGallery: string;

  // Store & Orders
  storeTitle: string;
  storeSubtitle: string;
  addToCart: string;
  inCart: string;
  cart: string;
  emptyCart: string;
  total: string;
  checkout: string;
  orderNow: string;
  customerName: string;
  customerPhone: string;
  customerCity: string;
  customerNotes: string;
  paymentMethod: string;
  fastPay: string;
  zainCash: string;
  fib: string;
  cashOnDelivery: string;
  orderSuccess: string;
  orderSuccessDesc: string;
  invoiceId: string;
  close: string;

  // Contact
  contactTitle: string;
  contactSubtitle: string;
  directWhatsApp: string;
  directTelegram: string;
  fullName: string;
  emailOrPhone: string;
  message: string;
  sendMessage: string;
  messageSent: string;
  messageSentDesc: string;

  // Gallery
  galleryTitle: string;
  gallerySubtitle: string;
  allMedia: string;
  photos: string;
  videos: string;
  aiCreations: string;

  // AI Assistant Chatbot
  supportBotTitle: string;
  supportBotSubtitle: string;
  askSupportPlaceholder: string;
  quickQuestions: string;

  // Responsive & Common
  back: string;
  apply: string;
  cancel: string;
  viewDetails: string;
  instantAccess: string;
}

export const translations: Record<Language, Translations> = {
  ku: {
    appName: '𝙓𝙑-𝘼𝙄',
    tagline: 'پلاتفۆرمی سەربەخۆی ژیریی دەستکرد، ستۆدیۆی وێنە و پاراستنی سایبەری',
    search: 'گەڕان',
    searchPlaceholder: 'بگەڕێ بۆ ئامراز، ستۆدیۆ، بەرهەم، یان پرسیار...',
    theme: 'ڕووکار',
    lightMode: 'ڕووی ڕووناک',
    darkMode: 'ڕووی تاریک',
    language: 'زمان',
    signIn: 'چوونەژوورەوە',
    signOut: 'دەرچوون',
    account: 'هەژمارەکەم',
    store: 'فرۆشگا و داواکاری',
    gallery: 'گاڵەری وێنە و ڤیدیۆ',
    contact: 'پەیوەندی و پشتگیری',
    features: 'تایبەتمەندییەکان',
    imageStudio: 'ستۆدیۆی وێنە',
    agentRunner: '⚡ ئەیجنت (Run AI)',
    aiChatbot: 'چاتبۆتی AI',
    whatsApp: 'واتسئاپ',
    telegram: 'تێلێگرام',

    bannerBadge: 'شۆڕشێکی نوێ',
    bannerText: 'هەرچەندە ئێمە دەمێکە ئەیجنتمان هەیە بەڵام ئەمە شۆڕشێکی نوێیە لە زیرەکی دەستکرد؛ تۆ تەنها داوا ئەکەی، ڤی ئێکس خۆی بۆت ئامادە ئەکات و ڕەنیشی ئەکات — هەر وێبسایتێک بە کەمتر لە ٥ دەقە!',
    heroTitle: 'تۆ تەنها داوا بکە، ڤی ئێکس خۆی ئامادەی دەکات و ڕەنی دەکات!',
    heroDesc: 'شۆڕشێکی نوێ لە زیرەکی دەستکرد؛ هەر وێبسایتێک پێت خۆشە تەنها بە کەمتر لە ٥ دەقە دروستی بکە و ڕەنی بکە!',

    pillImageStudio: '🎨 ستۆدیۆی ئیدیتکردنی وێنە (لابردنی لۆگۆ و نووسین)',
    pillAgentAi: '⚡ Agent AI: هەر وێبسایتێک داوابکە، بە کەمتر لە ٥ دەقە ڕەنی دەکات',
    pillCyberCheck: '🛡️ /check https://example.com',
    pillProEdit: '✨ ئیدیتکردنی پرۆفیشناڵ بە ژیریی دەستکرد',
    pillLocation: '📍 دۆزینەوەی شوێن لە وێنەدا (/location)',
    pillShop: '🛍️ فرۆشگای خزمەتگوزاری و داواکارییەکان',
    pillContactUs: '💬 پەیوەندی بە واتسئاپ و تێلێگرام',
    pillGallery: '🖼️ بینینی گاڵەری و نموونەی کارەکان',

    storeTitle: 'فرۆشگا و سیستمی داواکاری 𝙓𝙑-𝘼𝙄',
    storeSubtitle: 'باشترین خزمەتگوزارییەکانی وێبسایت، ئیدیتکردنی وێنە، و سیستەمی زیرەکی دەستکرد داوابکە',
    addToCart: 'زیادکردن بۆ سەبەتە',
    inCart: 'لە سەبەتەدایە',
    cart: 'سەبەتەی کڕین',
    emptyCart: 'سەبەتەکەت بەتاڵە',
    total: 'کۆی گشتی',
    checkout: 'تەواوکردنی داواکاری',
    orderNow: 'ناردنی داواکاری',
    customerName: 'ناوی تەواو',
    customerPhone: 'ژمارەی مۆبایل / واتسئاپ',
    customerCity: 'شار / ناونیشان',
    customerNotes: 'تێبینی یان داواکاری تایبەت',
    paymentMethod: 'شێوازی پارەدان',
    fastPay: 'فFastPay',
    zainCash: 'ZainCash',
    fib: 'FIB (بانکی یەکەمی عێراق)',
    cashOnDelivery: 'کاش لە کاتی گەیشتن (Cash on Delivery)',
    orderSuccess: 'داواکارییەکەت بە سەرکەوتوویی تۆمارکرا!',
    orderSuccessDesc: 'سوپاس بۆ داواکارییەکەت. تیمی 𝙓𝙑-𝘼𝙄 لە ماوەیەکی کەمدا لە ڕێگەی واتسئاپ یان تەلەفۆن پەیوەندیت پێوە دەکەن.',
    invoiceId: 'کۆدی داواکاری',
    close: 'داخستن',

    contactTitle: 'پەیوەندی ڕاستەوخۆ و پشتگیری',
    contactSubtitle: 'ئێمە لە هەموو کاتێکدا لە ڕێگەی واتسئاپ، تێلێگرام یان فۆرمی ڕاستەوخۆ لە خزمەتتداین',
    directWhatsApp: 'پەیامی ڕاستەوخۆ لە واتسئاپ',
    directTelegram: 'پەیوەندی لە تێلێگرام',
    fullName: 'ناوی بەڕێزت',
    emailOrPhone: 'ئیمێڵ یان ژمارەی مۆبایل',
    message: 'دەقی پەیامەکەت',
    sendMessage: 'ناردنی پەیام',
    messageSent: 'پەیامەکەت گەیشت!',
    messageSentDesc: 'سوپاس بۆ پەیوەندیکردنت، بە زووترین کات وەڵامت دەدەینەوە.',

    galleryTitle: 'گاڵەری وێنە و ڤیدیۆکانی 𝙓𝙑-𝘼𝙄',
    gallerySubtitle: 'نموونەی کاری ستۆدیۆی وێنە، لابردنی لۆگۆ، ئەپسکەیل، و ڤیدیۆکانی فێرکاری',
    allMedia: 'هەموو',
    photos: 'وێنەکان',
    videos: 'ڤیدیۆکان',
    aiCreations: 'کاری ژیری دەستکرد',

    supportBotTitle: 'چاتبۆتی AI بۆ وەڵامدانەوەی کڕیارەکان',
    supportBotSubtitle: 'وەڵامدانەوەی دەستبەجێ بە کوردی، عەرەبی و ئینگلیزی دەربارەی خزمەتگوزارییەکان',
    askSupportPlaceholder: 'پرسیارێک دەربارەی نرخ، داواکاری یان وێنە بکە...',
    quickQuestions: 'پرسیارە باوەکان:',

    back: 'گەڕانەوە',
    apply: 'جێبەجێکردن',
    cancel: 'پاشگەزبوونەوە',
    viewDetails: 'بینینی وردەکاری',
    instantAccess: 'دەستبەجێ بەبێ کۆد',
  },
  ar: {
    appName: '𝙓𝙑-𝘼𝙄',
    tagline: 'منصة الذكاء الاصطناعي السيادي، ستوديو الصور والأمن السيبراني',
    search: 'بحث',
    searchPlaceholder: 'ابحث عن الأدوات، الاستوديو، المنتجات، أو الأسئلة...',
    theme: 'المظهر',
    lightMode: 'الوضع الفاتح',
    darkMode: 'الوضع الداكن',
    language: 'اللغة',
    signIn: 'تسجيل الدخول',
    signOut: 'تسجيل الخروج',
    account: 'حسابي',
    store: 'المتجر والطلبات',
    gallery: 'معرض الصور والفيديو',
    contact: 'الاتصال والدعم',
    features: 'المميزات',
    imageStudio: 'ستوديو الصور',
    agentRunner: '⚡ الوكيل الذكي (Run AI)',
    aiChatbot: 'بوت الذكاء الاصطناعي',
    whatsApp: 'واتساب',
    telegram: 'تيليجرام',

    bannerBadge: 'ثورة جديدة',
    bannerText: 'رغم امتلاكنا للوكلاء منذ فترة، إلا أن هذه ثورة جديدة في الذكاء الاصطناعي: أنت فقط تطلب، وVX يجهز لك الموقع ويشغّله فوراً — أي موقع تريده خلال أقل من 5 دقائق!',
    heroTitle: 'أنت فقط تطلب، وVX يجهّزه ويشغّله لك فوراً!',
    heroDesc: 'ثورة جديدة في الذكاء الاصطناعي: بناء وتشغيل أي موقع ويب تريده خلال أقل من 5 دقائق، مع ستوديو الصور وفحص الأمان.',

    pillImageStudio: '🎨 ستوديو تعديل الصور (إزالة النصوص والشعارات)',
    pillAgentAi: '⚡ Agent AI: اطلب أي موقع وسيقوم بتشغيله خلال أقل من 5 دقائق',
    pillCyberCheck: '🛡️ /check https://example.com',
    pillProEdit: '✨ تعديل احترافي بالذكاء الاصطناعي',
    pillLocation: '📍 تحديد الموقع من الصور (/location)',
    pillShop: '🛍️ متجر الخدمات والطلبات المباشرة',
    pillContactUs: '💬 التواصل عبر واتساب وتيليجرام',
    pillGallery: '🖼️ استعراض معرض الأعمال والنماذج',

    storeTitle: 'متجر ونظام طلبات 𝙓𝙑-𝘼𝙄',
    storeSubtitle: 'اطلب أفضل خدمات المواقع، وتعديل الصور، وحلول الذكاء الاصطناعي المخصصة',
    addToCart: 'إضافة إلى السلة',
    inCart: 'في السلة',
    cart: 'سلة المشتريات',
    emptyCart: 'السلة فارغة حالياً',
    total: 'المجموع الكلي',
    checkout: 'إتمام الطلب',
    orderNow: 'إرسال الطلب الآن',
    customerName: 'الاسم الكامل',
    customerPhone: 'رقم الهاتف / واتساب',
    customerCity: 'المدينة / العنوان',
    customerNotes: 'ملاحظات أو طلبات خاصة',
    paymentMethod: 'طريقة الدفع',
    fastPay: 'فاست باي (FastPay)',
    zainCash: 'زين كاش (ZainCash)',
    fib: 'المصرف العراقي الأول (FIB)',
    cashOnDelivery: 'الدفع عند الاستلام (Cash on Delivery)',
    orderSuccess: 'تم تسجيل طلبك بنجاح!',
    orderSuccessDesc: 'شكراً لطلبك. سيتواصل معك فريق 𝙓𝙑-𝘼𝙄 قريباً عبر واتساب أو الهاتف لتأكيد التفاصيل.',
    invoiceId: 'رقم الفاتورة والطلب',
    close: 'إغلاق',

    contactTitle: 'الاتصال المباشر وفريق الدعم',
    contactSubtitle: 'نحن متاحون دائماً لخدمتكم عبر واتساب وتيليجرام أو من خلال نموذج المراسلة الفوري',
    directWhatsApp: 'مراسلة مباشرة عبر واتساب',
    directTelegram: 'التواصل عبر تيليجرام',
    fullName: 'الاسم الكريم',
    emailOrPhone: 'البريد الإلكتروني أو الهاتف',
    message: 'نص الرسالة',
    sendMessage: 'إرسال الرسالة',
    messageSent: 'تم استلام رسالتك!',
    messageSentDesc: 'شكراً لتواصلك معنا، سنرد على استفسارك في أقرب وقت ممكن.',

    galleryTitle: 'معرض صور وفيديوهات 𝙓𝙑-𝘼𝙄',
    gallerySubtitle: 'نماذج أعمال ستوديو الصور، إزالة العلامات المائية، والدروس التعليمية',
    allMedia: 'الكل',
    photos: 'الصور',
    videos: 'الفيديوهات',
    aiCreations: 'أعمال الذكاء الاصطناعي',

    supportBotTitle: 'بوت الذكاء الاصطناعي لخدمة العملاء',
    supportBotSubtitle: 'إجابات فورية بالعربية والكردية والإنجليزية حول الخدمات والأسعار',
    askSupportPlaceholder: 'اسأل عن الأسعار، طريقة الطلب، أو تعديل الصور...',
    quickQuestions: 'أسئلة شائعة:',

    back: 'رجوع',
    apply: 'تطبيق',
    cancel: 'إلغاء',
    viewDetails: 'عرض التفاصيل',
    instantAccess: 'دخول فوري بدون كود',
  },
  en: {
    appName: '𝙓𝙑-𝘼𝙄',
    tagline: 'Sovereign Intelligence, AI Image Studio & Cybersecurity Platform',
    search: 'Search',
    searchPlaceholder: 'Search tools, studio, store products, or questions...',
    theme: 'Theme',
    lightMode: 'Light Mode',
    darkMode: 'Dark Mode',
    language: 'Language',
    signIn: 'Sign In',
    signOut: 'Sign Out',
    account: 'My Account',
    store: 'Store & Orders',
    gallery: 'Media Gallery',
    contact: 'Contact & Support',
    features: 'Features',
    imageStudio: 'Image Studio',
    agentRunner: '⚡ Agent (Run AI)',
    aiChatbot: 'AI Assistant',
    whatsApp: 'WhatsApp',
    telegram: 'Telegram',

    bannerBadge: 'NEW REVOLUTION',
    bannerText: 'Although we have had agents for a long time, this is a new revolution in AI: You just ask, and VX prepares and runs it for you — Any website in under 5 minutes!',
    heroTitle: 'You just ask, VX prepares and runs it for you!',
    heroDesc: 'A new revolution in AI: Build and run any website in under 5 minutes, with Image Studio and Cyber Security audits.',

    pillImageStudio: '🎨 AI Image Studio (Remove Text & Logos)',
    pillAgentAi: '⚡ Agent AI: Request any website, built and running in under 5 mins',
    pillCyberCheck: '🛡️ /check https://example.com',
    pillProEdit: '✨ Professional AI Photo Enhancement',
    pillLocation: '📍 Locate Photos on OpenMap (/location)',
    pillShop: '🛍️ Order AI Services & Store Products',
    pillContactUs: '💬 Chat on WhatsApp & Telegram',
    pillGallery: '🖼️ Explore Media Showcase Gallery',

    storeTitle: '𝙓𝙑-𝘼𝙄 Store & Ordering System',
    storeSubtitle: 'Order premium full-stack web builds, photo studio packages, and custom cybersecurity solutions',
    addToCart: 'Add to Cart',
    inCart: 'In Cart',
    cart: 'Shopping Cart',
    emptyCart: 'Your cart is currently empty',
    total: 'Total Amount',
    checkout: 'Proceed to Checkout',
    orderNow: 'Submit Order Now',
    customerName: 'Full Name',
    customerPhone: 'Phone / WhatsApp Number',
    customerCity: 'City / Address',
    customerNotes: 'Project Notes & Special Requests',
    paymentMethod: 'Payment Method',
    fastPay: 'FastPay',
    zainCash: 'ZainCash',
    fib: 'First Iraqi Bank (FIB)',
    cashOnDelivery: 'Cash on Delivery',
    orderSuccess: 'Your Order Has Been Recorded!',
    orderSuccessDesc: 'Thank you for your order. The 𝙓𝙑-𝘼𝙄 specialist team will reach out via WhatsApp/Phone shortly.',
    invoiceId: 'Order Invoice Reference',
    close: 'Close',

    contactTitle: 'Direct Contact & Support',
    contactSubtitle: 'We are available 24/7 via WhatsApp, Telegram, or through our instant inquiry form',
    directWhatsApp: 'Chat on WhatsApp',
    directTelegram: 'Contact on Telegram',
    fullName: 'Your Full Name',
    emailOrPhone: 'Email or Mobile Number',
    message: 'Your Message',
    sendMessage: 'Send Message',
    messageSent: 'Message Received!',
    messageSentDesc: 'Thank you for reaching out. We will respond to your inquiry promptly.',

    galleryTitle: '𝙓𝙑-𝘼𝙄 Media Gallery',
    gallerySubtitle: 'Explore showcase photos, before/after watermark removal, resolution upscaling, and tutorials',
    allMedia: 'All',
    photos: 'Photos',
    videos: 'Videos',
    aiCreations: 'AI Generated',

    supportBotTitle: 'Customer AI Chatbot Assistant',
    supportBotSubtitle: 'Instant automated answers in Kurdish, Arabic & English for orders and services',
    askSupportPlaceholder: 'Ask about pricing, how to place an order, or image tools...',
    quickQuestions: 'Frequent questions:',

    back: 'Back',
    apply: 'Apply',
    cancel: 'Cancel',
    viewDetails: 'View Details',
    instantAccess: 'Instant 1-Click Access',
  },
};
