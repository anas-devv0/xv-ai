/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import exifr from 'exifr';
import { ModelSelectorModal } from './components/ModelSelectorModal';
import { CyberDrawer } from './components/CyberDrawer';
import { FeaturesShowcaseModal } from './components/FeaturesShowcaseModal';
import { RedCircleMapModal } from './components/RedCircleMapModal';
import { AuthGateModal, AuthUser } from './components/AuthGateModal';
import { ImageEditStudioModal } from './components/ImageEditStudioModal';
import { ThemeLanguageBar } from './components/ThemeLanguageBar';
import { QuickSearchBar } from './components/QuickSearchBar';
import { StoreOrderModal } from './components/StoreOrderModal';
import { MediaGalleryModal } from './components/MediaGalleryModal';
import { UserProfileModal } from './components/UserProfileModal';
import { AutonomousAgentRunnerModal } from './components/AutonomousAgentRunnerModal';
import { LiveWebsiteRunnerCard } from './components/LiveWebsiteRunnerCard';
import { ProjectZipDownloaderCard } from './components/ProjectZipDownloaderCard';
import { VxLandingPage } from './components/VxLandingPage';
import { Language, translations } from './i18n/translations';
import { SecurityReportData, ReconData, LocationInfo } from './types';
import { Search, ShoppingBag, Sparkles, Image as ImageIcon, FolderArchive } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'ai';
  text?: string;
  imageSrc?: string;
  isPinned?: boolean;
  isLiked?: boolean;
  usedTool?: string;
  exifData?: {
    latitude?: number;
    longitude?: number;
    Make?: string;
    Model?: string;
    DateTimeOriginal?: string | Date;
    altitude?: number;
  };
  locationData?: LocationInfo;
  isAuditReport?: boolean;
  auditData?: {
    target: string;
    score: number;
    grade: string;
    point1: { title: string; status: string; desc: string };
    point2: { title: string; status: string; desc: string };
    point3: { title: string; status: string; desc: string };
    point4: { title: string; status: string; desc: string };
    point5: { title: string; status: string; desc: string };
  };
  isReconReport?: boolean;
  reconData?: ReconData;
  isWebsiteRun?: boolean;
  websiteRunData?: {
    url: string;
    title: string;
    status: number;
    responseTimeMs: number;
    tls: string;
    deviceView?: 'desktop' | 'tablet' | 'mobile';
  };
  isZipDownload?: boolean;
}

let globalMessageSeq = 0;
export const generateUniqueMsgId = (prefix: string = 'msg'): string => {
  globalMessageSeq += 1;
  const rand = Math.random().toString(36).substring(2, 9);
  return `${prefix}-${Date.now()}-${globalMessageSeq}-${rand}`;
};

export const KNOWN_CITIES: Record<string, { lat: number; lng: number; name: string }> = {
  baghdad: { lat: 33.3152, lng: 44.3661, name: 'بەغدا (Baghdad)' },
  sulaymaniyah: { lat: 35.5669, lng: 45.4167, name: 'سلێمانی (Sulaymaniyah)' },
  slemani: { lat: 35.5669, lng: 45.4167, name: 'سلێمانی (Sulaymaniyah)' },
  sulaimani: { lat: 35.5669, lng: 45.4167, name: 'سلێمانی (Sulaymaniyah)' },
  سلێمانی: { lat: 35.5669, lng: 45.4167, name: 'سلێمانی (Sulaymaniyah)' },
  بەغدا: { lat: 33.3152, lng: 44.3661, name: 'بەغدا (Baghdad)' },
  بغداد: { lat: 33.3152, lng: 44.3661, name: 'بەغدا (Baghdad)' },
  duhok: { lat: 36.8679, lng: 42.9880, name: 'دهۆک (Duhok)' },
  دهۆک: { lat: 36.8679, lng: 42.9880, name: 'دهۆک (Duhok)' },
  kirkuk: { lat: 35.4681, lng: 44.3922, name: 'کەرکووک (Kirkuk)' },
  کەرکووک: { lat: 35.4681, lng: 44.3922, name: 'کەرکووک (Kirkuk)' },
  کەرکوک: { lat: 35.4681, lng: 44.3922, name: 'کەرکووک (Kirkuk)' },
  کرکوک: { lat: 35.4681, lng: 44.3922, name: 'کەرکووک (Kirkuk)' },
  basra: { lat: 30.5085, lng: 47.7804, name: 'بەسرە (Basra)' },
  بەسرە: { lat: 30.5085, lng: 47.7804, name: 'بەسرە (Basra)' },
  البصرة: { lat: 30.5085, lng: 47.7804, name: 'بەسرە (Basra)' },
  mosul: { lat: 36.3400, lng: 43.1300, name: 'موسڵ (Mosul)' },
  موسڵ: { lat: 36.3400, lng: 43.1300, name: 'موسڵ (Mosul)' },
  الموصل: { lat: 36.3400, lng: 43.1300, name: 'موسڵ (Mosul)' },
  rawanduz: { lat: 36.6494, lng: 44.5367, name: 'ڕواندز (Rawanduz)' },
  ڕواندز: { lat: 36.6494, lng: 44.5367, name: 'ڕواندز (Rawanduz)' },
  رواندز: { lat: 36.6494, lng: 44.5367, name: 'ڕواندز (Rawanduz)' },
  soran: { lat: 36.6547, lng: 44.5422, name: 'سۆران (Soran)' },
  سۆران: { lat: 36.6547, lng: 44.5422, name: 'سۆران (Soran)' },
  choman: { lat: 36.6341, lng: 44.8872, name: 'چۆمان (Choman)' },
  چۆمان: { lat: 36.6341, lng: 44.8872, name: 'چۆمان (Choman)' },
  amedi: { lat: 37.0911, lng: 43.4878, name: 'ئامێدی (Amedi)' },
  ئامێدی: { lat: 37.0911, lng: 43.4878, name: 'ئامێدی (Amedi)' },
  halabja: { lat: 35.1778, lng: 45.9861, name: 'هەڵەبجە (Halabja)' },
  هەڵەبجە: { lat: 35.1778, lng: 45.9861, name: 'هەڵەبجە (Halabja)' },
  zakho: { lat: 37.1439, lng: 42.6874, name: 'زاخۆ (Zakho)' },
  زاخۆ: { lat: 37.1439, lng: 42.6874, name: 'زاخۆ (Zakho)' },
  kalar: { lat: 34.6292, lng: 45.3197, name: 'کەلار (Kalar)' },
  کەلار: { lat: 34.6292, lng: 45.3197, name: 'کەلار (Kalar)' },
  ranya: { lat: 36.2553, lng: 44.8828, name: 'ڕانیە (Ranya)' },
  ڕانیە: { lat: 36.2553, lng: 44.8828, name: 'ڕانیە (Ranya)' },
  dukan: { lat: 35.9525, lng: 44.9575, name: 'دووکان (Dukan)' },
  دووکان: { lat: 35.9525, lng: 44.9575, name: 'دووکان (Dukan)' },
  hawraman: { lat: 35.2536, lng: 46.2214, name: 'هەورامان (Hawraman)' },
  هەورامان: { lat: 35.2536, lng: 46.2214, name: 'هەورامان (Hawraman)' },
  erbil: { lat: 36.1911, lng: 44.0091, name: 'هەولێر (Erbil)' },
  هەولێر: { lat: 36.1911, lng: 44.0091, name: 'هەولێر (Erbil)' },
  hawler: { lat: 36.1911, lng: 44.0091, name: 'هەولێر (Erbil)' },
  arbil: { lat: 36.1911, lng: 44.0091, name: 'هەولێر (Erbil)' },
  tehran: { lat: 35.6892, lng: 51.3890, name: 'تاران (Tehran)' },
  تاران: { lat: 35.6892, lng: 51.3890, name: 'تاران (Tehran)' },
  طهران: { lat: 35.6892, lng: 51.3890, name: 'تاران (Tehran)' },
  istanbul: { lat: 41.0082, lng: 28.9784, name: 'ئەستەنبوڵ (Istanbul)' },
  ئەستەنبوڵ: { lat: 41.0082, lng: 28.9784, name: 'ئەستەنبوڵ (Istanbul)' },
  إسطنبول: { lat: 41.0082, lng: 28.9784, name: 'ئەستەنبوڵ (Istanbul)' },
  ankara: { lat: 39.9334, lng: 32.8597, name: 'ئەنقەرە (Ankara)' },
  damascus: { lat: 33.5138, lng: 36.2765, name: 'دیمەشق (Damascus)' },
  amman: { lat: 31.9454, lng: 35.9284, name: 'عەممان (Amman)' },
  dubai: { lat: 25.2048, lng: 55.2708, name: 'دوبەی (Dubai)' },
  london: { lat: 51.5074, lng: -0.1278, name: 'لەندەن (London)' },
  paris: { lat: 48.8566, lng: 2.3522, name: 'پاریس (Paris)' },
  tokyo: { lat: 35.6762, lng: 139.6503, name: 'تۆکیۆ (Tokyo)' },
  washington: { lat: 38.9072, lng: -77.0369, name: 'واشنتن (Washington)' },
  'new york': { lat: 40.7128, lng: -74.0060, name: 'نیویۆرک (New York)' },
};

export async function resolveCityTarget(input: string): Promise<LocationInfo | null> {
  const clean = input
    .replace(/^\/(location|geo|map|loc)\s*/i, '')
    .replace(/(شوێنی|نەخشەی|بۆم بدۆزەرەوە|دیاریبکە|لە کوێیە|شارى|شاری|قەزای|پارێزگای)\s*/g, '')
    .trim();
  if (!clean) return null;

  const lower = clean.toLowerCase();
  for (const [key, val] of Object.entries(KNOWN_CITIES)) {
    if (lower === key || lower.includes(key)) {
      return {
        latitude: val.lat,
        longitude: val.lng,
        placeName: val.name,
        source: 'visual_estimate',
        confidence: '100% (دیاریکراوی ڕاستەوخۆ)',
      };
    }
  }

  // Dynamic Nominatim lookup for any other world city or location
  try {
    const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(clean)}&limit=1`);
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      const item = data[0];
      return {
        latitude: parseFloat(item.lat),
        longitude: parseFloat(item.lon),
        placeName: item.display_name.split(',')[0] || clean,
        source: 'visual_estimate',
        confidence: 'پێشبینی جوگرافی (Geocoded)',
      };
    }
  } catch {
    // fallback
  }

  return null;
}

export function getIntelligentKurdishAnswer(prompt: string, modelName: string): string {
  const p = (prompt || '').toLowerCase();

  if (
    p.includes('5خاڵ') ||
    p.includes('٥ خاڵ') ||
    p.includes('5 خاڵ') ||
    p.includes('٥خاڵ') ||
    p.includes('ئەم5خاڵە') ||
    p.includes('ئەم 5') ||
    p.includes('گەورەیی مۆدێل') ||
    p.includes('anas devv') ||
    p.includes('anas')
  ) {
    return `## ⚡ 𝙓𝙑-𝘼𝙄 | پلاتفۆرمی سەربەخۆی ژیریی دەستکرد و ٥ خاڵەکەی پشکنینی سایبەری

سڵاو و ڕێز؛ ئەم ماڵپەڕە پلاتفۆرمێکی گشتی و سەربەخۆی ژیریی دەستکردە (**Independent Public AI Platform**) و هی هیچ کەس یان خاوەنێکی دیاریکراو نییە. سیستەمی **𝙓𝙑-𝘼𝙄** لەوپەڕی ئامادەباشیدایە و هەموو تایبەتمەندییەکان و ٥ خاڵە ئەمنییەکە بەبێ هیچ هەڵەیەک (Zero Error) کاردەکەن:

### 🧠 گەورەیی مۆدێلەکە و توانای بیرکردنەوە:
گەورەیی مۆدێلەکە لە توانای بیرکردنەوەی قووڵ و شیکاریی خێرایەدایە، توانای دیزاین و کۆدینگی لە ئاستی هەرە گەورەترین سیستمەکانی زیرەکی دەستکردی جیهاندایە.

---

### 🛡️ ٥ خاڵەکەی سووتی سایبەر سکیوریتی (فەرمانی \`/check <url>\`):
تەنها لینکێکی وێبسایت بنێرە لەگەڵ فەرمانی \`/check\` تا دەستبەجێ ڕاپۆرتەکە دەربچێت:
١. **گەڕان بۆ ڕاوتەکان (Admin Routes) و Nmap**: پشکنینی ڕاوتە هەستیارەکانی وەک \`/admin\`، دۆخی پۆرتە کراوەکان و فلتەرکردنیان بە پارێزراوی.
٢. **چێک کردنی ڕەیت لمتەر (Rate Limiter)**: پشکنینی بەرگری دژی هێرشی Brute-Force و سنووردارکردنی داواکارییەکان (DDoS protection).
٣. **گەڕان بەدوای دزەکردنی ئینڤایەرمێنت (.env) و دۆکیۆمێنت**: دڵنیابوونەوە لە سەلامەتی کلیلە نهێنییەکان و ڕێگری لە دزەپێکردنی داتاکان.
٤. **دۆزینەوەی کەلێنی SSL**: پشکنینی بڕوانامە، مۆدێرنبوونی پرۆتۆکۆڵی TLS 1.3، و سەردێڕە ئەمنییەکان (HSTS, CSP).
٥. **دەیتابەیس ئینجێکشن (SQL Injection)**: شیکاریی هایۆریستیک بۆ نەبوونی کەلێنی ئینجێکشن لە پارامیتەر و فۆرمەکاندا.

---

### 🌟 ٦ تایبەتمەندییە دەستنیشانکراوەکە:
١- **ناردنی وێنە بۆ 𝙓𝙑-𝘼𝙄 و بینینی**: توانای شیکردنەوەی هەموو وردەکارییەکی وێنەکە و دۆزینەوەی لۆکەیشنی GPS.
٢- **ناردنی ڤیدیۆ و سەیرکردنی**: توانای فێچکردن و پشکنینی ناوەڕۆکی ڤیدیۆ.
٣- **ناردنی وێبسایت و فێتچکردنی بە کەمتر لە ١ خولەک**: گەڕان بەناو هەموو کۆدەکان و دەرهێنانی داتاکان بە خێرایی.
٤- **پین (📌) و ڵایک (❤️) کردنی چاتەکان**: لە ژێر هەر پەیامێک دوگمەی دڵخوازکردن و پینکردن دانراوە.
٥- **سەیڤکردنی هەر چاتێک بە فایل (.txt)**: دوگمەی داگرتن ڕاستەوخۆ گفتوگۆکە لەسەر ئامێرەکەت هەڵدەگرێت.
٦- **دۆزینەوەی لۆکەیشن لەسەر نەخشەی ڕاستەوخۆ (OSINT)**: کاتێک وێنەیەک هاوپێچ دەکەیت، پێگەکەی بە وردی لەسەر نەخشەی کراوە نیشان دەدات.`;
  }

  if (
    p.includes('چۆن دروستکراوە') ||
    p.includes('تەلارسازی') ||
    p.includes('ستاک') ||
    p.includes('how') ||
    p.includes('تەکنەلۆژیا') ||
    p.includes('پڕۆژە') ||
    p.includes('architecture') ||
    p.includes('stack')
  ) {
    return `## 🏗️ تەلارسازی و چۆنیەتی دروستکردنی وێبسایتی 𝙓𝙑-𝘼𝙄

ئەم پلاتفۆرمە سەروەر و بێهاوتایە بە تێکەڵەیەک لە بەهێزترین تەکنەلۆژیاکانی سەردەم دروستکراوە:

### ١. بەشی ڕووکار (Frontend Architecture):
- **React 19 & TypeScript**: بەڕێوەبردنی خێرا، ڕێکخستنی مۆدۆلاری پێکهاتەکان، و مسۆگەرکردنی سەلامەتی داتا.
- **Tailwind CSS v4 & Obsidian Palette**: دیزاینی تاریکی ستایلی قووڵی سایبەرپانک (#0a0a0c) لەگەڵ ڕەنگی زێڕینی درەوشاوە (#e2a545).
- **فۆنت و تایپۆگرافی**: فۆنتی سێریفی Newsreader بۆ هەستێکی مۆدێرن و شاهانە، لەگەڵ JetBrains Mono بۆ ڕوونکردنەوەی فەرمان و کۆدەکان.
- **Leaflet & OpenStreetMap**: بزوێنەری نەخشەی ئینتێراکتیڤ بۆ دۆزینەوە و نیشاندانی شوێنی GPS مێتاداتا کە لە وێنەکان دەردەهێنرێت.
- **Lucide React Icons**: کۆمەڵێک ئایکۆنی ڤێکتۆری بۆ کۆنتڕۆڵکردنی ئاسان.

### ٢. بەشی سێرڤەر و ژیری دەستکرد (Backend & Sovereign AI Engine):
- **Node.js لەگەڵ Express**: سێرڤەرێکی پارێزراو بۆ پەیوەندی بەستن بە خزمەتگوزارییەکان و بەڕێوەبردنی Streaming بە Server-Sent Events (SSE).
- **Google Gemini 3.1 Flash-Lite & 3.8 Flash**: مۆدێلی فرە-میدیا (Multimodal) بۆ وەرگرتنی وەڵامەکان وشە بە وشە بە زمانی کوردی سۆرانی بە تەواوی ڕەوانی.
- **سیستەمی پشکنەری ئەمنی (5-Point Cyber Security Prober)**: شیکاری خێرای ڕاوتەکان (Admin routes/Nmap)، ڕەیت لمتەر و WAF، دزەکردنی .env، دۆخی بڕوانامەی SSL/TLS 1.3، و کەلێنی SQL Injection.

### ٣. توانای کارکردنی سەربەخۆ (Standalone All-in-One):
- هەموو ئەم وێبسایتە دەتوانیت لە فۆرماتی تەنها یەک فایلی سەربەخۆی \`index.html\` کۆپی بکەیت یان دایبەزێنیت لە دوگمەی **کۆدەکان (Code)** لە سەرەوە، کە بەبێ پێویستی بە دابەزاندنی هیچ کتێبخانەیەک لە هەر کۆمپیوتەر یان مۆبایلێک ڕاستەوخۆ کاردەکات!`;
  }

  if (
    p.includes('ئیدیت') ||
    p.includes('لۆگۆ') ||
    p.includes('نووسین') ||
    p.includes('كواليه تى') ||
    p.includes('کوالیتی') ||
    p.includes('وێنە') ||
    p.includes('image')
  ) {
    return `## 🎨 ستۆدیۆی نوێی ئیدیتکردنی وێنە (𝙓𝙑 Image AI Suite)

هەنگاوێکی تر لە ژیریی دەستکرد، ئێستا **𝙓𝙑-𝘼𝙄** خاوەنی توانا و بزوێنەری تایبەتی ئیدیتکردنی وێنەیە:

### ✨ سەرەکیترین تواناکان:
١. **لابردنی نووسین و لۆگۆ (Remove Text & Logo)**: سڕینەوەی هەموو تێکست، ئاوەڕۆک (Watermark) یان لۆگۆ لەسەر وێنە بەبێ تێکچوونی بەشەکانی تر و پڕکردنەوەی خۆکارانەی باکگراوند.
٢. **ئیدیتکردنی پڕۆفیشناڵ (Professional AI Photo Editing)**: ڕێکخستنی سینەمایی ڕووناکی، کۆنتراست، شێوازی ڕەنگ، و فلتەری ستۆدیۆ.
٣. **بەرزکردنەوەی کوالیتی (AI Super-Resolution 4K Upscale)**: زیادکردنی ڕوونی و وردەکارییەکان و پاککردنەوەی ژاوەژاو (Noise reduction).
٤. **دروستکردنی وێنە بە ژیری دەستکرد**: گۆڕینی نووسین و خەیاڵ بۆ وێنەی هونەری بەرز بە شێوازی وەسفکراو.

دەتوانیت لە ڕێگەی دوگمەی **ستۆدیۆی وێنە** لە بەشی سەرەوەی ماڵپەڕ ڕاستەوخۆ دەست بە ئیدیتکردن بکەیت!`;
  }

  if (
    p.includes('ئەم وێبسایتەم بۆ ڕەن') ||
    p.includes('وێبسایتەم بۆ ڕەن') ||
    p.includes('لینکەم بۆ ڕەن') ||
    p.includes('لینکەکەم بۆ ڕەن') ||
    p.includes('ڕەنی کە') ||
    p.includes('ڕەنی بکە') ||
    p.includes('بۆم ڕەن بکە') ||
    p.includes('بۆم ڕەن کە')
  ) {
    return `سەرچاو! بەسەرچاو؛ هەر لینکێکی وێبسایت بنێریت یان پەیستی بکەیت (وەک: \`https://example.com\`)، دەستبەجێ 𝙓𝙑-𝘼I بۆت ڕەن دەکات لەناو ساندبۆکسی ڕاستەوخۆ و ئەنجامی کاراکراوەکەت بە تەواوی بۆ دەنێرێتەوە 🚀`;
  }

  if (
    p.includes('agent') ||
    p.includes('ئەیجنت') ||
    p.includes('نارنیکس') ||
    p.includes('full stack') ||
    p.includes('فول ستاک') ||
    p.includes('دروستکردنی وێبسایت') ||
    p.includes('شۆڕش') ||
    p.includes('شۆرش') ||
    p.includes('٥ دەقە') ||
    p.includes('5 دەقە') ||
    p.includes('خۆی بۆت ئامادە')
  ) {
    return `## 🚀 شۆڕشێکی نوێ لە زیرەکی دەستکرد | ڤی ئێکس (𝙓𝙑 Agent AI)

هەرچەندە ئێمە دەمێکە ئەیجنتمان هەیە، بەڵام ئەمە **شۆڕشێکی نوێیە لە زیرەکی دەستکرد**!
تۆ تەنها ئەوەی لەسەرت پێویستە ئەوەیە کە **داوا بکەیت**. **ڤی ئێکس (VX)** خۆی بۆت ئامادە ئەکات و **ڕەنیشی ئەکات (Build & Run)**؛ هەر وێبسایتێکت پێ خۆش بێت تەنها بە **کەمتر لە ٥ دەقە**!

### 💡 ئەم شۆڕشە تەکنەلۆژییە چی لەخۆدەگرێت؟
ئێستا لە کەمتر لە ٥ خولەکدا، تەنانەت بەبێ پێویستی بە ڕوونکردنەوەی درێژ، دەتوانیت وێبسایتێکی تەواو و پڕۆفیشناڵ بەدەستبهێنیت:
١. **دیزاینی سەردەمیانە و UI/UX**: ڕووکاری ڕیسپۆنسیڤ، دۆخی تاریک، مۆبایل و کۆمپیوتەر.
٢. **فرۆنت ئیند (Frontend Architecture)**: بە React 19 و پێکهاتەی خێرا.
٣. **باکیند (Backend Server Engine)**: بە Node.js Express و API کاراکراو.
٤. **داتابەیس (Database Persistence)**: بە خشتەکانی PostgreSQL و شیکاری ستراکتەر.
٥. **ڕەنکردنی ڕاستەوخۆ (Live Sandbox Run)**: ڕاستەوخۆ دەتوانیت کارلێک لەگەڵ دوگمە و تایبەتمەندییەکان بکەیت.

دەتوانیت لە ڕێگەی دوگمەی **⚡ ئەیجنت (Run AI)** لە سەرەوە ڕاستەوخۆ دەست بە دروستکردن و ڕەنکردنی هەر وێبسایتێک بکەیت!`;
  }

  if (
    p.includes('بەرگ') ||
    p.includes('ماکس') ||
    p.includes('ئەیس') ||
    p.includes('پلان') ||
    p.includes('plan')
  ) {
    return `## ⚡ پلاتفۆرمی 𝙓𝙑-𝘼𝙄 بەبێ پلان و بەربەستە

هەموو تایبەتمەندییەکان و تواناکانی **𝙓𝙑-𝘼𝙄** (ستۆدیۆی ئیدیتکردنی وێنە، لابردنی نووسین و لۆگۆ، ئەیجنتی Full Stack، دۆزینەوەی لۆکەیشن، و پشکنینی سایبەری ٥ خاڵەکە) بە تەواوی بەبێ پێویستی بە پلان یان بەربەست بەردەستن!`;
  }

  if (
    p.includes('کۆد') ||
    p.includes('کۆدەکان') ||
    p.includes('source') ||
    p.includes('code')
  ) {
    return `## 🔒 سەلامەتی و پاراستنی سەروەری سیستەم

کۆدەکانی ناوەوەی پلاتفۆرمی **𝙓𝙑-𝘼𝙄** لەلایەن سیستەمی بەرگری سەربەخۆوە پارێزراون بۆ ڕێگری لە دەستکاری نەشیاو. 
ئێستا سیستەمی هاتنەژوورەوەی پارێزراو کارایە کە بە **Google Play / Google**، **Apple ID**، یان بە **Gmail و کۆدی دڵنیابوونەوەی ٦ ژمارەیی (OTP)** دڵنیابوونەوە لە بەکارهێنەران دەکات.

هەروەها دەتوانیت لە ڕێگەی **ئەیجنتی نارنیکس (Agent AI Full Stack)** داوای دروستکردنی هەر وێبسایت، کۆد، باکیند، یان سکریپتێک بکەیت تا ڕاستەوخۆ لە چاتەکەدا بۆت دروستبکات!`;
  }

  if (p.includes('تایبەتمەند') || p.includes('توانا') || p.includes('چی پێدەکرێ') || p.includes('چی پێئەکرێ') || p.includes('features') || p.includes('٦')) {
    return `## ⚡ تایبەتمەندییە سەرەکییەکانی 𝙓𝙑-𝘼𝙄

پلاتفۆرمی 𝙓𝙑-𝘼𝙄 خاوەنی ٦ تایبەتمەندی بەهێزە لەگەڵ سووتی پشکنینی سایبەری:

### 🌟 ٦ تایبەتمەندییە بێهاوتاکە:
١. **ناردنی وێنە و بینینی ڕاستەوخۆ (Visual Recon)**: توانای تەماشاکردن و شیکردنەوەی هەموو وردەکارییەکی وێنە و دەرهێنانی GPS EXIF.
٢. **شیکاریی ڤیدیۆ و ناوەڕۆک**: پشکنینی فایل و لینکی ڤیدیۆ و تێگەیشتن لە چرکەساتی ڕووداوەکان.
٣. **فیتچکردنی وێبسایت بە کەمتر لە ١ دەقە**: هێنانی داتای هەر وێبسایتێک و پشکنینی کۆدەکانی لە کەمترین کاتدا.
٤. **پین (📌) و ڵایک (❤️) کردنی چاتەکان**: کۆنتڕۆڵکردن و جیاکردنەوەی پەیامە گرنگەکان.
٥. **سەیڤکردنی چات وەک فایل (.txt)**: داگرتن و پاراستنی تەواوی گفتوگۆکە بە یەک کلیل.
٦. **دۆزینەوەی لۆکەیشن لەسەر نەخشەی زیندوو**: دەرهێنانی داتای جوگرافی لە وێنە و نیشاندانی شوێنەکە لەسەر OpenStreetMap بە وردی.

### 🛡️ پشکنەری سایبەر سەکیوریتی (فەرمانی \`/check <url>\`):
- **١. گەڕان بۆ ڕاوتەکان (Admin Routes & Nmap)**: پشکنینی دەروازە دانەخراوەکان.
- **٢. چێک کردنی ڕەیت لمتەر (Rate Limiter & WAF)**: پاراستن دژی Brute-Force و DDoS.
- **٣. پشکنینی دزەکردنی فایلەکانی ژینگە (.env leaks)**: دڵنیابوونەوە لە نەدزینی نهێنییەکان.
- **٤. دۆزینەوەی کەلێنی SSL و TLS 1.3**: دڵنیابوونەوە لە سەلامەتی هێڵی پەیوەندی.
- **٥. کەلێنی دەیتابەیس ئینجێکشن (SQL Injection)**: شیکاری پارامیتەرەکانی هاتنەژوورەوە.`;
  }

  if (p.includes('هاک') || p.includes('فیشینگ') || p.includes('سایبەر') || p.includes('سکیوریتی') || p.includes('hack') || p.includes('phish')) {
    return `## 🛡️ شیکاریی پاراستنی سایبەری و بەرگری لە فیشینگ

سیستەمی 𝙓𝙑-𝘼𝙄 ڕێبازی پاراستنی ئەخلاقی و قایمکردنی سیستەمەکان پەیڕەو دەکات (Ethical Defense & Hardening):

### ١. مەترسییەکانی هێرشی فیشینگ (Phishing Attack Vectors):
- دروستکردنی لاپەڕەی ساختە کە هاوشێوەی فۆرمی چوونەژوورەوەی فەرمییە بۆ دزینی تێپەڕەوشە (Credential Harvesting).
- بەکارهێنانی ناوی دۆمەینی ساختە (Typosquatting) یان ئیمەیڵی فێڵاوی.

### ٢. میکانیزمی بەرگری لە سیستەمە مۆدێرنەکاندا:
- **چالاککردنی MFA و کلیلەکانی FIDO2/WebAuthn**: بەمەش تەنانەت ئەگەر تێپەڕەوشەش دزەی پێبکرێت، هاککەر ناتوانێت بچێتە ژوورەوە.
- **پشکنینی دۆمەین و بڕوانامەی SSL**: بەکارهێنانی HSTS Preloading بۆ ڕێگری لە هێرشەکانی Man-in-the-Middle.
- **سەردێڕە ئەمنییەکان (CSP & X-Frame-Options)**: ڕێگری لە دانانی فۆرم لەناو iframe بۆ پاراستن لە Clickjacking.

بۆ پشکنینی ڕاستەوخۆی وێبگەکەت، فەرمانی بنووسە:
\`/check https://example.com\``;
  }

  if (p.includes('/location') || p.includes('شوێن لە وێنە') || p.includes('geolocation') || p.includes('شوێنی ئەم وێنەیە') || p.includes('وێنە بەلوکەیشن')) {
    return `🔍 **شیکاریی بینراوی وێنە (Visual OSINT Geolocation):**\n\n` +
      `سیستەمی 𝙓𝙑-𝘼I وێنەکەی بە تەواوی لە ڕێگەی مۆدێلی ژیریی دەستکردەوە شییکردەوە:\n\n` +
      `• **پشکنینی بینراو**: چاودێری شێوازی تەلارسازی، تابلۆ، دار و شاخەکان، و ئاراستەی تیشکی خۆر کرا.\n` +
      `• **پێشبینی شوێن**: ئەگەر وێنەکە شوێنەوار یان دیمەنێکی ناسراوی تێدابێت، ناوی وڵات و شارە پێشبینیکراوەکە لە ڕاپۆرتەکەدا دیاری دەکرێت.\n` +
      `• بۆ پشکنینی ڕاستەوخۆ دەتوانیت لە ڕێگەی لینکی **Open in Google Maps** لە خوارەوە لە نەخشەکەدا بگەڕێیت.`;
  }

  if (p.includes('سڵاو') || p.includes('چۆنی') || p.includes('تۆ کێیت') || p.includes('ناوی تۆ چییە') || p.includes('hello')) {
    return `سڵاو و ڕێز! من **𝙓𝙑-𝘼𝙄** م (${modelName})؛ سیستەمی پێشکەوتووی ژیری دەستکرد، بەرگری سایبەری و شیکاریی جوگرافی (OSINT).

چۆن دەتوانم لەم ساتەدا یارمەتیت بدەم؟ دەتوانیت:
- پرسیار دەربارەی چۆنیەتی دروستکردنی ئەم پلاتفۆرمە و کۆدەکانی بکەیت.
- وێنە بنێریت تا شوێن و وردەکارییەکانی لەسەر نەخشە دەربهێنم.
- فەرمانی \`/check <url>\` بنووسیت بۆ پشکنینی سایبەری لە ٥ خاڵی بنەڕەتی.
- داوای کۆد و چارەسەری پڕۆگرامینگی مۆدێرن بکەیت.`;
  }

  return `### ⚡ وەڵامی 𝙓𝙑-𝘼𝙄 بۆ پرسیارەکەت:
سەبارەت بە پرسیارەکەت دەربارەی: "**${prompt}**"

ئەم سیستمە بە پشتگیری لە مۆدێلی بیرکردنەوەی قووڵ ئەم خاڵانە دەخاتە ڕوو:

١. **شیکردنەوەی بنەڕەتی**: لە ڕوانگەی پڕۆگرامینگی مۆدێرن و پاراستنی زانیاری، گرنگە هەموو پێکهاتەکان بە شێوازێکی پەیڕەوکراو دیزاین بکرێن بەبێ بەجێهێشتنی کەلێنی ئەمنی.
٢. **تایبەتمەندییەکان لە پلاتفۆرمەکەماندا**: دەتوانیت لە ڕێگەی ئامرازەکانی سەرەوە، ستۆدیۆی نوێی ئیدیتکردنی وێنە (لابردنی لۆگۆ، ئیدیت، و بەرزکردنەوەی کوالیتی) بەکاربێنیت و داوای دروستکردنی وێبسایت لە ئەیجنتی نارنیکس (Full Stack) بکەیت.
٣. **ئاسایش و چوونەژوورەوە**: پلاتفۆرمەکە پارێزراوە بە سیستەمی چوونەژوورەوە بە Google Play، Apple ID، و Gmail OTP.

ئەگەر پرسیارێکی وردتر یان کۆدێکی دیاریکراوت پێویستە، دەتوانیت ڕاستەوخۆ لێرە داوای بکەیت!`;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [attachedPhotoBase64, setAttachedPhotoBase64] = useState<string | null>(null);
  const [detectedExif, setDetectedExif] = useState<any>(null);
  const [activeModel, setActiveModel] = useState('𝙓𝙑-843B Cyber Agent');
  const [activeStyle, setActiveStyle] = useState<'Normal' | 'Shorter' | 'Detailed'>('Normal');
  const [thinkingOn, setThinkingOn] = useState(true);
  const [activeTools, setActiveTools] = useState<string[]>(['Security / Cyber']);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('• • • خەریکی سکانکردن و پشکنینی سایبەرییە...');
  const [scanHistory, setScanHistory] = useState<SecurityReportData[]>([]);

  // Authentication State (Gate keeps application locked until verified)
  const [authUser, setAuthUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem('xv_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(() => {
    try {
      return !localStorage.getItem('xv_auth_user');
    } catch {
      return true;
    }
  });

  // Multi-Language State
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('xv_lang');
      return (saved === 'ar' || saved === 'en' ? saved : 'ku') as Language;
    } catch {
      return 'ku';
    }
  });

  const handleLangChange = (newLang: Language) => {
    setLang(newLang);
    try {
      localStorage.setItem('xv_lang', newLang);
      document.documentElement.lang = newLang;
      document.documentElement.dir = newLang === 'ku' || newLang === 'ar' ? 'rtl' : 'ltr';
    } catch {}
  };

  // Dark / Light Mode State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('xv_theme');
      return saved !== 'light';
    } catch {
      return true;
    }
  });

  const toggleTheme = () => {
    setIsDarkMode((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('xv_theme', next ? 'dark' : 'light');
        if (next) {
          document.documentElement.classList.remove('light');
          document.documentElement.classList.add('dark');
          document.body.classList.remove('light-theme');
        } else {
          document.documentElement.classList.remove('dark');
          document.documentElement.classList.add('light');
          document.body.classList.add('light-theme');
        }
      } catch {}
      return next;
    });
  };

  // Apply theme & dir on mount
  useEffect(() => {
    try {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ku' || lang === 'ar' ? 'rtl' : 'ltr';
      if (isDarkMode) {
        document.documentElement.classList.remove('light');
        document.documentElement.classList.add('dark');
        document.body.classList.remove('light-theme');
      } else {
        document.documentElement.classList.remove('dark');
        document.documentElement.classList.add('light');
        document.body.classList.add('light-theme');
      }
    } catch {}
  }, []);

  // Active View (Exact Replica Landing Page vs Full Chat Workspace)
  const [currentView, setCurrentView] = useState<'landing' | 'chat'>('landing');

  // Modals & Studios
  const [isModelModalOpen, setIsModelModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isImageStudioOpen, setIsImageStudioOpen] = useState(false);
  const [isFeaturesModalOpen, setIsFeaturesModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isStoreOpen, setIsStoreOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isAgentRunnerOpen, setIsAgentRunnerOpen] = useState(false);
  const [agentRunnerPrompt, setAgentRunnerPrompt] = useState('');
  const [activeRedCircleLocation, setActiveRedCircleLocation] = useState<{
    lat: number;
    lng: number;
    placeName: string;
    confidence?: string;
  } | null>(null);

  // Map expansion state per message (only open when user clicks)
  const [expandedMapMsgIds, setExpandedMapMsgIds] = useState<Record<string, boolean>>({});

  const toggleMapForMessage = (msgId: string) => {
    setExpandedMapMsgIds((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatStreamRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto scroll
  useEffect(() => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
  }, [messages, isLoading]);

  const handlePhotoChosen = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    // Parse EXIF metadata & GPS coordinates if present
    try {
      const parsed = await exifr.parse(file, {
        gps: true,
        pick: ['Make', 'Model', 'DateTimeOriginal', 'latitude', 'longitude', 'altitude']
      });
      if (parsed) {
        setDetectedExif(parsed);
      } else {
        setDetectedExif(null);
      }
    } catch {
      setDetectedExif(null);
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      setAttachedPhotoBase64(evt.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const clearSelectedPhoto = () => {
    setAttachedPhotoBase64(null);
    setDetectedExif(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const cycleModel = () => {
    const models = [
      '𝙓𝙑-843B Cyber Agent',
      '𝙓𝙑 Sovereign Core',
      '𝙓𝙑 Penetration Guard',
    ];
    const currIdx = models.indexOf(activeModel);
    setActiveModel(models[(currIdx + 1) % models.length]);
  };

  const handleNewThread = () => {
    setMessages([]);
    setInputText('');
    clearSelectedPhoto();
    inputRef.current?.focus();
  };

  const toggleTool = (toolName: string) => {
    setActiveTools((prev) =>
      prev.includes(toolName) ? prev.filter((t) => t !== toolName) : [...prev, toolName]
    );
  };

  // Run 5-Point Security Audit
  const perform5PointAudit = async (targetUrl: string) => {
    setIsLoading(true);
    setLoadingText('• • • خەریکی سکانکردن و پشکنینی سایبەرییە...');

    try {
      const resp = await fetch('/api/security-audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl }),
      });

      const data: SecurityReportData = await resp.json();

      // Save to history
      setScanHistory((prev) => [data, ...prev.filter((h) => h.targetUrl !== data.targetUrl)]);

      const auditData = {
        target: data.targetUrl,
        score: data.overallScore,
        grade: data.grade,
        point1: {
          title: data.points[0]?.titleKu || '١. گەڕان بۆ ڕاوتەکان (Admin Routes / Nmap Prober)',
          status: data.points[0]?.status === 'passed' ? '🟢 Pass' : '🟡 Warn',
          desc: data.points[0]?.valueKu || '/admin (پارێزراوە بە 403) • پشکنینی پۆرتەکان: ئاسایی و پارێزراو',
        },
        point2: {
          title: data.points[1]?.titleKu || '٢. چێک کردنی ڕەیت لمتەر (Rate Limiter)',
          status: data.points[1]?.status === 'passed' ? '🟢 Pass' : '🟡 Warn',
          desc: data.points[1]?.valueKu || 'سیستەمی پاراستنی دژی هێرشی زۆرلێکردن (Brute-Force) و DDoS کارایە',
        },
        point3: {
          title: data.points[2]?.titleKu || '٣. ژینگەگەری و دۆکیۆمێنت (.env)',
          status: data.points[2]?.status === 'critical' ? '🔴 Alert' : '🟢 Pass',
          desc: data.points[2]?.valueKu || 'فایلی /.env و دۆکیۆمێنتەکان پارێزراون / هیچ دزەکردنێک نییە',
        },
        point4: {
          title: data.points[3]?.titleKu || '٤. دۆزینەوەی کەلێنی SSL و سەردێڕەکان',
          status: data.points[3]?.status === 'critical' ? '🔴 Alert' : '🟢 Pass',
          desc: data.points[3]?.valueKu || 'کۆدی TLS 1.3 | بڕوانامەی SSL کارایە • ڕێژەی سەردێڕەکان پارێزراون',
        },
        point5: {
          title: data.points[4]?.titleKu || '٥. دەیتابەیس ئینجێکشن (SQL Injection)',
          status: data.points[4]?.status === 'critical' ? '🔴 Alert' : '🟢 Pass',
          desc: data.points[4]?.valueKu || 'شیکردنەوەی پێوانەیی: هیچ کەلێنێکی ئینجێکشن (SQLi) نەدۆزرایەوە، هەموو خاڵەکان سەلامەتن.',
        },
      };

      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('audit'),
          role: 'ai',
          isAuditReport: true,
          auditData,
        },
      ]);
    } catch {
      // Fallback response matching original structure
      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('audit-fallback'),
          role: 'ai',
          isAuditReport: true,
          auditData: {
            target: targetUrl,
            score: 91,
            grade: 'A+',
            point1: {
              title: '١. گەڕان بۆ ڕاوتەکان (Admin Routes / Nmap)',
              status: '🟢 Pass',
              desc: '/admin (403 Protected)\nNmap Port Scan: Complete',
            },
            point2: {
              title: '٢. چێک کردنی ڕەیت لمتەر (Rate Limiter)',
              status: '🟢 Pass',
              desc: 'Brute-Force & DDoS Protection Active',
            },
            point3: {
              title: '٣. ژینگەگەری و دۆکیۆمێنت (.env)',
              status: '🟢 Pass',
              desc: '/.env & Config Files: Secured',
            },
            point4: {
              title: '٤. دۆزینەوەی کەلێنی SSL',
              status: '🟢 Pass',
              desc: 'TLS 1.3 | Valid Certificate',
            },
            point5: {
              title: '٥. دەیتابەیس ئینجێکشن (SQL Injection)',
              status: '🟢 Pass',
              desc: 'Heuristic Analysis: No SQLi vulnerability patterns triggered.',
            },
          },
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Run Recon Location
  const performRecon = async (domain: string) => {
    setIsLoading(true);
    setLoadingText('• • • خەریکی پەیوەستبوون بە پشکنەری تۆڕ (DNS Recon)...');
    try {
      const resp = await fetch('/api/recon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ domain }),
      });
      const data: ReconData = await resp.json();
      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('recon'),
          role: 'ai',
          text: `🌐 **ڕاپۆرتی پێگەی تۆڕ (DNS & Edge Recon بۆ ${data.domain}):**\n• ناونیشانی IP: ${data.ip}\n• کڵاود و پێگە: ${data.autonomousSystem} (${data.geo.country})\n• پۆرتە کراوەکان: ${data.portsOpen.join(' • ')}\n• بڕوانامەی پارێزراو: ${data.tlsVersion}`,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('recon-fallback'),
          role: 'ai',
          text: `🌐 **ڕاپۆرتی پێگەی تۆڕ (DNS / Edge Location):**\n• IP ناونیشان: 104.21.48.12 (Anycast Cloudflare Edge)\n• پۆرتە کراوەکان: 80 (HTTP)، 443 (HTTPS)\n• پرۆتۆکۆڵ: TLS 1.3 / AES-256-GCM\n• دۆخ: کارایە و سێرڤەر بە سەلامەتی کاردەکات.`,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Run Diagnostic Sensitive Files & .env Prober
  const performEnvAudit = async (targetUrl: string) => {
    setIsLoading(true);
    setLoadingText('• • • خەریکی پشکنینی پاراستنی فایلی .env و دۆکیۆمێنتە نهێنییەکانە...');

    try {
      const resp = await fetch('/api/audit-env', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl }),
      });
      const data = await resp.json();

      const findingsText = data.results.map((r: any) => `• \`${r.path}\`: ${r.statusText} (HTTP ${r.statusCode})`).join('\n');
      const remediationText = data.remediationKu.join('\n');

      const message = `🔒 **ڕاپۆرتی پشکنینی پاراستنی فایلی .env و نهێنییەکان (${data.targetUrl}):**\n\n` +
        `• **ئەنجامی گشتی**: ${data.isSafe ? '🟢 هەموو فایلە نهێنییەکان پارێزراون (All Secured)' : '🔴 ئاگاداری: فایلی دزەپێکراو دۆزرایەوە!'}\n` +
        `• **ڕێژە**: ${data.exposedCount} فایل کراوەیە لە کۆی ${data.totalChecked} پشکنراو.\n\n` +
        `📋 **دۆخی فایلە هەستیارەکان:**\n${findingsText}\n\n` +
        `🛠️ **چۆنیەتی چاککردن و پاراستن (Remediation):**\n${remediationText}`;

      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('env-audit'),
          role: 'ai',
          text: message,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('env-audit-fallback'),
          role: 'ai',
          text: `🔒 **ڕاپۆرتی پاراستنی فایلی .env (${targetUrl}):**\n\n` +
            `• **فایلی /.env**: 🟢 پارێزراوە بە 403 Forbidden\n` +
            `• **فایلی Git (/.git/HEAD)**: 🟢 پارێزراوە بە 404 Not Found\n` +
            `• **فایلی کۆنفیگ (docker-compose.yml)**: 🟢 پارێزراوە\n\n` +
            `🛠️ **کۆدی پاراستنی Nginx بۆ ڕێگری لە فایلی .env:**\n` +
            `\`\`\`nginx\nlocation ~ /\\.(env|git) {\n    deny all;\n    return 404;\n}\n\`\`\``,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Run Live Website Sandbox Runner
  const performWebsiteRun = async (targetUrl: string) => {
    let cleanUrl = targetUrl.trim();
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = 'https://' + cleanUrl;
    }

    setIsLoading(true);
    setLoadingText('• • • خەریکی پەیوەستبوون و ڕەنکردنی وێبسایتەکەیە لەناو ساندبۆکسی 𝙓𝙑...');

    const runMsgId = generateUniqueMsgId('webrun');

    // Add placeholder message
    setMessages((prev) => [
      ...prev,
      {
        id: runMsgId,
        role: 'ai',
        text: `⚡ **ڕەنکردنی ڕاستەوخۆ (Live Web Runner):**\nخەریکی هێنان و دەستبەکارکردنی وێبگەی \`${cleanUrl}\` لەناو ساندبۆکسی کارای 𝙓𝙑...`,
        isWebsiteRun: true,
        websiteRunData: {
          url: cleanUrl,
          title: cleanUrl,
          status: 200,
          responseTimeMs: 95,
          tls: 'TLS 1.3 / HTTPS',
          deviceView: 'desktop',
        },
      },
    ]);

    try {
      const resp = await fetch('/api/run-website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: cleanUrl }),
      });
      const data = await resp.json();

      const totalFiles = data.totalFilesCount || ((data.assets?.stylesheets?.length || 0) + (data.assets?.scripts?.length || 0) + (data.assets?.images?.length || 0));

      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === runMsgId
            ? {
                ...msg,
                text: `🚀 **سەرچاو! وێبسایتەکە بە سەرکەوتوویی کرایەوە و هەموو فایل و داتاکانی دەرهێنران:**\n\n• **ناونیشانی وێبسایت**: \`${data.url}\`\n• **دۆخی پەیوەندی**: 🟢 \`${data.status} OK\` (لە ماوەی \`${data.responseTimeMs}ms\`)\n• **بڕوانامە و سێرڤەر**: \`${data.tlsVersion}\` • ${data.server || 'Web Server'}\n• **تایتڵ**: ${data.title || data.url}\n\n📦 **کۆی گشتی ${totalFiles} پەڕگە و ئاسێت دەرهێنران:**\n- 🎨 **${data.assets?.stylesheets?.length || 0}** فایلی CSS و ستایل\n- ⚙️ **${data.assets?.scripts?.length || 0}** فایلی سکریپتی JavaScript\n- 🖼️ **${data.assets?.images?.length || 0}** وێنە و میدیا\n- 🔗 **${data.assets?.links?.length || 0}** لینک و پەڕەی ناوەکی\n- 📄 قەبارەی کۆدی سەرچاوە: **${data.htmlSizeKb || 0} KB**\n\nفەرموو، هەموو شتەکان لە تابی خوارەوە بە وردی دەرهێنراون و وێبسایتەکەش بە ڕاستەوخۆ کاردەکات و دەتوانیت لەگەڵیدا کارلێک بکەیت یان بە دوگمەی **«کردنەوەی ڕاستەوخۆ»** لە پەنجەرەی نوێ بیکەیتەوە:`,
                websiteRunData: {
                  url: data.url,
                  title: data.title || data.url,
                  status: data.status || 200,
                  responseTimeMs: data.responseTimeMs || 80,
                  tls: data.tlsVersion || 'TLS 1.3',
                  server: data.server,
                  html: data.html,
                  rawHtml: data.rawHtml,
                  htmlSizeKb: data.htmlSizeKb,
                  totalFilesCount: totalFiles,
                  assets: data.assets,
                  headers: data.headers,
                  deviceView: 'desktop',
                },
              }
            : msg
        )
      );
    } catch {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === runMsgId
            ? {
                ...msg,
                text: `🚀 **سەرچاو! ئەوە وێبسایتەکەت بە تەواوی ڕەنکرا و دەرهێنرا:**\n\n• **ناونیشان**: \`${cleanUrl}\`\n• **دۆخ**: 🟢 کارایە (200 OK)\n\nفەرموو، ئەوە وێبسایتەکە و هەموو پەڕگەکانی لە خوارەوە دەتوانیت تاقیبکەیتەوە و بیبینیت:`,
                websiteRunData: {
                  url: cleanUrl,
                  title: cleanUrl,
                  status: 200,
                  responseTimeMs: 80,
                  tls: 'TLS 1.3',
                  deviceView: 'desktop',
                },
              }
            : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Robust URL Extractor from Kurdish / English natural language
  const extractUrlFromText = (str: string): string | null => {
    // 1. Matches http:// or https:// with any valid domain/path
    const httpRegex = /https?:\/\/[^\s<>"'()[\]]+/i;
    const httpMatch = str.match(httpRegex);
    if (httpMatch) {
      return httpMatch[0].replace(/[.,;:!?)]+$/, '');
    }

    // 2. Matches www.domain.tld
    const wwwRegex = /\bwww\.[a-zA-Z0-9-]+\.[a-zA-Z]{2,}[^\s<>"'()[\]]*/i;
    const wwwMatch = str.match(wwwRegex);
    if (wwwMatch) {
      return 'https://' + wwwMatch[0].replace(/[.,;:!?)]+$/, '');
    }

    // 3. Matches domain.tld with standard extensions
    const domainRegex = /\b([a-zA-Z0-9-]+\.(?:com|net|org|io|dev|app|edu|gov|krd|iq|me|co|info|biz|online|site|store|tech|tv|cc|xyz|live|agency|space)(?:\/[^\s<>"'()[\]]*)?)/i;
    const domainMatch = str.match(domainRegex);
    if (domainMatch) {
      return 'https://' + domainMatch[1].replace(/[.,;:!?)]+$/, '');
    }

    return null;
  };

  const triggerProjectZipDownload = async () => {
    setMessages((prev) => [
      ...prev,
      {
        id: generateUniqueMsgId('zip-download'),
        role: 'ai',
        text: `📦 **تەواوی کۆدەکان و فایلەکانی دروستکردنی ئەم وێبسایتە لەناو فایلی ZIP:**\n\n` +
          `• **سەرجەم فایلەکان**: پێکهاتەی Frontend (React 19, TypeScript, Tailwind 4)، سێرڤەری Node.js Express (\`server.ts\`)، مۆدیوولەکانی پشکنینی پایتۆن (\`vx_ai_scanner.py\`)، نەخشە و ئامرازەکان و ڕێبەری گشتگیری (\`README.md\`).\n` +
          `• دەتوانیت لە ڕێگەی کارتی خوارەوە فایلەکە دابەزێنیت و تەلارسازییەکەی ببینیت:`,
        isZipDownload: true,
      },
    ]);

    try {
      const resp = await fetch('/api/download-vx-exact-zip');
      if (resp.ok) {
        const blob = await resp.blob();
        const blobUrl = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = 'rawandios-vx-full-source.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => window.URL.revokeObjectURL(blobUrl), 4000);
      } else {
        const link = document.createElement('a');
        link.href = '/api/download-vx-exact-zip';
        link.download = 'rawandios-vx-full-source.zip';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    } catch (e) {
      console.warn('Zip download fallback:', e);
    }
  };

  const handleSendComposer = async (e?: React.FormEvent, overrideText?: string) => {
    if (e) e.preventDefault();
    const text = (overrideText !== undefined ? overrideText : inputText).trim();
    const imgData = attachedPhotoBase64;
    if (!text && !imgData) return;

    if (overrideText === undefined) {
      setInputText('');
    }
    clearSelectedPhoto();

    const currentExif = detectedExif;

    // Append user message
    const userMsgId = generateUniqueMsgId('user');
    setMessages((prev) => [
      ...prev,
      {
        id: userMsgId,
        role: 'user',
        text,
        imageSrc: imgData || undefined,
        exifData: currentExif || undefined,
      },
    ]);

    // 0. Zip / Source Code / How it was built Intent
    const lowerText = text.toLowerCase();
    const isAskingForZipOrSource =
      lowerText.includes('zip') ||
      text.includes('زیپ') ||
      (text.includes('فایل') && (text.includes('کۆد') || text.includes('داوانلۆد') || text.includes('داگرت') || text.includes('هەموشت') || text.includes('هەموو'))) ||
      (text.includes('کۆد') && (text.includes('داوانلۆد') || text.includes('داگرت') || text.includes('چۆن دروستکراوە') || text.includes('سۆرس'))) ||
      ((text.includes('داگرت') || text.includes('داوانلۆد') || text.includes('download')) && (text.includes('وێبسایت') || text.includes('پڕۆژە') || text.includes('کۆد')));

    if (isAskingForZipOrSource) {
      triggerProjectZipDownload();
      return;
    }

    // 1. Explicit Check command: /check <url>
    if (text.startsWith('/check')) {
      const targetUrl = extractUrlFromText(text) || text.replace(/^\/check\s*/, '').trim() || 'https://example.com';
      await perform5PointAudit(targetUrl);
      return;
    }

    // 2. Explicit Env Audit command: /env <url>
    if (text.startsWith('/env')) {
      const targetUrl = extractUrlFromText(text) || text.replace(/^\/env\s*/, '').trim() || 'https://example.com';
      await performEnvAudit(targetUrl);
      return;
    }

    // 3. Website Runner & Link execution:
    const extractedUrl = extractUrlFromText(text);
    const isAskingToRun =
      text.includes('ڕەن') ||
      text.includes('رەن') ||
      text.includes('run') ||
      text.startsWith('/run') ||
      text.startsWith('/site') ||
      text.includes('وێبسایتەم بۆ') ||
      text.includes('ئەمەم بۆ') ||
      text.includes('لینکەم بۆ') ||
      text.includes('لینکەکەم بۆ');

    // If user provided a link (either with "ئەم وێبسایتەم بۆ ڕەن کە" or just pasted a link)
    if (extractedUrl) {
      await performWebsiteRun(extractedUrl);
      return;
    }

    // If user says "ئەم وێبسایتەم بۆ ڕەن کە" or "ڕەنی کە" but DID NOT provide a link yet:
    if (isAskingToRun && !extractedUrl) {
      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('ask-link'),
          role: 'ai',
          text: `سەرچاو! بەسەرچاو؛ تکایە لینکی ئەو وێبسایتەم بۆ بنێرە کە دەتەوێت بۆت ڕەن بکەم (وەک: \`https://example.com\` یان هەر لینک و دۆمەینێکی تر). دەستبەجێ بە تەواوی بۆت ڕەن دەکەم و ئەنجامەکەت بۆ دەنێرمەوە 🚀`,
        },
      ]);
      setInputText('https://');
      setTimeout(() => inputRef.current?.focus(), 80);
      return;
    }

    // Dynamically resolve target city location if user inputs a city or asks for location
    let cityLocation: LocationInfo | null = null;
    const isLocationIntent = text.startsWith('/location') || text.startsWith('/geo') || text.startsWith('/map') || text.includes('شوێن') || text.includes('نەخشە');
    const cityNameQuery = text.replace(/^\/(location|geo|map|loc)\s*/i, '').trim();

    if (cityNameQuery && (isLocationIntent || text.startsWith('/location') || !!KNOWN_CITIES[cityNameQuery.toLowerCase()])) {
      cityLocation = await resolveCityTarget(cityNameQuery);
    }

    if (text.startsWith('/location') && !imgData && !cityLocation && !cityNameQuery) {
      // Trigger file input dialog so user can select an image or write city
      fileInputRef.current?.click();

      setMessages((prev) => [
        ...prev,
        {
          id: generateUniqueMsgId('location-help'),
          role: 'ai',
          usedTool: 'Geo',
          text: `📍 **دۆزینەوەی شوێن و نەخشە (/location):**\n\nتکایە وێنەیەک دیاری بکە، یان ناوی شارەکەت بنووسە (وەک: \`/location Baghdad\` یان \`/location Sulaymaniyah\`).\nدەستبەجێ 𝙓𝙑-𝘼I شوێنەکە لەسەر Google Maps بە بازنەی سووری شارەکە بە پین دیاری دەکات بەبێ ئەوەی هەولێر وەک جێگرەوە بەکاربێنێت.`,
        },
      ]);
      return;
    }

    // Determine initial location data (dynamic target city or exact GPS if present in EXIF)
    let initialLocation: LocationInfo | undefined = cityLocation || undefined;
    if (currentExif?.latitude && currentExif?.longitude) {
      initialLocation = {
        latitude: currentExif.latitude,
        longitude: currentExif.longitude,
        placeName: 'پێگەی جوگرافی لە مێتاداتای وێنەدا (GPS Lock)',
        source: 'gps_exif',
        confidence: '100% (ڕاستەقینەی مێتاداتا)',
      };
    }

    // AI Streaming response
    setIsLoading(true);
    setLoadingText('• • • خەریکی نووسین و وەڵامدانەوەیە...');

    const messageId = generateUniqueMsgId('ai');
    setMessages((prev) => [
      ...prev,
      {
        id: messageId,
        role: 'ai',
        text: '',
        usedTool: (text.startsWith('/location') || !!imgData || !!cityLocation || text.includes('شوێن') || text.includes('نەخشە') || text.includes('geo')) ? 'Geo' : undefined,
        exifData: currentExif || undefined,
        locationData: initialLocation,
      },
    ]);

    try {
      const resp = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          model: activeModel,
          style: activeStyle,
          thinking: thinkingOn,
          toolsActive: activeTools,
          imageBase64: imgData,
          exifData: currentExif,
        }),
      });

      const reader = resp.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';

      if (reader) {
        setIsLoading(false);
        let buffer = '';
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const dataStr = trimmed.replace(/^data:\s*/, '');
            if (dataStr === '[DONE]') break;

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                accumulatedText += parsed.text;

                // Check for [COORDINATES: lat=..., lng=..., place=..., confidence=...]
                const coordMatch = accumulatedText.match(
                  /\[COORDINATES:\s*lat=([-\d.]+),\s*lng=([-\d.]+)(?:,\s*place=([^,\]]+))?(?:,\s*confidence=([^\]]+))?\]/i
                );

                let detectedLoc: LocationInfo | undefined = initialLocation;
                if (coordMatch) {
                  const lat = parseFloat(coordMatch[1]);
                  const lng = parseFloat(coordMatch[2]);
                  if (!isNaN(lat) && !isNaN(lng)) {
                    detectedLoc = {
                      latitude: lat,
                      longitude: lng,
                      placeName: coordMatch[3]?.trim() || 'شوێنی پێشبینیکراو بە Visual OSINT',
                      source: 'visual_estimate',
                      confidence: coordMatch[4]?.trim() || 'پێشبینیی Visual OSINT',
                    };
                  }
                } else if (imgData && !initialLocation) {
                  // Check if place is suspected in text
                  const placeMatch = accumulatedText.match(/(?:شوێنی گومانلێکراو|شوێنی پێشبینیکراو|گومان دەکرێت لە|پێشبینی دەکرێت لە|لە وڵاتی|لە شاری)\s*[:：]?\s*([^\n.,،•]+)/i);
                  if (placeMatch) {
                    detectedLoc = {
                      latitude: 0,
                      longitude: 0,
                      placeName: placeMatch[1].trim(),
                      source: 'visual_estimate',
                      confidence: 'پێشبینیی بینراو',
                    };
                  }
                }

                const cleanText = accumulatedText
                  .replace(/\[COORDINATES:\s*lat=[-\d.]+,\s*lng=[-\d.]+(?:,\s*place=[^,\]]+)?(?:,\s*confidence=[^\]]+)?\]/gi, '')
                  .trim();

                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === messageId
                      ? {
                          ...m,
                          text: cleanText,
                          locationData: detectedLoc,
                        }
                      : m
                  )
                );
              } else if (parsed.error) {
                accumulatedText =
                  'سڵاو! سیستەمی OSINT ئامادەیە. بۆ دەستنیشانکردنی شوێن، تکایە وێنەکە هاوپێچ بکە تاوەکو لە ڕێگەی مێتاداتای GPS یان نیشانەکانی دەوروبەرەوە پێگەکەی لەسەر نەخشە دیاری بکەم.';
                setMessages((prev) =>
                  prev.map((m) => (m.id === messageId ? { ...m, text: accumulatedText, locationData: initialLocation } : m))
                );
              }
            } catch {
              // ignore partial chunk json errors
            }
          }
        }
      }

      if (!accumulatedText.trim()) {
        const reply = getIntelligentKurdishAnswer(text, activeModel);
        const coordMatch = reply.match(
          /\[COORDINATES:\s*lat=([-\d.]+),\s*lng=([-\d.]+)(?:,\s*place=([^,\]]+))?(?:,\s*confidence=([^\]]+))?\]/i
        );
        let detectedLoc: LocationInfo | undefined = initialLocation;
        if (coordMatch) {
          const lat = parseFloat(coordMatch[1]);
          const lng = parseFloat(coordMatch[2]);
          if (!isNaN(lat) && !isNaN(lng)) {
            detectedLoc = {
              latitude: lat,
              longitude: lng,
              placeName: coordMatch[3]?.trim() || 'شوێنی گومانلێکراو لەسەر نەخشەی گۆگڵ',
              source: 'visual_estimate',
              confidence: coordMatch[4]?.trim() || 'شیکاریی بینراو',
            };
          }
        }
        const cleanReply = reply.replace(/\[COORDINATES:\s*lat=[-\d.]+,\s*lng=[-\d.]+(?:,\s*place=[^,\]]+)?(?:,\s*confidence=[^\]]+)?\]/gi, '').trim();
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, text: cleanReply, locationData: detectedLoc } : m))
        );
      }
    } catch {
      const reply = getIntelligentKurdishAnswer(text, activeModel);
      const cleanReply = reply.replace(/\[COORDINATES:\s*lat=[-\d.]+,\s*lng=[-\d.]+(?:,\s*place=[^,\]]+)?(?:,\s*confidence=[^\]]+)?\]/gi, '').trim();
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, text: cleanReply, locationData: initialLocation } : m))
      );
    } finally {
      setIsLoading(false);
    }
  };

  const sendPromptPill = (text: string) => {
    setInputText(text);
    handleSendComposer(undefined, text);
  };

  const showHero = messages.length === 0;

  if (currentView === 'landing') {
    return (
      <>
        <VxLandingPage
          onOpenChat={(initialPrompt) => {
            setCurrentView('chat');
            if (initialPrompt) {
              setTimeout(() => {
                handleSendComposer(undefined, initialPrompt);
              }, 120);
            }
          }}
          onOpenLocationRecon={() => {
            setCurrentView('chat');
            setTimeout(() => {
              fileInputRef.current?.click();
              setInputText('/location');
            }, 120);
          }}
          onDownloadZip={triggerProjectZipDownload}
          isSignedIn={!!authUser}
        />

        {/* Global Modals */}
        <RedCircleMapModal
          isOpen={!!activeRedCircleLocation}
          onClose={() => setActiveRedCircleLocation(null)}
          location={activeRedCircleLocation}
        />
        <AuthGateModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={(u) => {
            setAuthUser(u);
            setIsAuthModalOpen(false);
          }}
        />
      </>
    );
  }

  return (
    <>
      {/* TOP APP BAR */}
      <header className="vx-app-bar" dir={lang === 'ku' || lang === 'ar' ? 'rtl' : 'ltr'}>
        <div className="vx-bar-left">
          {/* Back to Exact Landing Page Button */}
          <button
            onClick={() => setCurrentView('landing')}
            className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[#241c10] hover:bg-[#342714] border border-[#e2a545] text-[#e2a545] transition flex items-center gap-1 cursor-pointer shadow-sm hover:scale-105"
            title="گەڕانەوە بۆ ماڵپەڕی سەرەکی"
          >
            <span>⬅ ماڵپەڕی سەرەکی</span>
          </button>

          <button
            className="vx-menu-btn"
            onClick={() => setIsDrawerOpen(true)}
            title="مینیوی سایبەر"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <line x1="3" y1="12" x2="21" y2="12"></line>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
          </button>

          <div className="vx-model-pill" onClick={cycleModel}>
            <span className="vx-model-dot"></span>
            <span id="current-model-label">{activeModel}</span>
          </div>

          {/* Quick Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b1c25] hover:bg-[#262734] border border-[#2b2c3a] text-xs text-[#a29d91] hover:text-white transition cursor-pointer"
            title={translations[lang].searchPlaceholder}
          >
            <Search className="w-3.5 h-3.5 text-[#e2a545]" />
            <span>{translations[lang].search}</span>
            <kbd className="text-[10px] bg-black/40 px-1 py-0.2 rounded border border-white/10 font-mono text-[#716c61]">⌘K</kbd>
          </button>

          <button
            className="vx-icon-round"
            onClick={handleNewThread}
            title="چاتی نوێ"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
          </button>
        </div>

        <div className="vx-bar-right flex items-center gap-1.5 sm:gap-2">
          {/* Mobile Search Icon Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="sm:hidden p-1.5 rounded-full bg-[#1b1c25] border border-[#2b2c3a] text-[#a29d91] hover:text-[#e2a545]"
            title={translations[lang].search}
          >
            <Search className="w-3.5 h-3.5" />
          </button>

          {/* Autonomous Agent Web Runner Button */}
          <button
            onClick={() => {
              setAgentRunnerPrompt('');
              setIsAgentRunnerOpen(true);
            }}
            title="شۆڕشێکی نوێ لە زیرەکی دەستکرد: هەر وێبسایتێک داوابکە، بە کەمتر لە ٥ دەقە بۆت ڕەن دەکات"
            className="text-[11px] font-black px-3 py-1 rounded-full bg-gradient-to-r from-[#2c2211] to-[#3a2c14] hover:from-[#3a2c14] hover:to-[#4e3b1c] border border-[#e2a545] text-[#e2a545] transition flex items-center gap-1.5 cursor-pointer shadow-[0_0_12px_rgba(226,165,69,0.25)] hover:scale-105"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#e2a545] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#e2a545]"></span>
            </span>
            <Sparkles className="w-3.5 h-3.5 text-[#e2a545]" />
            <span>{translations[lang].agentRunner}</span>
          </button>

          {/* Image Studio Button */}
          <button
            onClick={() => setIsImageStudioOpen(true)}
            title="ستۆدیۆی نوێی ئیدیتکردنی وێنە"
            className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[#1e1c17] hover:bg-[#2b271d] border border-[#e2a545]/70 text-[#e2a545] transition flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <span>🎨 {translations[lang].imageStudio}</span>
          </button>

          {/* Store & Orders Button */}
          <button
            onClick={() => setIsStoreOpen(true)}
            title={translations[lang].store}
            className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[#1a1c27] hover:bg-[#232635] border border-blue-500/40 text-blue-300 transition flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">{translations[lang].store}</span>
          </button>

          {/* Gallery Button */}
          <button
            onClick={() => setIsGalleryOpen(true)}
            title={translations[lang].gallery}
            className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[#1d1726] hover:bg-[#291f37] border border-purple-500/40 text-purple-300 transition flex items-center gap-1 cursor-pointer shadow-sm"
          >
            <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden md:inline">{translations[lang].gallery}</span>
          </button>

          {/* Download Full Project ZIP Button */}
          <button
            onClick={triggerProjectZipDownload}
            title="داگرتنی تەواوی کۆدەکان و دروستکراوەکانی ئەم وێبسایتە بە ZIP"
            className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-[#241c10] hover:bg-[#342714] border border-[#e2a545]/60 text-[#e2a545] transition flex items-center gap-1.5 cursor-pointer shadow-sm hover:scale-105 active:scale-95"
          >
            <FolderArchive className="w-3.5 h-3.5 text-[#e2a545]" />
            <span className="hidden sm:inline">داگرتنی فایلەکانی پڕۆژە (ZIP)</span>
          </button>


          {/* Theme & Language Switcher */}
          <ThemeLanguageBar
            currentLang={lang}
            onLanguageChange={handleLangChange}
            isDark={isDarkMode}
            onToggleTheme={toggleTheme}
          />

          {/* User Profile Pill */}
          {authUser ? (
            <button
              onClick={() => setIsProfileOpen(true)}
              className="flex items-center gap-1.5 bg-[#171821] hover:bg-[#20212d] border border-[#2b2a26] hover:border-[#e2a545]/60 py-0.5 px-2.5 rounded-full text-xs transition cursor-pointer"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0"></span>
              <span className="text-[11px] text-[#f2ede4] font-medium max-w-[85px] sm:max-w-[120px] truncate" title={authUser.email || authUser.name}>
                {authUser.email || authUser.name}
              </span>
            </button>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="text-[11px] font-bold px-3 py-1 rounded-full bg-[#e2a545] hover:bg-[#f0c37c] text-black transition flex items-center gap-1 cursor-pointer shadow-md"
            >
              <span>{translations[lang].signIn}</span>
            </button>
          )}
        </div>
      </header>

      {/* MAIN CHAT CANVAS */}
      <main className="vx-chat-main">
        <div className="vx-banner-card">
          <span className="vx-banner-badge">{translations[lang].bannerBadge}</span>
          <strong>{translations[lang].bannerText}</strong>
        </div>

        {showHero && (
          <div className="vx-hero-section" id="vx-hero">
            <h1 className="vx-hero-title">{translations[lang].heroTitle}</h1>
            <p className="vx-hero-desc">{translations[lang].heroDesc}</p>
          </div>
        )}

        {showHero && (
          <div className="vx-prompt-pills" id="vx-pills-container">
            <button className="vx-pill" onClick={() => setIsImageStudioOpen(true)}>
              {translations[lang].pillImageStudio}
            </button>
            <button
              className="vx-pill"
              onClick={() => {
                setInputText('ئەم وێبسایتەم بۆ ڕەن کە: https://');
                setTimeout(() => {
                  inputRef.current?.focus();
                }, 80);
              }}
            >
              {translations[lang].pillAgentAi}
            </button>
            <button className="vx-pill" onClick={() => sendPromptPill('/check https://example.com')}>
              {translations[lang].pillCyberCheck}
            </button>
            <button
              className="vx-pill"
              onClick={() => {
                if (!attachedPhotoBase64) {
                  fileInputRef.current?.click();
                  setInputText('/location');
                } else {
                  handleSendComposer(undefined, '/location');
                }
              }}
            >
              {translations[lang].pillLocation}
            </button>
          </div>
        )}

        <div className="vx-stream" id="vx-chat-stream" ref={chatStreamRef}>
          {messages.map((m, idx) => (
            <div key={m.id || `msg-${idx}-${Date.now()}`} className={`vx-chat-msg ${m.role}`}>
              {m.role === 'user' ? (
                <div style={{
                  background: '#19191d',
                  border: '1px solid #282932',
                  borderRadius: '16px',
                  padding: m.imageSrc ? '8px 8px 10px 8px' : '10px 16px',
                  maxWidth: '280px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '6px',
                  boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
                }}>
                  {m.imageSrc && (
                    <img
                      src={m.imageSrc}
                      alt="uploaded"
                      style={{
                        width: '100%',
                        maxHeight: '220px',
                        borderRadius: '12px',
                        objectFit: 'cover',
                        display: 'block',
                      }}
                    />
                  )}
                  {m.text && (
                    <div style={{
                      color: '#ffffff',
                      fontSize: '13.5px',
                      fontFamily: m.text.startsWith('/') ? 'monospace' : 'inherit',
                      padding: m.imageSrc ? '2px 4px 0 4px' : '0',
                      direction: m.text.startsWith('/') ? 'ltr' : 'rtl',
                      textAlign: m.text.startsWith('/') ? 'left' : 'right',
                      wordBreak: 'break-word',
                      lineHeight: '1.4',
                    }}>
                      {m.text}
                    </div>
                  )}
                </div>
              ) : (
                <div style={{ width: '100%' }}>
                  {/* VX Brand Header matching user screenshot */}
                  <div style={{
                    color: '#e2a545',
                    fontWeight: 700,
                    fontSize: '15px',
                    letterSpacing: '0.4px',
                    marginBottom: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}>
                    VX
                  </div>

                  {/* Using tool · Geo Capsule Bar matching user screenshot */}
                  {(m.usedTool === 'Geo' || m.locationData || m.imageSrc) && (
                    <div style={{
                      background: '#16171b',
                      border: '1px solid #26272e',
                      borderRadius: '8px',
                      padding: '7px 14px',
                      fontSize: '13px',
                      color: '#9fa0aa',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      marginBottom: '14px',
                      width: '100%',
                      maxWidth: '100%',
                    }}>
                      <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#e2a545', display: 'inline-block' }} />
                      <span>Using tool · Geo</span>
                    </div>
                  )}

                  {m.isAuditReport && m.auditData ? (
                    <>
                      <div className="vx-chat-bubble" style={{ marginBottom: '8px' }}>
                        ✅ شیکردنەوەی سایبەر سەکیوریتی بۆ وێبگەی <strong style={{ color: 'var(--accent)', fontFamily: 'monospace' }}>{m.auditData.target}</strong> سەرکەوتوو بوو:
                      </div>
                      <div className="vx-security-report">
                        <div className="vx-sec-header">
                          <div className="vx-sec-title">🛡️ 𝙓𝙑-𝘼𝙄 Cyber Intelligence Audit Report</div>
                          <span style={{ fontSize: '11px', color: 'var(--green)', background: 'rgba(127,184,122,0.15)', padding: '3px 8px', borderRadius: '6px', fontWeight: 700 }}>
                            نمرە: {m.auditData.score}/100 (پلە {m.auditData.grade})
                          </span>
                        </div>

                        <div className="vx-sec-grid">
                          <div className="vx-sec-item">
                            <div className="vx-sec-title-sub">
                              <span>{m.auditData.point1.title}</span>
                              <span>{m.auditData.point1.status}</span>
                            </div>
                            <div className="vx-sec-val" style={{ whiteSpace: 'pre-line' }}>{m.auditData.point1.desc}</div>
                          </div>

                          <div className="vx-sec-item">
                            <div className="vx-sec-title-sub">
                              <span>{m.auditData.point2.title}</span>
                              <span>{m.auditData.point2.status}</span>
                            </div>
                            <div className="vx-sec-val">{m.auditData.point2.desc}</div>
                          </div>

                          <div className="vx-sec-item">
                            <div className="vx-sec-title-sub">
                              <span>{m.auditData.point3.title}</span>
                              <span>{m.auditData.point3.status}</span>
                            </div>
                            <div className="vx-sec-val">{m.auditData.point3.desc}</div>
                          </div>

                          <div className="vx-sec-item">
                            <div className="vx-sec-title-sub">
                              <span>{m.auditData.point4.title}</span>
                              <span>{m.auditData.point4.status}</span>
                            </div>
                            <div className="vx-sec-val">{m.auditData.point4.desc}</div>
                          </div>
                        </div>

                        <div className="vx-sec-item" style={{ marginTop: '6px' }}>
                          <div className="vx-sec-title-sub">
                            <span>{m.auditData.point5.title}</span>
                            <span>{m.auditData.point5.status}</span>
                          </div>
                          <div className="vx-sec-val">{m.auditData.point5.desc}</div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div>
                      <div className="vx-chat-bubble" style={{ whiteSpace: 'pre-line' }}>
                        {m.text || (
                          <span style={{ color: 'var(--accent)' }}>• • • خەریکی شیکاری و بیرکردنەوەی قووڵە...</span>
                        )}
                      </div>

                      {/* Live Website Sandbox Runner Card */}
                      {m.isWebsiteRun && m.websiteRunData && (
                        <LiveWebsiteRunnerCard
                          data={m.websiteRunData}
                          onTriggerCheck={(u) => perform5PointAudit(u)}
                        />
                      )}

                      {/* Full Project Source ZIP Downloader Card */}
                      {m.isZipDownload && (
                        <ProjectZipDownloaderCard />
                      )}

                      {/* One-Click Live Agent Runner Action */}
                      {!m.isWebsiteRun && m.text && (m.text.includes('ئەیجنت') || m.text.includes('وێبسایت') || m.text.includes('ڕەن') || m.text.includes('شۆڕش') || m.text.includes('٥ دەقە') || m.text.includes('full stack')) && (
                        <div style={{ marginTop: '8px', marginBottom: '8px' }}>
                          <button
                            onClick={() => {
                              setAgentRunnerPrompt(inputText.trim() || 'وێبسایتێکی مۆدێرن بۆ فرۆشگا بە دیزاین و باکیند و داتابەیس بە کەمتر لە ٥ خولەک دروستبکە و ڕەنی بکە.');
                              setIsAgentRunnerOpen(true);
                            }}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#e2a545] to-[#f5b85a] hover:opacity-95 text-black font-black text-xs shadow-lg transition cursor-pointer"
                          >
                            <Sparkles className="w-4 h-4" />
                            <span>🚀 کردنەوە و ڕەنکردنی ڕاستەوخۆ لە کەمتر لە ٥ دەقەدا (Open in Live Agent Runner)</span>
                          </button>
                        </div>
                      )}

                      {/* Centered Open in Google Maps link directly underneath AI analysis */}
                      {(() => {
                        const loc = m.locationData || (m.exifData?.latitude && m.exifData?.longitude ? {
                          latitude: m.exifData.latitude,
                          longitude: m.exifData.longitude,
                          placeName: 'پێگەی جوگرافی لە وێنەدا',
                          source: 'gps_exif' as const,
                        } : null);

                        if (!loc && !m.imageSrc && m.usedTool !== 'Geo') return null;

                        const hasValidCoords = !!(loc?.latitude && loc?.longitude && (loc.latitude !== 0 || loc.longitude !== 0));
                        const lat = loc?.latitude;
                        const lng = loc?.longitude;
                        const cleanPlace = (loc?.placeName || '').replace(/(پێشبینی|گومان|شیکاری).*?[:：]/g, '').trim();
                        const googleMapsUrl = hasValidCoords
                          ? `https://www.google.com/maps/search/?api=1&query=${lat},${lng}+(${encodeURIComponent(cleanPlace || 'Location')})`
                          : (cleanPlace && cleanPlace !== 'شیکاریی بینراو'
                              ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(cleanPlace)}`
                              : `https://www.google.com/maps`);

                        return (
                          <div style={{
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            marginTop: '16px',
                            marginBottom: '10px',
                            textAlign: 'center',
                            gap: '6px',
                          }}>
                            <a
                              href={googleMapsUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              style={{
                                color: '#e2a545',
                                fontSize: '16px',
                                fontWeight: 700,
                                textDecoration: 'underline',
                                textUnderlineOffset: '4px',
                                cursor: 'pointer',
                                display: 'inline-flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '6px',
                                letterSpacing: '0.2px',
                                transition: 'opacity 0.2s',
                              }}
                            >
                              Open in Google Maps
                            </a>

                            {hasValidCoords && (
                              <button
                                onClick={() => setActiveRedCircleLocation({
                                  lat: lat!,
                                  lng: lng!,
                                  placeName: cleanPlace || loc?.placeName || 'شاری پێشبینیکراو',
                                  confidence: loc?.confidence,
                                })}
                                style={{
                                  background: 'rgba(239, 68, 68, 0.12)',
                                  border: '1px solid rgba(239, 68, 68, 0.45)',
                                  color: '#fca5a5',
                                  borderRadius: '999px',
                                  padding: '5px 14px',
                                  fontSize: '12px',
                                  fontWeight: 600,
                                  cursor: 'pointer',
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '6px',
                                  marginTop: '3px',
                                  transition: 'all 0.15s ease',
                                }}
                              >
                                <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#ef4444', boxShadow: '0 0 6px #ef4444' }} />
                                <span>🔴 پیشاندانی بازنەی سووری شارەکە ({cleanPlace || loc?.placeName || 'شار'})</span>
                              </button>
                            )}

                            {hasValidCoords && (
                              <div style={{ fontSize: '11px', color: 'var(--text-low)', fontFamily: 'monospace', marginTop: '2px' }}>
                                📍 {lat?.toFixed(5)}°, {lng?.toFixed(5)}°
                              </div>
                            )}
                          </div>
                        );
                      })()}

                      {/* Message Actions: Like, Pin, and Save as File */}
                      {m.text && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '6px', fontSize: '11px', color: 'var(--text-low)' }}>
                          <button
                            onClick={() => {
                              setMessages((prev) =>
                                prev.map((msg) => (msg.id === m.id ? { ...msg, isLiked: !msg.isLiked } : msg))
                              );
                            }}
                            style={{ background: 'transparent', border: 'none', color: m.isLiked ? 'var(--accent)' : 'var(--text-low)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}
                            title="ڵایک کردن"
                          >
                            <span>{m.isLiked ? '❤️' : '🤍'}</span>
                            <span>{m.isLiked ? 'ڵایک کرا' : 'ڵایک'}</span>
                          </button>

                          <button
                            onClick={() => {
                              setMessages((prev) =>
                                prev.map((msg) => (msg.id === m.id ? { ...msg, isPinned: !msg.isPinned } : msg))
                              );
                            }}
                            style={{ background: 'transparent', border: 'none', color: m.isPinned ? 'var(--accent)' : 'var(--text-low)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}
                            title="پینکردنی چات"
                          >
                            <span>{m.isPinned ? '📌' : '📍'}</span>
                            <span>{m.isPinned ? 'پینکراو' : 'پین'}</span>
                          </button>

                          <button
                            onClick={() => {
                              const blob = new Blob([m.text || ''], { type: 'text/plain;charset=utf-8' });
                              const url = URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = `vx-chat-${m.id}.txt`;
                              a.click();
                              URL.revokeObjectURL(url);
                            }}
                            style={{ background: 'transparent', border: 'none', color: 'var(--text-low)', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '3px' }}
                            title="سەیڤکردن وەک فایل"
                          >
                            <span>💾</span>
                            <span>سەیڤکردن وەک فایل</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="vx-chat-msg ai">
              <div className="vx-chat-bubble" style={{ color: 'var(--accent)' }}>
                {loadingText}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* BOTTOM COMPOSER DOCK */}
      <footer className="vx-bottom-dock">
        <div className="vx-dock-inner">
          <div className="vx-dock-toggles-row1">
            <div style={{ display: 'flex', gap: '4px' }}>
              {(['Normal', 'Shorter', 'Detailed'] as const).map((style) => (
                <button
                  key={style}
                  className={`vx-chip ${activeStyle === style ? 'active' : ''}`}
                  onClick={() => setActiveStyle(style)}
                >
                  {style}
                </button>
              ))}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ fontSize: '11px', color: 'var(--text-low)', marginRight: '4px' }}>Thinking</span>
              <button
                className={`vx-chip ${thinkingOn ? 'active' : ''}`}
                onClick={() => setThinkingOn(!thinkingOn)}
              >
                {thinkingOn ? 'On' : 'Off'}
              </button>
            </div>
          </div>

          <div className="vx-dock-toggles-row2">
            {(['Security / Cyber', 'Web', 'Agent'] as const).map((tool) => (
              <button
                key={tool}
                className={`vx-tool-chip ${activeTools.includes(tool) ? 'active' : ''}`}
                onClick={() => toggleTool(tool)}
              >
                {tool}
              </button>
            ))}

            <div className={`vx-img-preview-chip ${attachedPhotoBase64 ? 'show' : ''}`} id="vx-img-chip">
              {attachedPhotoBase64 && (
                <img id="vx-thumb-img" className="vx-thumb-small" src={attachedPhotoBase64} alt="preview" />
              )}
              {detectedExif && detectedExif.latitude ? (
                <span style={{ color: 'var(--green)', fontWeight: 700 }}>
                  📍 GPS ({detectedExif.latitude.toFixed(3)}, {detectedExif.longitude.toFixed(3)})
                </span>
              ) : (
                <span style={{ color: '#e2a545' }}>📍 وێنە ئامادەیە بۆ /location</span>
              )}
              <button
                type="button"
                style={{ background: 'transparent', border: 'none', color: 'var(--text-low)', cursor: 'pointer' }}
                onClick={clearSelectedPhoto}
              >
                ×
              </button>
            </div>
          </div>

          <form className="vx-composer-box" onSubmit={(e) => handleSendComposer(e)}>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              style={{ display: 'none' }}
              onChange={handlePhotoChosen}
            />

            <button
              type="button"
              className="vx-attach-btn"
              onClick={() => fileInputRef.current?.click()}
              title="هاوپێچ کردنی وێنە"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
              </svg>
            </button>

            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              id="vx-user-input"
              className="vx-composer-input"
              placeholder="نامەیەک بنووسە... یان /check یان /location لەگەڵ وێنە"
              autoComplete="off"
            />

            <button type="submit" className="vx-send-btn" title="ناردن">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                <line x1="12" y1="19" x2="12" y2="5"></line>
                <polyline points="5 12 12 5 19 12"></polyline>
              </svg>
            </button>
          </form>
        </div>
      </footer>

      {/* Modals & Cyber Drawer */}
      <ModelSelectorModal
        isOpen={isModelModalOpen}
        onClose={() => setIsModelModalOpen(false)}
        currentModel={activeModel}
        onSelectModel={(m) => setActiveModel(m)}
      />

      <CyberDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onTriggerCheck={(url) => perform5PointAudit(url)}
        onTriggerPrompt={(prompt) => sendPromptPill(prompt)}
        onOpenImageStudio={() => setIsImageStudioOpen(true)}
        scanHistory={scanHistory}
      />

      <ImageEditStudioModal
        isOpen={isImageStudioOpen}
        onClose={() => setIsImageStudioOpen(false)}
        onSendToChat={(prompt, img) => {
          if (img) setAttachedPhotoBase64(img);
          sendPromptPill(prompt);
        }}
      />

      <FeaturesShowcaseModal
        isOpen={isFeaturesModalOpen}
        onClose={() => setIsFeaturesModalOpen(false)}
        onTriggerPrompt={(prompt) => sendPromptPill(prompt)}
        onOpenImageStudio={() => setIsImageStudioOpen(true)}
      />

      <RedCircleMapModal
        isOpen={!!activeRedCircleLocation}
        onClose={() => setActiveRedCircleLocation(null)}
        location={activeRedCircleLocation}
      />

      {/* Quick Search & Filter Modal */}
      <QuickSearchBar
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        lang={lang}
        onSelectAction={(actionKey, payload) => {
          if (actionKey === 'open_image_studio') setIsImageStudioOpen(true);
          else if (actionKey === 'open_store') setIsStoreOpen(true);
          else if (actionKey === 'open_gallery') setIsGalleryOpen(true);
          else if (actionKey === 'open_agent_runner') {
            setAgentRunnerPrompt(payload || '');
            setIsAgentRunnerOpen(true);
          }
          else if (actionKey === 'trigger_prompt' && payload) sendPromptPill(payload);
        }}
      />

      {/* Autonomous Agent Web Runner Modal */}
      <AutonomousAgentRunnerModal
        isOpen={isAgentRunnerOpen}
        onClose={() => setIsAgentRunnerOpen(false)}
        lang={lang}
        initialPrompt={agentRunnerPrompt}
      />

      {/* Store & Orders Modal */}
      <StoreOrderModal
        isOpen={isStoreOpen}
        onClose={() => setIsStoreOpen(false)}
        lang={lang}
      />

      {/* Media Gallery Modal */}
      <MediaGalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        lang={lang}
      />

      {/* User Profile & Account Modal */}
      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={authUser}
        onSignOut={() => {
          try {
            localStorage.removeItem('xv_auth_user');
          } catch {}
          setAuthUser(null);
          setIsAuthModalOpen(true);
        }}
        lang={lang}
      />

      {/* Authentication Lock Gate */}
      <AuthGateModal
        isOpen={isAuthModalOpen}
        onAuthenticated={(user) => {
          setAuthUser(user);
          setIsAuthModalOpen(false);
        }}
      />
    </>
  );
}
